close all
clear
clc
load sample_lin

para.dim = size(Xl, 2);
para.lambda = 1/10;                 % parameter for regularization parameter
para.CL = 10;                       % SVM parameter for label data from the class +1 or -1
para.riLt = para.CL*para.lambda;    % parameter for label data from the class +1 or -1
para.riL0 = [];                     % parameter for label data following distribution different from the class +1 or -1
para.riU = 0.5*para.lambda;         % parameter for unlabeled data
% You can set different parameter for each point

para.C0 = inf;                      % parameter for alpha0, default is inf, we can change it for penalizing the balance constraint.
para.epsilon = 0.01;                % epsilon insensitive function
para.kappa = -0.1;                  % parameter for new defined loss function
para.D = 2;                         % a sufficiently large constant
para.eps = 1e-6;
para.options.Kernel = 'linear';
para.options.KernelParam = 0;
para.InitialMethod = 'SVM';

para.bShow = 1;
para.tol = 1e-8;
para.algo.ridge = 1e-8;
para.inf = 1e6;
para.balance = 0;                   % for balanced constraint
para.calOFVal = 1;
% para.mosekpath = 'D:/Tools/Mosek/5/toolbox/r2006b'; % you may change the Mosek path here
para.solver = 'Mosek_QP';           % solve 3CSVM using mosek optimization toolbox
para.mosekpath = 'C:\Program Files\Mosek\7\toolbox\r2009b';
setenv('KMP_DUPLICATE_LIB_OK','TRUE')
para.marker.size = 6;
para.marker.type = 'o';
para.marker.color = 'r';
para.alpha_cutoff = 0;
para.MaxIter = 20;

% Xl: labeled training data from class +1 or -1 
% Xus: unlabeled data following the same distribution of class +1 or -1
% Xuu: unlabeled data following different distribution of class +1 or -1
X = [Xl; Xus; Xuu]; 

Xu = [Xus; Xuu];
Yu = zeros(size(Xu,1),1);
Data_u = struct('X', Xu, 'Y', [], 'type', 'u') ;

para.l = size(Xl, 1);
para.u = size(Xu, 1);

if (para.bShow==1)
    Axis_max = max(X+0.5,[], 1);
    Axis_min = min(X-0.5,[], 1);
    para.axis_range = [Axis_min(2) Axis_max(2)  Axis_min(1)  Axis_max(1)];
    para.axis_range = [-2 2 -1.6 1.6];

    hfig = figure; hold on; box on; 
    xlabel('x_1');
    ylabel('x_2');
    title('Data');

    Data_l = struct('X', Xl, 'Y', Yl, 'type', 'l') ;
    Data_us = struct('X', Xus, 'Y', [], 'type', 'u') ;
    Data_un = struct('X', Xuu, 'Y', [], 'type', 's') ;
    MyShowData(Data_l);
    MyShowData(Data_us);
    MyShowData(Data_un);
    axis(para.axis_range);
    axis equal;

    Fs(1) = getframe(hfig);
end
    
% 3C-SVM
Data = struct('Xl', Xl, 'Yl', Yl, 'X0', [], 'Xu', Xu);

Lt = size(Data.Xl, 1);
L0 = size(Data.X0, 1);
U = size(Data.Xu, 1);

L0e = 2*L0;
L = L0e+Lt;
LU = L+U;
L2U = L+2*U;
L4U = L+4*U;

para.L0 = L0;
para.Lt = Lt;
para.l = L;
para.u = U;
para.ri = [para.riL0; para.riL0; para.riLt*ones(L,1); para.riU*ones(4*U, 1)]; 

[algo_3CSVM F] = TCSVM(para, Data);  
algo_3CSVM.training_time

classifier_3CSVM = saveclassifier('svm', algo_3CSVM.svs, algo_3CSVM.alpha(:,1), algo_3CSVM.Xsvs, algo_3CSVM.b, para.options);
ls_3CSVM = struct('color', [1 0 1], 'linewidth', 1, 'linestyle', '-');

if (para.bShow==1)
    hfig=figure; hold on; grid on; box on;
    h01 = MyShowData(Data_l);
    h02 = MyShowData(Data_u);

    h3 = plotsvmcurve(classifier_3CSVM, para.axis_range, ls_3CSVM);  
    h30 = MyShowData(Data_u, algo_3CSVM.d, para);

    legend([h01; h02; h3; h30], {'+1 Class'; '-1 Class'; 'Unlabeled'; '3C-SVM'; '0 Class'; }, 1); 
    xlabel('x_1');
    ylabel('x_2');
    title('Demo for 3C-SVM');

    Fs = [Fs F getframe(hfig)];
    movie2avi(Fs,'Demo_3CSVM','fps',1,'compression','none', 'quality', 30);
end