function h = plotsvmcurve(classifier, axis_range, para) % add parameter para by Haiqin
if (isempty(para.color))
    para.color = [0 0 1];
end

if (para.linewidth == 0)
    para.linewidth = 1;
end

if (isempty(para.linestyle))
    para.linestyle = '-';
end


h = ezplot(@(x,y)myfun(x,y, classifier), axis_range);
set(h, 'color', para.color, 'LineWidth', para.linewidth, 'LineStyle', para.linestyle);
axis(axis_range);
axis equal;
end

function z=myfun(x,y, classifier)

switch classifier.options.Kernel
    case 'linear'
        K=[x y]*classifier.xtrain';
    case 'rbf'
        D2=distSqrd([x y], classifier.xtrain);
        if (options.libsvm == 1)
            K=exp( -0.5/para.options.KernelParam*D2);
        else
            K=exp( -0.5/sig_ker^2 *D2);
        end
end
    z=K*classifier.alpha+classifier.b;    
end
