function [alpha, b, fval, tr_time] = SolveInnerQP_bal(K, Y, mu, para)
% Solve the dual of QP, which does not include balance constraint
% Output
%  alpha: consist of alpha: alpha_t(1:L2U);
%           alpha^*: alpha_t(L2U+1:L4U);
%           alpha0
%           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha = [];
b = [];
fval = -inf;
tr_time = 0;

% K = calkernel(para.options, X);
Q = K.*(Y*Y')/para.lambda;
len = size(Q, 1);

L0 = para.L0;
L = para.l;
Lt = L-2*L0;
U = para.u;
L2U = L+2*U;
L4U = L+4*U;

% HH = [Q(1:L2U) Q(1:end, L+1:L2U) ; ...
%     Q(L+1:L2U, :) Q(L+1:L2U, L+1:L2U); ...
%     ];
% HH = HH+para.algo.ridge*eye(size(HH));
%   
% % p = [-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1);
% % -para.epsilon*ones(2*U, 1)];
% % p = [Q(1:L2U,1+L:L2U); Q(L+1:L2U, L+1:L2U)]*mu/para.lambda+[-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1); para.epsilon*ones(2*U,1)];
% p = [Q(1:L2U,1+L:L2U); Q(L+1:L2U, L+1:L2U)]*mu+[-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1); para.epsilon*ones(2*U,1)];


HH = [Q(1:L2U, 1:L2U), Q(1:L2U, L+1:L2U+1); ...
    Q(L+1:L2U+1, 1:L2U) Q(L+1:L2U+1, L+1:L2U+1); ...
    ];
HH = HH+para.algo.ridge*eye(size(HH));
  
p = [Q(1:L2U,1+L:L2U); Q(L+1:L2U+1, L+1:L2U)]*mu+[-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1); para.epsilon*ones(2*U,1); mean(Y(2*L0+1:L, 1))];
% [ones(L, 1); (1-para.D)*ones(2*U, 1); para.epsilon*ones(2*U,1); mean(Y(1:L, 1))];

Aneq = -[zeros(U, L) para.D*eye(U) para.D*eye(U) -para.D*eye(U) -para.D*eye(U) zeros(U, 1)];
bneq = zeros(U, 1);

Aeq = [Y(1:L2U, 1); Y(L+1:L2U); 1]';
beq = Y(L+1:L2U,1)'*mu;

lb = [zeros(L4U, 1); -para.C0] ;
ub = [para.ri; para.C0];

% trace(HH)
switch para.solver
    case 'Mosek_QP' % using Mosek to solve the QP
        tic;
        [alpha, fval, exitflag, output, lambda] ...
            = quadprog(HH, -p, Aneq, bneq, Aeq, beq, lb, ub, [], []);
        tr_time = toc;
        b = lambda.eqlin(end);
    case 'Matlab_QP'  % using quadprog in Matlab, not work sometimes 
        opts= optimset('display','off','MaxIter',10000,'LargeScale','off'); 
        tic
        [alpha, fval, exitflag, output, lambda] ...
            = quadprog(HH, -p, Aneq, bneq, Aeq, beq, lb, ub, [], opts);
        tr_time = toc;
        b = lambda.eqlin(end);
end
