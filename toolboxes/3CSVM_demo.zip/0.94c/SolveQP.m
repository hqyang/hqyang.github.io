function [algo] = SolveQP(K, Y, para);
% Mosek_QP: using Mosek toolbox to solve the QP
% Matlab_QP: using Matlab Optimization Toolbox, quadprog, would be slower.

algo.alpha = [];
algo.b = [];
algo.svs = [];
algo.Xsv = [];
algo.training_time = 0;

% K = calkernel(para.options, X);
len = size(K, 1);
Q = K.*(Y*Y');
Q = Q+sparse(eye(size(K))*para.algo.ridge);

switch para.solver
    case 'Mosek_QP'
		setenv('KMP_DUPLICATE_LIB_OK','TRUE')
        addpath(para.mosekpath);
        tic;
        [alpha, fval, exitflag, output, lambda] = ...
            quadprog(Q, -ones(len,1), [], [], Y', 0, zeros(len,1), para.CL*ones(len,1), [], []);
        algo.training_time = toc;
% %         rmpath(para.mosekpath);
        
        algo.alpha = alpha.*Y;
        algo.b = lambda.eqlin(1);
%         algo.Xsvs = X;
        algo.fval = fval;
    case 'Matlab_QP'
        % calculate alpha
        opts= optimset('display','off','MaxIter',10000,'LargeScale','off'); 
        tic;
        [alpha,fval,exit,out,lambda] = quadprog(Q, -ones(len,1), [], [], Y', 0, zeros(len,1), para.CL*ones(len,1), [], opts);
        algo.alpha= alpha.*Y;
        algo.b=lambda.eqlin(1);    % f(x) = sum(alpha_i*K(x,x_i))+b
        algo.training_time = toc;
%         algo.Xsvs = X;
        algo.fval = fval;
end
algo.svs = find(abs(algo.alpha)>eps);