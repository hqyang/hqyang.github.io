function [algo, F, history] = TCSVM(para, Data)

% para: parameter for the algorithm
% Data: 
%   Xl:  nl*d, feature for labeled target data; 
%   Yl:  nl*1, labels for target data, values are in {-1, +1};
%   X0:  nl0*d, feature for irrelevant data	
%   Xu:  nu*d, features for unlabeled data

% algo.alpha = [];
% algo.b = [];
% algo.svs = [];
% algo.d = zeros(para.u, 1);
% algo.Xsvs = [Xl; Xu];
algo.fval = [];
algo.OFVal = [];

Lt = size(Data.Xl, 1);
L0 = size(Data.X0, 1);
U = size(Data.Xu, 1);

L0e = 2*L0;
L = L0e+Lt;
LU = L+U;
L2U = L+2*U;
L4U = L+4*U;
%%% Construct kernel
XAll = [Data.X0; Data.X0; Data.Xl; Data.Xu; Data.Xu];

% if (L0~=0)
%     YAll = [ones(L0, 1); -ones(L0, 1); Data.Yl; ones(U, 1); -ones(U,1)];
% else
    YAll = [Data.Yl; ones(U, 1); -ones(U,1)];
% end
Yl = Data.Yl;

para_t = para;

% switch para.algo.name
%     case {'3CSVM', '3CSVM_b', '3CSVM_ori', '3CSVM_ori_b'} % use Matlab optimization toolbox quadprog to solve the QP
%         para_t.algo.name = 'Matlab_QP';
%     case {'3CSVM_L4U', '3CSVM_L4U_b', '3CSVM_L4U_ori', '3CSVM_L4U_ori_b'} % use Mosek optimization toolbox quadprog to solve the QP
%         para_t.algo.name = 'Mosek_QP';
% end

% construct kernel, to simplify, we construct the training kernel once
KAll = calkernel(para.options, XAll);


if (para.balance)
    Ki0 = mean(KAll(:, L+1:LU), 2);
    K0i = Ki0';
%     K00 = mean(mean(KAll(L+1:LU, L+1:LU)));
    K00 = mean(Ki0(L+1:LU));
    KAll = [KAll Ki0; K0i K00];
    YAll = [YAll; 1];
end

iter = 1;

OFVal = [];
% Initialization 
switch para.InitialMethod
    case 'SVM' %training SVM on only labeled data
        TLI = L0e+1:L;
        [algo_t0] = SolveQP(KAll(TLI, TLI), Data.Yl, para_t);
        algo_t0.Xsvs = Data.Xl;
       
        % Calculate d_0
        [d_t0 FxVal] = Calculate_d_K(algo_t0, KAll(L+1:LU, TLI), para_t);

        % Calculate the optimized objective function
        if para.calOFVal 
            OFVal = CalObjectiveFunction(para, algo_t0, KAll(1:LU, TLI), Yl);
        end
        
        % Update mu
        [mu_iter, II] = UpdateMu_Dual(algo_t0, d_t0, KAll(L+1:L2U, TLI), YAll(L+1:L2U, 1), para_t);
    case 'USVM'  %training USVM on only labeled and unlabeled data
        TLI = 1:L2U;
        [algo_t0] = Solve_UniversumK(KAll(TLI, TLI), YAll(1:L2U,1), para_t);
        algo_t0.Xsvs = XAll;
       
        % Calculate d_0
        [d_t0 FxVal] = Calculate_d_K(algo_t0, KAll(L+1:LU, TLI), para_t);

        % Calculate the optimized objective function
        if para.calOFVal 
            OFVal = CalObjectiveFunction(para, algo_t0, KAll(1:LU, TLI), Yl);
        end

        % Update mu
        [mu_iter, II] = UpdateMu_Dual(algo_t0, d_t0, KAll(L+1:L2U, TLI), YAll(L+1:L2U, 1), para_t);        
end
% Here, we use all points as support vectors for simplicity.  Actually, we
% can get those points corresponding to non-zero algo_t0.alpha

algo.training_time = algo_t0.training_time;
algo.fval = [algo.fval; algo_t0.fval];
algo.OFVal = [algo.OFVal; OFVal];

history.d(:, iter) = d_t0;
history.mu(:, iter) = mu_iter;
% End initialization

% show result
if para.bShow==1
    svs_t = [];
    Data_l = struct('X', Data.Xl, 'Y', Data.Yl, 'type', 'l') ;
    Data_u = struct('X', Data.Xu, 'Y', [], 'type', 'u') ;
    classifier1=saveclassifier('svm', svs_t, algo_t0.alpha, algo_t0.Xsvs, algo_t0.b, para.options);
    ls = struct('color', [1 0 0], 'linewidth', 0, 'linestyle', ':');

    hfig = figure; hold on; box on;
    xlabel('x_1');
    ylabel('x_2');
    MyShowData(Data_l);
    plotsvmcurve(classifier1, para.axis_range, ls);
    hu1 = MyShowData(Data_u); 
    hu2 = MyShowData(Data_u, d_t0, para); 
    
    title_str = ['The ' num2str(iter) '-th result for 3C-SVM'];
    title(title_str);
    
    F(iter) = getframe(hfig);
end

mu_diffs = 10*para.tol;

while (mu_diffs>para.tol && iter<para.MaxIter)
    % 1. solve the QP to get alpha, alpha^*, alpha_0(if needed), t, b
    
    if (para.balance==false)
        [alphas_iter, b_iter, fval_iter, tr_time] = SolveInnerQP(KAll, YAll, mu_iter, para_t);
        alpha_iter = YAll(1:L2U,1).*(alphas_iter(1:L2U)+[zeros(L,1); alphas_iter(L2U+1:L4U)-mu_iter])/para.lambda;
%         alpha_iter = YAll(1:L2U,1).*(alphas_iter(1:L2U)+[zeros(L,1); alphas_iter(L2U+1:L+4*U)-mu_save(:,iter)]);
    else
        [alphas_iter, b_iter, fval_iter, tr_time] = SolveInnerQP_bal(KAll, YAll, mu_iter, para_t);
        alpha_iter = YAll(1:L2U,1).*([alphas_iter(1:L2U)]+[zeros(L,1); alphas_iter(L2U+1:L4U)-mu_iter+YAll(L+1:L2U,1)*alphas_iter(L4U+1,1)/U/2])/para.lambda;
%         alpha_iter = YAll(1:L2U, 1).*(alphas_iter(1:L2U)+[zeros(L,1); alphas_iter(L2U+1:L+4*U)-mu_save(:,iter)+YAll(L+1:L2U,1)*alphas_iter(L+4*U+1,1)/U/2]);        
    end
    algo_t.alpha = alpha_iter;
    algo.training_time = algo.training_time+tr_time;
    algo.fval = [algo.fval; fval_iter];
    algo_t.b = b_iter;
    algo_t.Xsvs = XAll;

    [d_iter FxVal_t] = Calculate_d_K(algo_t, KAll(L+1:L+U, 1:L+2*U), para_t);
    
    if para.calOFVal 
        OFVal = CalObjectiveFunction(para_t, algo_t, KAll(1:L+2*U, 1:L+2*U), Data.Yl);  
    end
    algo.OFVal = [algo.OFVal; OFVal];
    
    [mu_iter, II] = UpdateMu_Dual(algo_t, d_iter, KAll(L+1:L2U, 1:L2U), [ones(U,1); -ones(U,1)], para_t);    
    
    iter = iter + 1;

    % save results
    history.alphas(:, iter) = alpha_iter;
    history.b(:, iter) = b_iter;
    history.d(:, iter) = d_iter;
    history.mu(:, iter) = mu_iter;
    
    if para.bShow==1
        classifier_show = saveclassifier('svm', [], alpha_iter, algo_t.Xsvs, b_iter, para.options);
        para.ls = struct('color', [1 0 0], 'linewidth', 0, 'linestyle', ':');

        hfig = figure; hold on; box on;
        xlabel('x_1');
        ylabel('x_2');
        MyShowData(Data_l);
        
        plotsvmcurve(classifier_show, para.axis_range, para.ls);  
        hu1 = MyShowData(Data_u); 
        hu2 = MyShowData(Data_u, d_iter, para); 
        
        title_str = ['The ' num2str(iter) '-th result for 3C-SVM'];
        title(title_str);
        
        F(iter) = getframe(iter);
    end

    Diff_mu(iter,1) = sum(abs(history.mu(:,iter)-history.mu(:,iter-1)));
    mu_diffs = Diff_mu(iter, 1);
    if (iter>2) % may be jumped interval in the start of writing codes, seems no this problem afterwards
        mu_diff2 = sum(abs(history.mu(:,iter)-history.mu(:,iter-2)));        
        if (mu_diff2)<mu_diffs
            mu_diffs = mu_diff2;
            disp('use mu difference 2');
        end
    end
    disp(mu_diffs)
end
disp(iter)

% Store d
algo.d = d_iter;

% Store alpha and support vector features
algo.alpha = alpha_iter; 
algo.Xsvs = algo_t.Xsvs;

% Store b
algo.b = b_iter;

algo.svs = find(abs(algo.alpha)>para.eps);

algo.iter = iter;

% save('TCSVM_rs.mat', 'alpha_save', 'b_save', 'd_save');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [d_t FxVal] = Calculate_d_K(algo_t, Ku, para);
% determine d based on which error is less
d_t = zeros(para.u, 1);

% Kts = calkernel(para.options, algo_t.Xsvs, Xu);
FxVal = Ku*algo_t.alpha+algo_t.b;

AbsFxVal = abs(FxVal);

err1 = max(0, 1-AbsFxVal);
err2 = max(0, AbsFxVal-para.epsilon);

% if err1(i)<err2(i), then the point should be set to the class +1/-1, 
%   that is d(i) = 1 
II = find(err1<err2);
d_t(II, 1) = 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [mu, II] = UpdateMu_Dual(algo_t, d_t, Ku, Yu, para);
mu = zeros(para.u*2, 1);
FxVal = Ku*algo_t.alpha+algo_t.b;
Yts = FxVal.*Yu;

D1_idx = find(d_t==0);
Yts(D1_idx, 1) = para.kappa+1;
Yts(D1_idx+para.u, 1) = para.kappa+1;

II = find(Yts<para.kappa);
mu(II,:) = para.riU;
end

function OFVal = CalObjectiveFunction(para, algo_t, KAll, Yl);
% OFVal = lambda*|w|^2+sum_i(rLi*sum(max(0, 1-y_if(x_i))) ...
%        +sum_k(rUk*sum(min(max(0,1-abs(f(x_k+L))), max(0,abs(f(x_k+L)-epsilon))))) 
% 
L = para.l;
U = para.u;
len = size(algo_t.alpha, 1);

KSv = KAll(1:len, :);
KMat = KAll(1:L+U, :);

Fval = KMat*algo_t.alpha+algo_t.b;
errL = max(0, 1-Yl.*Fval(1:L,1));

AFvalU = abs(Fval(1+L:L+U, 1));
errU = min(max(0, 1-AFvalU), max(0, AFvalU-para.epsilon));

OFVal = para.lambda*algo_t.alpha'*KSv*algo_t.alpha+para.riLt*sum(errL)+para.riU*sum(errU);
end