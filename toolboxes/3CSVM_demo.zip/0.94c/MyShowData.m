function h = MyShowData(data, d, para)
% d = 0: class 0
if (nargin<2)
    d = [];
end

h = [];
switch data.type
    case 'l'
        X = data.X;
        Y = data.Y;
        II = find(Y==1);
        JJ = find(Y==-1);
        h1 = plot(X(II, 1), X(II, 2), 'r+');
        h2 = plot(X(JJ, 1), X(JJ, 2), 'bs');
        h = [h1; h2];
    case 'u'
        if (isempty(d))
            h1 = plot(data.X(:, 1), data.X(:,2), 'k.');
            h = h1;
        else
            II = find(d==0);
            h2 = plot(data.X(II, 1), data.X(II, 2), 'o');
            set(h2, 'color', para.marker.color, 'MarkerSize', para.marker.size);
            h = h2;
        end
        
    case 'm'
        h = plot(data.X(:, 1), data.X(:,2), 'ko', 'MarkerSize', 8);
    case 's' % 'universum
        h = plot(data.X(:, 1), data.X(:,2), 'kp', 'MarkerEdgeColor','k', 'MarkerFaceColor', 'k');        
end