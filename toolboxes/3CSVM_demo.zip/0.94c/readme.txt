Notes to run the demo codes
1. type demo_3CSVM to test the 3C-SVM
2. A sequence of images will be shown and Demo_3CSVM.avi will be generated.
3. Currently, the codes are tested in v7.8.0.347 (R2009a). 
4. The Mosek used is version 7.  You may need a licence for it.


FAQ:
1. Warning: Name is nonexistent or not a directory: C:\Program Files\Mosek\7\toolbox\r2009b.

A: You need the Mosek toolbox, which can be downloaded from http://www.mosek.com.  You need to install it and set the mosek path in line 20 demo_3CSVM.m

In the codes, when para.solver = 'Mosek_QP', the QP problem is solved by the mosek optimization toolbox while para.solver = 'Matlab_QP', the QP problem is solved by the default Matlab QP solver. 

In our observation, using mosek solver can attain good solutions.  Using the original Matlab quadprog is slow and the results are not robust.

2. The parameter para.balance is used to denote the balance constraint. Adding the balance constraint may not help the performance when there are unlabeled universum data.

Update procedure
1. Ver0.9c: implement codes without simplying \alpha_k^{\star}=\alpha_k^*-\mu_k.
2. Ver0.91c: implement codes with simplying \alpha_k^{\star}=\alpha_k^*-\mu_k and adding balance constraint, while calculating the kernel only once to reduce computations.
3. Ver0.92c: in some cases, errors will be propagated in \mu_k, turn back to case 1.  So add options '3CSVM_ori', '3CSVM_ori_b', '3CSVM_L4U_ori', and '3CSVM_L4U_ori_b'
to implement the original cases. 
4. Ver0.93c: slightly modification.
4. Ver0.94c: 
1) test in Mosek versin 7, setenv('KMP_DUPLICATE_LIB_OK','TRUE') is added. 
2) the original implementation is based on the framework of [1].  This version releases the empirical evaluation strictly follow Theorem 3 in the Neural Networks paper. 

If you have any further questions, please email me by hqyang@ieee.org.

[1] R. Collobert, F. H. Sinz, J.Weston, and L. Bottou. Large scale transductive svms. Journal of Machine Learning Research, 7:1687–1712, 2006.
Mar. 10, 2015