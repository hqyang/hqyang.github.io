function [alpha, b, fval, tr_time] = SolveInnerQP(K, Y, mu, para)
% Solve the dual of QP, which does not include balance constraint
% Output
%  alpha: consist of alpha: alpha_t(1:L2U);
%           alpha^*: alpha_t(L2U+1:L4U);
%           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha = [];
b = [];
fval = -inf;
tr_time = 0;

% K = calkernel(para.options, X);
Q = K.*(Y*Y')/para.lambda;

L0 = para.L0;
L = para.l;
Lt = L-2*L0;
U = para.u;
L2U = L+2*U;
L4U = L+4*U;

HH = [Q Q(1:end, L+1:L2U) ; ...
    Q(L+1:L2U, :) Q(L+1:L2U, L+1:L2U); ...
    ];
HH = HH+para.algo.ridge*eye(size(HH));
  
% p = [-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1);
% -para.epsilon*ones(2*U, 1)];
% p = [Q(1:L2U,1+L:L2U); Q(L+1:L2U, L+1:L2U)]*mu/para.lambda+[-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1); para.epsilon*ones(2*U,1)];
p = [Q(1:L2U,1+L:L2U); Q(L+1:L2U, L+1:L2U)]*mu+[-para.epsilon*ones(2*L0, 1); ones(Lt, 1); (1-para.D)*ones(2*U, 1); para.epsilon*ones(2*U,1)];

lb = zeros(L4U, 1);
ub = para.ri;

Aeq = [Y; Y(L+1:L2U)]';
% beq = [Y(L+1:L2U,1)'*mu*para.ri(L+1:L2U)];
% beq = sum(Y(L+1:L2U, 1).*mu.*para.ri(L+1:L2U));
beq = Y(L+1:L2U, 1)'*mu;

Aneq = -[zeros(U, L) para.D*eye(U) para.D*eye(U) -para.D*eye(U) -para.D*eye(U)];
bneq = zeros(U, 1);

% trace(HH)
switch para.solver
    case 'Mosek_QP' % using Mosek to solve the QP
		setenv('KMP_DUPLICATE_LIB_OK','TRUE')
        addpath(para.mosekpath);        
        tic;
        [alpha, fval, exitflag, output, lambda] ...
            = quadprog(HH, -p, Aneq, bneq, Aeq, beq, lb, ub, [], []);
        tr_time = toc;
        exitflag
%         lambda.eqlin
        b = lambda.eqlin(end);
    case 'Matlab_QP'  % using quadprog in Matlab, not work sometimes 
        opts= optimset('display','off','MaxIter',10000,'LargeScale','off'); 
        tic
        [alpha, fval, exitflag, output, lambda] ...
            = quadprog(HH, -p, Aneq, bneq, Aeq, beq, lb, ub, [], opts);
        tr_time = toc;
        b = lambda.eqlin(end);
end
