#!/usr/bin/python
'''
categorize the original file according to category
'''
import sys
import re
if(len(sys.argv)!= 3):
    print 'Usage: ./cate_temporal temporal_cate_file cate_survey_file'
    sys.exit(-1)

sep = re.compile('\s+')
temporal_file = open(sys.argv[1],'r')
survery_file = open(sys.argv[2],'r')
name_list = {}
pa_list = {}

cate_no = 0
## read category file

while True:
    line = survery_file.readline().rstrip()
    if not line:
        break
    t1 = sep.split(line)
    pa_id = int(t1[0])
    name = t1[1]
    line = survery_file.readline().rstrip()
    t2 = sep.split(line)
    name_list[pa_id] = name
    for c in t2:
        cid = int(c)
        pa_list[cid] = pa_id
    cate_no += 1
print name_list
wline = {}

while True:
    line = temporal_file.readline().rstrip()
    if not line:
        break
    t = sep.split(line)
    cate_id = int(t[1])
    if not pa_list.has_key(cate_id):
        continue
    pa_id = pa_list[cate_id]
    if not wline.has_key(pa_id):
        wline[pa_id] = line
    else:
        wline[pa_id] += '\n' + line

for pid in sorted(wline.keys()):
    fname = './Cate/' + name_list[pid]
    print fname
    ff = open(fname,'w')
    ff.write(wline[pid])
    ff.close()
survery_file.close()
temporal_file.close()
