#include <stdio.h>
#include <math.h>
#include <time.h>
#include<sys/time.h>
#include <stdlib.h>
#include <unistd.h>
/****************************************************************************
 * define some global variables 
 * *************************************************************************/

// model input

#define UNUM 53944 // user number
#define LNUM 367149 // location number
//#define K 10 // latent dimension
#define PRED_N 20 // predict num
int K;
int bool_dist;
int modelbased;
char *result_file;
int **tul; // test user location matrix
double **luf; // latent user vector
double **llf; // latent location vector
double alpha;
int **ul;
int test_num = 0;
int start = 0;
char *record_file;
double pi = 3.141592653589793;
// for pred ranking
typedef struct
{
    double val;
    int loc;
}rating;

typedef struct
{
    double lat;
    double lng;
    double var_lat;
    double var_lng;
    int freq;
}Pos;

Pos** user_center;
Pos loc_info[LNUM+1];

double sigmoid(double val)
{
    return 1.0/(1+exp(-val));
}

double dsigmoid(double val)
{
    double v = sigmoid(val);
    return v*(1.0-v);
}
int compare(const void * a, const void* b)
{
    rating *a1 = (rating*)a;
    rating *b1 = (rating*)b;
    if (a1->val > b1->val)
        return -1;
    else if (a1->val < b1->val)
        return 1;
    return 0;
}

int intComp(const void* a, const void* b)
{
    int* a1 = (int*)a;
    int* b1 = (int*)b;
    if( *a1 > *b1)
        return 1;
    else if (a1 < b1)
        return -1;
    return 0;
}

double distance(Pos p1,Pos p2)
{
    double r = 6378.16;
    double pi = 3.141592653589793;
    double a1 = sin(p1.lat*pi/180) * sin(p2.lat*pi/180);
    double a2 = cos(p1.lat*pi/180) * cos(p2.lat*pi/180) * cos(p2.lng*pi/180 - p1.lng*pi/180);
    return r*acos(a1+a2);
}

void getInput(int argc,char **argv)
{
    FILE* fp = NULL;
    if (argc != 15)
    {
        fprintf(stderr,"./evalModel test_ci user_center loc_info K ULatent LLatent train_ci test_num  bool_dist record_file result_file modelbased_bool [alpha] start\n");
        exit(-1);
    }
    alpha = atof(argv[13]);
    start = atoi(argv[14]);
    modelbased = atoi(argv[12]);
    result_file = argv[11];
    record_file = argv[10];
    bool_dist = atoi(argv[9]);
    test_num = atof(argv[8]); 
    K = atoi(argv[4]);
    luf = (double **)malloc(sizeof(double*)*(UNUM+1));
    ul = (int **)malloc(sizeof(int*)*(UNUM+1));
    tul = (int **)malloc(sizeof(int*)*(UNUM+1));
    llf = (double **)malloc(sizeof(double*)*(LNUM+1));
    user_center = (Pos**)malloc(sizeof(Pos*)*(UNUM+1));
    int uid,num;
    uid = num = 0;
    int loc_id = 0;
    //user center file
    fp = fopen(argv[2],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[2]);
        exit(-1);
    }
    

    double lat,lng,v_lat,v_lng;
    while(fscanf(fp,"%d %d",&uid,&num) != EOF)
    {
        user_center[uid] = (Pos*)malloc(sizeof(Pos)*(num+1));
        user_center[uid][0].lat = num;
        for(int i = 1; i<= num ;i++)
        {
            int freq;
            fscanf(fp,"%lf %lf %lf %lf %d",&lat,&v_lat,&lng,&v_lng,&freq);
            user_center[uid][i].lat = lat;
            user_center[uid][i].var_lat = 0.1;
            user_center[uid][i].var_lng = 0.1;
            user_center[uid][i].lng = lng;
            user_center[uid][i].freq = freq;
        }
    }

    fclose(fp);
    
    fp = fopen(argv[3],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[3]);
        exit(-1);
    }

    while(fscanf(fp,"%d %lf %lf",&loc_id,&lat,&lng) != EOF)
    {
        loc_info[loc_id].lat = lat;
        loc_info[loc_id].lng = lng;
    }

    fclose(fp);
    //testing file
    fp = fopen(argv[1],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[1]);
        exit(-1);
    }

    while(fscanf(fp,"%d\t%d",&uid,&num) != EOF)
    {
        tul[uid] = (int*)malloc(sizeof(int)*(num+1));
        tul[uid][0] = num;
        for(int i = 1; i <= num; i++)
        {
            int tmp;
            fscanf(fp,"%d",&tmp);
            tul[uid][i] = tmp;
        }
    }
    fclose(fp);

    fp = fopen(argv[5],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[5]);
        exit(-1);
    }
    while(fscanf(fp,"%d",&uid) != EOF)
    {
        luf[uid] = (double*)malloc(sizeof(double)*K);
        for(int i = 0; i < K;i++)
        {
            double tmp;
            fscanf(fp,"%lf",&tmp);
            luf[uid][i] = tmp;
        }
    }
    fclose(fp);
    
    fp = fopen(argv[6],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[6]);
        exit(-1);
    }
    while(fscanf(fp,"%d",&loc_id) != EOF)
    {
        llf[loc_id] = (double*)malloc(sizeof(double)*K);
        for(int i = 0; i < K;i++)
        {
            double tmp;
            fscanf(fp,"%lf",&tmp);
            llf[loc_id][i] = tmp;
        }
    }
    fclose(fp);

    fp = fopen(argv[7],"r");
    
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[7]);
        exit(-1);
    }

    while(fscanf(fp,"%d %d",&uid,&num) != EOF)
    {
        ul[uid] = (int*)malloc(sizeof(int)*(num+1));
        ul[uid][0] = num;
        for(int i = 1; i <= num;i++)
        {
            int tmp;
            fscanf(fp,"%d",&tmp);
            ul[uid][i] = tmp;
        }
    }
}


//# of intersect of sorted vector
int intersect(int* real,int n1,int* pred,int n2)
{
    int num = 0;
    int i,j;
    i = j = 0;
    while( i < n1 && j < n2)
    {
        int a1=real[i];
        int a2=pred[j];
        if(a1 < a2)
            i++;
        else if(a1 > a2)
            j++;
        else
        {
            i++;j++;num++;
        }
    }
    return num;
}

double square(double x)
{
    return (x*x);
}

double dist_prob(int user,int loc_id, double alpha)
{
    int c_num = (int)user_center[user][0].lat;
    double* dist_list = (double*)malloc(sizeof(double)*c_num);
    double* prob_list = (double*)malloc(sizeof(double)*c_num);
    double p_sum = 0;
    double t_freq = 0;
    double exp_sum = 0;
    for(int m = 1; m <= c_num; m++)
    {
        double dist = distance(user_center[user][m],loc_info[loc_id]);
        dist_list[m-1] = dist;
        double v_x = user_center[user][m].var_lat;
        double v_y = user_center[user][m].var_lng;
        double x1 = square(loc_info[loc_id].lat - user_center[user][m].lat)/v_x;
        double y1 = square(loc_info[loc_id].lng - user_center[user][m].lng)/v_y;
        double index = (-0.5)*(x1+y1);
        prob_list[m-1] = exp(index)/(2*pi*sqrt(v_x)*sqrt(v_y));
        exp_sum += prob_list[m-1];
        p_sum += 1.0/(dist + 0.001);
        t_freq += pow(user_center[user][m].freq,alpha);
    }

    double re = 0;
    if(exp_sum > 1e-10)
    {
        for (int m = 1; m <= c_num; m++)
        {
            double frac = pow(user_center[user][m].freq,alpha)/t_freq;
            re += frac*prob_list[m-1]/((dist_list[m-1]+0.001)*(p_sum*exp_sum));
        }
    }
    free(dist_list);
    free(prob_list);
    return re;
}

// precision of each user
int precision_recall(double* precision, double* recall,double*f,int test_num)
{
    *precision = *recall = 0;
    double p5,p10,r5,r10;
    p5 = p10 = r5 = r10 = 0;
    FILE* fp;
    int total_num = 0;
    //fp = fopen("dist_pred_result.txt","wb");
    //re_fp=fopen("result.txt","wb");
    fp = fopen(result_file,"w");
    for(int i = start; i < start + test_num; i++)
    {
        if(i%20 == 0)
            fprintf(stdout,"%d\n",i);
        rating* pred = (rating*)malloc(sizeof(rating)*LNUM);
        int *visited = (int*)malloc(sizeof(int)*(LNUM+1));

        for(int j = 1 ; j <= LNUM; j++)
        {
            visited[j] = 0;
        }

        for(int j = 1 ; j <= ul[i][0]; j++)
        {
            visited[ul[i][j]] = 1;
        }
        int num = 0;
        int c_num = (int)user_center[i][0].lat;
        for(int j = 1 ; j <= LNUM; j++)
        {
            if(visited[j])
                continue;
            rating temp;
            temp.loc = j;
            temp.val = 0;
            for(int k = 0; k < K; k++)
            {
                temp.val += luf[i][k]*llf[j][k];
            }
            if(modelbased && bool_dist)
            {
                temp.val *= dist_prob(i,j,alpha);
            }
            else if (bool_dist)
                temp.val = dist_prob(i,j,alpha);
            /*
            if (bool_dist)
                temp.val *= dist_prob(i,j,0.2);
            */
            pred[num++] = temp;
        }
        //fprintf(stdout,"yes\n");
        qsort(pred,num,sizeof(rating),compare);
        /*
        fprintf(fp,"%d\t50\t",i);
        for(int j = 0 ; j < 50;j++)
        {

            int c_num = (int)user_center[i][0].lat;
            double m_dist = 1e10;
            for(int m = 1; m <= c_num; m++)
            {
                double dist = distance(user_center[i][m],loc_info[pred[j].loc]);
                if(dist < m_dist)
                    m_dist = dist;
            }
            fprintf(fp,"%d\t%lf\t%lf\t",pred[j].loc,m_dist,pred[j].val);
        }
        fprintf(fp,"\n");*/
        //fprintf(stdout,"num is %d\n",num);
        int* result = (int*)malloc(sizeof(int)*PRED_N);
        for(int j = 0; j < PRED_N; j++)
        {
            result[j] = pred[j].loc;
            //double dist = distance(user_center[i],loc_info[result[j]]);
        }
        qsort(result,PRED_N,sizeof(int),intComp);
        /*
        for(int j = 0; j < PRED_N; j++)
        {
            fprintf(re_fp,"%d\t",result[j]);
        }
        //fprintf(stdout,"\n\n\n");
        //qsort(tul[i] + 1,tul[i][0],sizeof(int),intComp);
        //sleep(5);*/
        double de;
        int comm_5 = intersect(tul[i]+1,tul[i][0],result,5);
        int comm_10 = intersect(tul[i]+1,tul[i][0],result,10);
        if(tul[i][0] > 0)
        {
            double cur_precision_5 = (double)comm_5/5;
            double cur_recall_5 = (double)comm_5/tul[i][0];
            double cur_precision_10 = (double)comm_10/10;
            double cur_recall_10 = (double)comm_10/tul[i][0];
            //double cur_f = 2*cur_precision*cur_recall/(cur_precision+cur_recall);
            fprintf(fp,"%d\t%d\t%lf\t%lf\t%lf\t%lf\n",i,ul[i][0],cur_precision_5,cur_recall_5,cur_precision_10,cur_recall_10);
        //fprintf(re_fp,"\n%d\t%d\t%lf\t%lf\n",comm,i,cur_precision,cur_recall);
            //*precision += cur_precision;
            //*recall += cur_recall;
            p5 += cur_precision_5;
            r5 += cur_recall_5;
            p10 += cur_precision_10;
            r10 += cur_recall_10;
            total_num ++;
        }
        free(pred);
        free(visited);
    }
    fclose(fp);
    p5 = p5/total_num;
    r5 = r5/total_num;
    p10 = p10/total_num;
    r10 = r10/total_num;
    fprintf(stdout,"P@5 is %lf,R@5 is %lf, P@10 is %lf,R@10 is %lf\n",p5,r5,p10,r10);
}


int binary_search(int *a, int n,int key)
{
    int high = n-1;
    int low = 0;
    //printf("a[0] is %d\t key is %d n is %d\n",a[0],key,n);
    while(low <= high)
    {
        int mid = (high + low)/2;
        if(a[mid]>key)
        {
            high = mid -1;
        }
        else if (a[mid]<key)
        {
            low = mid+1;
        }
        else
        {
            return mid;
        }
    }
    return -1;
}

int main(int argc, char** argv)
{
    fprintf(stdout,"Loading dataset...\n");
    getInput(argc,argv);
    fprintf(stdout,"Successfully loading dataset!\n");
    record_file = argv[10];

    FILE* fp = fopen(record_file,"a");
    double f;
    double precision,recall;
    //double alpha = 0.2;
    precision_recall(&precision,&recall,&f,test_num);
    fclose(fp);
    return 0;
}
