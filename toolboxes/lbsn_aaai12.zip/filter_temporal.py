#!/usr/bin/python
import math
import time
import datetime
import sys
import re

if (len(sys.argv) != 4):
    print 'Usage: ./location_temporal.py temporal_file out_file freq_threshold'
    sys.exit(-1)

sep = re.compile('\s+')
temporal_file = open(sys.argv[1],'r')
#ci_file = open(sys.argv[3],'w')
#rating_file = open(sys.argv[4],'w')
#spot_file = open(sys.argv[2],'r')
out_file = open(sys.argv[2],'w')
min_freq = int(sys.argv[3])


while True:
    tt = temporal_file.readline().rstrip()
    if not tt:
        break
    #print line
    line = sep.split(tt)
    loc_id = int(line[0])
    n = len(line)
    i = 2
    number = 0
    while i < n:
        number += int(line[i])
        i += 2
    if number < min_freq:
        continue
    else:
        w_line = line[0] + '\t' + str(number) + '\t'
        for i in range(1,len(line)):
            w_line += line[i] + '\t'
        w_line = w_line.rstrip() + '\n'
        out_file.write(w_line)
temporal_file.close()
out_file.close()

