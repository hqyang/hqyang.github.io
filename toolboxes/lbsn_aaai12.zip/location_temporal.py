#!/usr/bin/python
import time
import math
import datetime
import sys
import re

if (len(sys.argv) != 4):
    print 'Usage: ./location_temporal.py checkin_file temporal_file freq_threshold'
    sys.exit(-1)

'''
delta time t1 - t2 (mins)
'''
def deltatime(line,i,c_list,n_list,t1,t2):
    try:
        s1 = time.strptime(t1,'%Y-%m-%dT%H:%M:%SZ')
        s2 = time.strptime(t2,'%Y-%m-%dT%H:%M:%SZ')
        d1 = datetime.datetime(*s1[:6])
        d2 = datetime.datetime(*s2[:6])
        result = (d1 - d2).total_seconds()/60
        return result
    except:
        print c_list,n_list
        print line,i
        print t1,t2
        sys.exit(-1)

def timepassed(t1):
    s1 = time.strptime(t1,'%Y-%m-%dT%H:%M:%SZ')
    print s1
    result = int(s1.tm_year - 2009)*365 + s1.tm_yday
    return result

sep = re.compile('\s+')
checkin_file = open(sys.argv[1],'r')
#ci_file = open(sys.argv[3],'w')
#rating_file = open(sys.argv[4],'w')
#spot_file = open(sys.argv[2],'r')
out_file = open(sys.argv[2],'w')
min_freq = int(sys.argv[3])
'''
spot_info = {}

# ***** load spot info into dictionary ******#
while True:
    line = spot_file.readline().rstrip()
    if not line:
        break
    spot_id = int(line)
    spot_info[spot_id] = spot_file.readline().strip()
# ******** end load spot info ************* #
'''
# ******** load checkin file and calculate inter-checkin time and distance ******#
'''
def sigmoid(x):
    result = 1.0/(1 + math.exp(-x))
    return result
'''
loc_info = {}


while True:
    line = checkin_file.readline().rstrip()
    if not line:
        break
    print line
    uid = int(line)
    num_line = checkin_file.readline().strip()
    num = int(num_line)
    n_line = checkin_file.readline()
    i = 1
    c_list = sep.split(n_line)
    ## cur location id
    cur_id = int(c_list[1])
    time_pass = timepassed(c_list[0])
    #ci_info[cur_id] = 1
    ### init the dictionary
    if loc_info.has_key(cur_id):
        if loc_info[cur_id].has_key(time_pass):
            loc_info[cur_id][time_pass] += 1
        else:
            loc_info[cur_id][time_pass] = 1
    else:
        loc_info[cur_id] = {}

    while i < num:
        c_line = n_line
        n_line = checkin_file.readline()

        c_list = sep.split(c_line)
        n_list = sep.split(n_line)

        time_delta = deltatime(line,i,c_list,n_list,c_list[0],n_list[0])

        c_sid = int(c_list[1])
        n_sid = int(n_list[1])

        '''
        if not spot_info.has_key(c_sid) or not spot_info.has_key(n_sid):
            i += 1
            continue
        '''
        #time.sleep(5)
        #if time_delta > 3:
        time_pass = timepassed(n_list[0])
        if loc_info.has_key(n_sid):
            if loc_info[n_sid].has_key(time_pass):
                loc_info[n_sid][time_pass] += 1
            else:
                loc_info[n_sid][time_pass] = 1
        else:
            loc_info[n_sid] = {}
        i += 1

# **************  end load checkin file ***************** #
print len(loc_info.keys())
nn = 0
for loc_id in sorted(loc_info.keys()):
    nn += 1
    w_line = ''
    w_line += str(loc_id) + '\t'
    for date in sorted(loc_info[loc_id].keys()):
        w_line += str(date) + '\t' + str(loc_info[loc_id][date]) + '\t'
    w_line = w_line.rstrip() + '\n'
    out_file.write(w_line)
print nn
checkin_file.close()
out_file.close()

