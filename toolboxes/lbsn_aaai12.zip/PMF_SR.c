#include <stdio.h>
#include <math.h>
#include <time.h>
#include<sys/time.h>
#include <stdlib.h>
#include <unistd.h>
/****************************************************************************
 * define some global variables 
 * *************************************************************************/

// model input

#define UNUM 53944 // user number
#define LNUM 367149 // location number
//#define K 10 // latent dimension
#define lambda1 1 // regularization para for ||Y-LS\T||^2
//#define lambda2 0.02 // regularization para for L2 norm
#define PRED_N 20 // predict num
#define epsilon 1E-4 // smallest diff
//#define INIT_STEP 1 // init learing rate
#define LARGE_STEP_RATE 1.1 
#define SMALL_STEP_RATE 0.8 
#define MAX_STOP_NUM 8
//#define itoa 0.9
double itoa;
int **ul; // user location matrix
int **lu; // location user matrix
double **ulr; // user location rating matrix
double **lur; // location user rating matrix
double lambda2,INIT_STEP;
int K,it;
double **luf; // latent user vector
double **llf; // latent location vector
int is_write;
double **G;
FILE* gfp;
int **friend_info;
int **to_friend_info;
double **friend_val;

// for pred ranking
typedef struct
{
    double val;
    int loc;
}rating;


double sigmoid(double val)
{
    return 1.0/(1+exp(-val));
}

double dsigmoid(double val)
{
    double v = sigmoid(val);
    return v*(1.0-v);
}
int compare(const void * a, const void* b)
{
    rating *a1 = (rating*)a;
    rating *b1 = (rating*)b;
    if (a1->val > b1->val)
        return -1;
    else if (a1->val < b1->val)
        return 1;
    return 0;
}

int intComp(const void* a, const void* b)
{
    int* a1 = (int*)a;
    int* b1 = (int*)b;
    if( *a1 > *b1)
        return 1;
    else if (a1 < b1)
        return -1;
    return 0;
}

void initLatentVector()
{
    luf = (double **)malloc(sizeof(double*)*(UNUM+1));
    llf = (double **)malloc(sizeof(double*)*(LNUM+1));

    srand(time(NULL));
    for(int i = 1; i <= UNUM; i++)
    {
        luf[i] = (double*)malloc(sizeof(double)*K);
        for(int j = 0; j < K; j++)
        {
	    //luf[i][j] = 0.5;
            luf[i][j] = (double)rand()/RAND_MAX - 0.5;
        }
    }

    for(int i = 1; i <= LNUM; i++)
    {
        llf[i] = (double*)malloc(sizeof(double)*K);
        for(int j = 0; j < K; j++)
        {
	    //llf[i][j] = 0.5;
            llf[i][j] = (double)rand()/RAND_MAX - 0.5;
        }
    }
    
    G = (double**)malloc(sizeof(double*)*(UNUM+1));

    for(int i = 1; i <= UNUM; i++)
    {
        G[i] = (double*)malloc(sizeof(double)*(ul[i][0]+1));
        for(int j = 0; j < ul[i][0]+1;j++)
        {
            G[i][j] = 0;
        }
    }
}

void getInput(int argc,char **argv)
{
    FILE* fp = NULL;
    if (argc != 13)
    {
        fprintf(stderr,"./MF_v1 train_ci train_rating friend_file to_friend_file trust_val lambda2 K init_step itoa record ULatent LLatent\n");
        exit(-1);
    }
    
    itoa = atof(argv[9]);
    lambda2 = atof(argv[6]);
    K = atoi(argv[7]);
    INIT_STEP = atof(argv[8]);
    ul = (int **)malloc(sizeof(int*)*(UNUM+1));
    lu = (int**)malloc(sizeof(int*)*(LNUM+1));
    ulr = (double**)malloc(sizeof(double*)*(UNUM+1));
    lur = (double**)malloc(sizeof(double*)*(LNUM+1));
    friend_info = (int**)malloc(sizeof(int*)*(UNUM+1));
    to_friend_info = (int**)malloc(sizeof(int*)*(UNUM+1));
    friend_val = (double**)malloc(sizeof(double*)*(UNUM+1));
    int uid,num;
    uid = num = 0;
    int loc_id = 0;

    //friend_file
    
    fp = fopen(argv[3],"r");

    int line_no = 1;

    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[3]);
        exit(-1);
    }

    while(fscanf(fp,"%d %d",&uid,&num) != EOF)
    {
        while(line_no < uid)
        {
            friend_info[line_no] = (int*)malloc(sizeof(int)*1);
            friend_info[line_no][0] = 0;
            line_no ++;
        }

        friend_info[uid] = (int*)malloc(sizeof(int)*(num+1));
        friend_info[uid][0] = num;
        for(int i = 1; i <= num; i++)
        {
            int tmp;
            fscanf(fp,"%d",&tmp);
            friend_info[uid][i] = tmp;
        }
        line_no++;
    }
    fclose(fp);

    // to friend file
    fp = fopen(argv[4],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[4]);
        exit(-1);
    }
    
    line_no = 1;
    while(fscanf(fp,"%d %d",&uid,&num) != EOF)
    {
        while(line_no < uid)
        {
            to_friend_info[line_no] = (int*)malloc(sizeof(int)*1);
            to_friend_info[line_no++][0] = 0;
        }

        to_friend_info[uid] = (int*)malloc(sizeof(int)*(num+1));
        to_friend_info[uid][0] = num;
        for(int i = 1; i<= num;i++)
        {
            int tmp;
            fscanf(fp,"%d",&tmp);
            to_friend_info[uid][i] = tmp;
        }
        line_no++;
    }
    fclose(fp);
    
    // friend value file
    fp = fopen(argv[5],"r");
    if(fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[5]);
        exit(-1);
    }
    
    line_no = 1;
    while(fscanf(fp,"%d %d",&uid,&num) != EOF)
    {
        while(line_no < uid)
        {
            friend_val[line_no] = (double*)malloc(sizeof(double)*1);
            friend_val[line_no++][0] = 0;
        }

        friend_val[uid] = (double*)malloc(sizeof(double)*(num+1));
        friend_val[uid][0] = num;
        for(int i = 1; i<= num;i++)
        {
            double tmp;
            fscanf(fp,"%lf",&tmp);
            friend_val[uid][i] = tmp;
        }
        line_no++;
    }
    fclose(fp);
    
    fp = fopen(argv[1],"r");
    if (fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[1]);
        exit(-1);
    }

    while(fscanf(fp,"%d\t%d",&uid,&num) != EOF)
    {
        ul[uid] = (int*)malloc(sizeof(int)*(num+1));
        ul[uid][0] = num;
        int tmp;
        for(int i = 1; i <= num ; i++)
        {
            fscanf(fp,"%d",&tmp);
            ul[uid][i] = tmp;
        }
    }
    fclose(fp);

    //user location rating file
    fp = fopen(argv[2],"r");
    if (fp == NULL)
    {
        fprintf(stderr,"cannot open file %s\n",argv[2]);
        exit(-1);
    }

    while(fscanf(fp,"%d\t%d",&uid,&num) != EOF)
    {
        ulr[uid] = (double*)malloc(sizeof(double)*(num+1));
        ulr[uid][0] = num;
        double tmp;
        for(int i = 1; i <= num;i++)
        {
            fscanf(fp,"%lf",&tmp);
            ulr[uid][i] = tmp;
        }
    }

    fclose(fp);
    for (int i = 1; i <= LNUM; i++)
    {
        lu[i] = (int*)malloc(1*sizeof(int));
        lu[i][0] = 0;
        lur[i] = (double*) malloc(1*sizeof(double));
        lur[i][0] = 0.0;
    }
    
    for(int i = 1; i<= UNUM; i++)
    {
        for(int j = 1; j <= ul[i][0]; j++)
        {
            int loc_id = ul[i][j];
            lu[loc_id][0]++;
            lu[loc_id] = (int*)realloc(lu[loc_id],(lu[loc_id][0]+1)*sizeof(int));
            lu[loc_id][lu[loc_id][0]] = i;

            lur[loc_id] = (double*)realloc(lur[loc_id],(lu[loc_id][0]+1)*sizeof(double));
            lur[loc_id][lu[loc_id][0]] = ulr[i][j];
        }
    }

}

double UL(int uid,int loc_id)
{
    double result = 0;
    for(int i= 0; i < K; i++)
    {
        result += luf[uid][i]*llf[loc_id][i];
    }
    return result;
}

double frobeniusL(int loc_id)
{
    double result = 0;
    for(int i = 0; i < K; i++)
    {
        result += llf[loc_id][i] * llf[loc_id][i];
    }
    return result;
}


double frobeniusU(int uid)
{
    double result = 0;
    for(int i = 0; i < K ; i++)
    {
        result += luf[uid][i] * luf[uid][i];
    }
    return result;
}

double square(double x)
{
    return x*x;
}

double lossValue()
{
    double result = 0;
    for(int i = 1; i <= UNUM; i++)
    {
        int num = ul[i][0];

        for(int j = 1; j <= num; j++)
        {
            double pred = UL(i,ul[i][j]);
            double real = ulr[i][j];
            double temp = (sigmoid(pred) - real) * (sigmoid(pred) - real);
            result += temp;
        }
    }
    fprintf(gfp,"square loss is %lf\n",result/2); 
    
    double unorm = 0;
    for(int i = 1 ; i <= UNUM; i++)
    {
        unorm += frobeniusU(i);
    }

    result += lambda2 * unorm;
    fprintf(gfp,"UNorm is %lf\t",unorm);
    double lnorm = 0;
    for(int j = 1; j <= LNUM; j++)
    {
        lnorm += frobeniusL(j);
    }
    result += lnorm * lambda2;
    fprintf(gfp,"LNorm is %lf\t",lnorm);
    
    double social_norm = 0;
    for(int i = 1; i <= UNUM; i++)
    {
        for(int f = 1; f <= friend_info[i][0];f++)
        {
            int fid = friend_info[i][f];
            double simi = friend_val[i][f];
            for(int k = 0; k < K; k++)
            {
                social_norm += simi*square(luf[i][k] - luf[fid][k]);
            }
        }
    }
    fprintf(gfp,"social norm is %lf\t",social_norm);
    fprintf(gfp,"regularization is %lf\n",(unorm + lnorm)*lambda2/2 + social_norm*itoa/2);
    result += social_norm * itoa;
    result = result/2;
    return result;
}

//# of intersect of sorted vector
int intersect(int* real,int n1,int* pred,int n2,double*hlu)
{
    double t = 0;
    int num = 0;
    int i,j;
    i = j = 0;
    while( i < n1 && j < n2)
    {
        int a1=real[i];
        int a2=pred[j];
        if(a1 < a2)
            i++;
        else if(a1 > a2)
            j++;
        else
        {
            t += 1/pow(2,4*j);
            i++;j++;num++;
        }
    }
    *hlu = t;
    //printf("hlu is %lf\n",*hlu);
    return num;
}

void computeGR()
{
    for(int i = 1; i <= UNUM;i++)
    {
        int num = ul[i][0];
        for(int j = 1; j <= num; j++)
        {
            int loc_id = ul[i][j];
            G[i][j] = UL(i,loc_id);
        }
    
    }
}

int binary_search(int *a, int n,int key)
{
    int high = n-1;
    int low = 0;
    //printf("a[0] is %d\t key is %d n is %d\n",a[0],key,n);
    while(low <= high)
    {
        int mid = (high + low)/2;
        if(a[mid]>key)
        {
            high = mid -1;
        }
        else if (a[mid]<key)
        {
            low = mid+1;
        }
        else
        {
            return mid;
        }
    }
    return -1;
}


void updateU(double step_len)
{
    for(int i = 1; i <= UNUM; i++)
    {
        double *grad = (double*)malloc(sizeof(double)*K);
        for(int k = 0 ; k < K; k++)
            grad[k] = 0;
        int num = ul[i][0];
        for(int j = 1; j<= num; j++)
        {
            int loc_id = ul[i][j];
            double pred_val = G[i][j];
            double dg = dsigmoid(pred_val);
            dg *= sigmoid(pred_val) - ulr[i][j];
            double bias = dg;
            for(int k = 0; k < K; k++)
            {
                grad[k] += bias*(llf[loc_id][k]);           
            }
        }
        
        for(int f = 1; f <= friend_info[i][0]; f++)
        {
            int fid = friend_info[i][f];
            double simi = friend_val[i][f];
            for(int k = 0; k < K; k++)
                grad[k] += itoa * simi *(luf[i][k] - luf[fid][k]);
        }

        for(int k = 0; k < K; k++)
        {
            grad[k] += lambda2*luf[i][k];
        }

        for(int k = 0; k < K;k++)
        {
            luf[i][k] -= step_len * grad[k];
        }
        free(grad);
    }
}

void updateL(double step_len)
{
    for(int j = 1; j <= LNUM; j++)
    {
        double *grad = (double*)malloc(sizeof(double)*K);
        for(int k = 0; k < K; k++)
            grad[k] = 0;
        
        int num = lu[j][0];
        for(int i = 1; i <= num; i++)
        {
            int uid = lu[j][i];
            int pos = binary_search(ul[uid]+1,ul[uid][0],j);
            pos++;
            if(pos < 1 || pos > ul[uid][0])
            {
                fprintf(stderr,"error find index%d\n",pos);
                exit(-1);
            }
            double pred_val = G[uid][pos];
            double dg = dsigmoid(pred_val);
            dg *= sigmoid(pred_val) - ulr[uid][pos];
            double bias = dg;
            for(int k = 0 ; k < K ; k++)
            {
                grad[k] += bias*luf[uid][k];
            }
        }
        for(int k = 0 ; k < K;k++)
        {   
            grad[k] += lambda2 * llf[j][k];
        }

        for(int k = 0; k < K; k++)
        {
            llf[j][k] -= step_len * grad[k];
        }
        free(grad);
    }
}

void writeModel(int argc, char** argv)
{
    FILE* tfp = fopen(argv[11],"w");
    for( int i = 1; i <= UNUM; i++)
    {
        fprintf(tfp,"%d\t",i);
        for(int k = 0;k < K-1;k++)
        {
            fprintf(tfp,"%lf\t",luf[i][k]);
        }
        fprintf(tfp,"%lf\n",luf[i][K-1]);
    }
    fclose(tfp);

    tfp = fopen(argv[12],"w");
    for(int i =1;i <=LNUM;i++)
    {
        fprintf(tfp,"%d\t",i);
        for(int k = 0;  k < K-1;k++)
        {
            fprintf(tfp,"%lf\t",llf[i][k]);
        }
        fprintf(tfp,"%lf\n",llf[i][K-1]);
    }
    fclose(tfp);
    is_write = 1;
}

int main(int argc, char** argv)
{
    is_write = 0;
    it = 1;
    gfp = fopen(argv[10],"a");
    fprintf(gfp,"Loading dataset...\n");
    getInput(argc,argv);
    fprintf(gfp,"Successfully loading dataset!\n");

    fprintf(gfp,"Initialization parameter...\n");
    initLatentVector();
    fprintf(gfp,"done!\n");
    double loss;

    int stopno = 0;
    double step_len = INIT_STEP;
    double precision,recall;
    double old_precision,old_recall,old_loss;
    double diff1,diff2,diff_loss;
    old_precision = old_recall = 0;
    old_loss = 1E10;
    fprintf(gfp,"K is %d,lambda is %lf,beta is %lf,init step_len is %lf\n",K,lambda2,itoa,INIT_STEP);
    while(stopno < MAX_STOP_NUM)
    {
        //precision_recall(&precision,&recall);
        computeGR();
        loss = lossValue();

        //diff1 = precision - old_precision;
        //diff2 = recall - old_recall;
        diff_loss = old_loss - loss;
        //print info
        fprintf(gfp,"****************************************************************\n");
        //fprintf(stdout,"iteration:%d\n precision:%lf\trecall:%lf\ntraining loss:%lf\n",it++,precision,recall,loss);
        fprintf(gfp,"iteration:%d\ntraining loss:%lf\n",it++,loss);
        fprintf(gfp,"\nloss diff:%lf\n",diff_loss);
        //fprintf(stdout,"\nprecision diff:%lf\trecall diff:%lf\nloss diff:%lf\n",diff1,diff2,diff_loss);
        fprintf(gfp,"****************************************************************\n");

	if ( it > 100)
	{
	   writeModel(argc,argv);
           break;
	}       
        if (loss < 5000)
        {
	    writeModel(argc,argv);
            break;
        }
        if(diff_loss < 0)
        {
            stopno++;
            if(step_len > 0.0001)
                step_len = step_len * SMALL_STEP_RATE;
        }
        else if(diff_loss < 1)
        {
	    writeModel(argc,argv);
            break;
        }
    
        updateU(step_len);
        updateL(step_len);
        //updateAlpha(step_len);
        //updateS(step_len);
        old_precision = precision;
        old_recall = recall;
        old_loss = loss;
        if(it %10 == 0)
	    step_len *= 0.8;
    }
    if (! writeModel)	
      writeModel(argc,argv);
    fclose(gfp);
    return 0;
}
