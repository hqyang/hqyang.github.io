#!/usr/bin/python

import re
import sys

alpha = 0.05
if(len(sys.argv)!= 4):
    print 'Usage: ./friend_simi.py friend_file ci_file output'
    sys.exit(-1)


sep = re.compile('\s+')
friend_file = open(sys.argv[1],'r')
ci_file = open(sys.argv[2],'r')

output = open(sys.argv[3],'w')

fri_info = {}
ci_info={}
while True:
    line = friend_file.readline().rstrip()
    if not line:
        break
    t = sep.split(line)
    uid = int(t[0])
    t = t[2:]

    temp = []
    for i in range(0,len(t)):
        temp.append(int(t[i]))

    fri_info[uid] = temp

friend_file.close()

while True:
    line = ci_file.readline().rstrip()
    if not line:
        break
    t = sep.split(line)
    uid = int(t[0])
    ci_info[uid] = t[2:]

ci_file.close()

for uid in sorted(fri_info.keys()):
    fri_list = fri_info[uid]
    fri_list.sort()
    num = len(fri_list)
    uset = set(ci_info[uid])
    ufset = set(fri_list)
    w_line = str(uid) + '\t' + str(num) + '\t'
    for i in range(0,num):
        fid = fri_list[i]
        fset = set(ci_info[fid])
        total = len(uset.union(fset))
        comm = len(uset.intersection(fset))
        simi = 0
        simi += (1-alpha)*float(comm)/total
        ffset = set(fri_info[fid])
        total = len(ufset.union(ffset))
        comm = len(ufset.intersection(ffset))
        simi += alpha * float(comm)/total
        w_line += str(simi) + '\t'
    w_line = w_line.rstrip() + '\n'
    output.write(w_line)

output.close()

