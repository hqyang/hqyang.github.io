http://www.cse.cuhk.edu.hk/~ccheng/data/Gowalla_data.tar.gz


new_user_centroid.py: generate user center for each user


PMF_SR.c: PMF with Social Regularization 


PFM.cpp: Probabilistic factor model (Ma hao's SIGIR 11)


final_evalModel.c: combine both geo and MF 


full_ci: user location matrix
full_rating: user location frequency corresponding to full_ci file


idx_friend: each user's friend info


idx_friend_simi: each user's similarity to his friends corresponding to idx_friend


friend_simi.py: compute friend similarity. (Ye Mao's SIGIR'11 paper)

