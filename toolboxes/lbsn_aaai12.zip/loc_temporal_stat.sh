#!/bin/bash
if [ $# -ne 1 ]; then
    echo "./loc_temporal_stat filename";
    exit 0;
fi

filename=$1
aa=`wc -l $filename|awk '{printf("%d", $1);}'`
echo $aa
max_num=`awk '{first=$3;last=$(NF-1);if(max < last-first){max=last-first;}}END{print max}' <$filename`
echo $max_num
declare -i mm=$max_num
echo $mm
awk '
BEGIN{
for(i=0;i<= mm;i++){
    s[i]=0;
}
print i;
}
{first=$3; 
for(i=3;i <=NF; i+=2){
    if(i != 3){
        p[$i-first] += $(i+1) + p[$i-first-1];
    }else{
        p[$i-first] += $(i+1);
    }
    for(j=$i-first;i+2 < NF && j<$(i+2)-first;j++){
        p[$j] = p[$i-first];
    }
}
}END{
for ( k in p){
    print k,p[k]/NR;
}
}
' < $filename
