#!/usr/bin/python
import time
import math
import datetime
import sys
import re

if (len(sys.argv) != 7):
    print 'Usage: ./distance.py spot_file train_ci train_rating output dist_thresold num_thresold'
    sys.exit(-1)


sep = re.compile('\s+')

radius = 6378.16
def distance(lat1,lng1,lat2,lng2):
    a1 = 0
    a2 = 0
    try:
        c = 180/math.pi
        a1 = math.sin(lat1/c) * math.sin(lat2/c)
        a2 = math.cos(lat1/c) * math.cos(lat2/c) * math.cos(lng2/c - lng1/c)
        #print a1, a2
        result = radius * math.acos(a1 + a2)
        return result
    except:
        if (math.fabs(a1 + a2 - 1.0) < 1e-10):
            return 0
        else:
            print lat1,lng1,lat2,lng2
            print a1,a2
            print a1 + a2
            sys.exit(-1)

class Loc:
    def __init__(self,loc_id,freq):
        self.loc_id = loc_id
        self.freq = freq

class Region:
    def __init__(self,c_lat,c_lng,t_freq,var_lat,var_lng,loc_list):
        self.c_lat =  c_lat
        self.c_lng = c_lng
        self.t_freq = t_freq
        self.var_lat = var_lat
        self.var_lng = var_lng
        self.loc_list = loc_list

spot_file = open(sys.argv[1],'r')

spot_info = {}
while True:
    line = spot_file.readline().rstrip()
    if not line:
        break
    tokens = sep.split(line)
    loc = int(tokens[0])
    spot_info[loc] = []
    spot_info[loc].append(float(tokens[1]))
    spot_info[loc].append(float(tokens[2]))

spot_file.close()
train_ci = open(sys.argv[2],'r')
train_rating = open(sys.argv[3],'r')
output = open(sys.argv[4],'w')

loc_detail = open("center_detail.txt","w")
rank_d = open("rank_top","w")
while True:
    ci_line = train_ci.readline().rstrip()
    if not ci_line:
        break

    total_ci_num = 0
    rating_line = train_rating.readline().rstrip()
    ci_t = sep.split(ci_line)
    rating_t = sep.split(rating_line)
    uid = int(ci_t[0])
    print uid
    train_num = int(ci_t[1])
    ci_t = ci_t[2:]
    rating_t = rating_t[2:]

    Rating = []
    for i in range(0,train_num):
        loc_id = int(ci_t[i])
        freq = int(rating_t[i])
        total_ci_num += freq
        Rating.append(Loc(loc_id,freq))

    Rating = sorted(Rating,key = lambda obj:obj.freq, reverse = True)
    rank_line = str(uid) + '\t' + str(train_num) + '\t' + str(total_ci_num) + '\t'
    for i in range(0,train_num):
        rank_line += str(Rating[i].freq) + '\t'
    rank_line = rank_line.rstrip() + '\n'
    rank_d.write(rank_line)
    flag = []
    ## init each loc as unlabeled
    for i in range(0,train_num):
        #loc_id = int(ci_t[i])
        flag.append(1)

    Region_list = []

    for i in range(0,train_num):
        loc_id = Rating[i].loc_id
        #t_freq = 0
        temp_Loc = []
        loc_list = list()
        if flag[i]:
            #t_freq = Rating[i].freq
            temp_Loc.append(Rating[i])
            loc_list.append(Rating[i])
            cur_pos = spot_info[loc_id]
            flag[i] = 0
            for j in range(i+1,train_num):
                if flag[j]:
                    temp_loc_id = Rating[j].loc_id
                    temp_pos = spot_info[temp_loc_id]
                    dist = distance(cur_pos[0],cur_pos[1],temp_pos[0],temp_pos[1])
                    if(dist <= float(sys.argv[5])):
                        flag[j] = 0
                        temp_Loc.append(Rating[j])
                        loc_list.append(Rating[j])
            total_lat = 0
            total_lng = 0
            total_sqr_lat = 0
            total_sqr_lng = 0
            total_freq = 0
            if len(temp_Loc) <= 1:
                continue
            for k in range(0,len(temp_Loc)):
                freq = temp_Loc[k].freq
                pos_id = temp_Loc[k].loc_id
                total_freq += freq
                total_sqr_lat += freq*spot_info[pos_id][0]*spot_info[pos_id][0]
                total_lat += freq*spot_info[pos_id][0]
                total_lng += freq*spot_info[pos_id][1]
                total_sqr_lng += freq*spot_info[pos_id][1]*spot_info[pos_id][1]
            c_lat = total_lat/total_freq
            c_lng = total_lng/total_freq
            var_lat = total_sqr_lat/(total_freq-1) - total_freq*c_lat*c_lat/(total_freq-1)
            var_lng = total_sqr_lng/(total_freq-1) - total_freq*c_lng*c_lng/(total_freq-1)
            Region_list.append(Region(c_lat,c_lng,total_freq,var_lat,var_lng,loc_list))

    Region_list = sorted(Region_list,key = lambda obj:obj.t_freq, reverse = True)
    #print total_ci_num
    threshold = total_ci_num*float(sys.argv[6])
    w_line = str(uid) + '\t'
    loc_detail.write('user ' + str(uid) + '\n')
    temp_line = ''
    region_num = 0
    for i in range(0,len(Region_list)):
        freq = Region_list[i].t_freq
        if freq >= threshold:
            d_line = ''
            region_num += 1
            temp_line += str(Region_list[i].c_lat) + '\t' + str(Region_list[i].var_lat) + '\t' + str(Region_list[i].c_lng) + '\t' + str(Region_list[i].var_lng) + '\t' + str(freq) + '\t'
            loc_list = Region_list[i].loc_list
            for j in range(0,len(loc_list)):
                d_line += str(loc_list[j].loc_id) + '\t' + str(loc_list[j].freq) + '\t'
            d_line += '\n'
            loc_detail.write(d_line)
    w_line += str(region_num) + '\t' + temp_line.rstrip() + '\n'
    output.write(w_line)
rank_d.close()
output.close()
train_ci.close()
train_rating.close()
