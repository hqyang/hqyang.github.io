#!/usr/bin/python
import sys
import re
if(len(sys.argv)!= 3):
    print 'Usage: ./stat_temporal temporal_file output'
    sys.exit(-1)

sep = re.compile('\s+')
time_th = 1000
temporal_file = open(sys.argv[1],'r')
output = open(sys.argv[2],'w')
stat = {}
max_num = 1000;
for i in range(0, max_num + 1):
    stat[i] = 0
tmax = 0
tt = [0] * time_th
print len(tt)
while True:
    line = temporal_file.readline().rstrip()
    if not line:
        break
    tokens = sep.split(line)
    tokens = tokens[2:]
    i = 0;
    freq = {}
    bias = int(tokens[0]);
    max_cur = int(tokens[len(tokens)-2]) - bias;
    cal_num = time_th - bias;
    if cal_num > tmax:
        tmax = cal_num
    while i < len(tokens):
        day = int(tokens[i]) - bias
        if (day != 0):
            freq[day] = int(tokens[i+1]) + freq[day-1]
        else:
            freq[day] = int(tokens[i+1])

        if i+2 < len(tokens):
            for j in range(day+1,int(tokens[i+2])-bias):
                freq[j] = freq[day];
        i += 2
    ### modify
    for i in range(0,cal_num +1):
        tt[i] += 1
        if(freq.has_key(i)):
            stat[i] += freq[i]
        else:
            stat[i] += freq[max_cur]
print tmax,tt[0]
w_line = '0\t0\n'
output.write(w_line)
for key in sorted(stat.keys()):
    if key > tmax or tt[key] < 5000:
        continue
    print key,tt[key]
    ave = float(stat[key])/tt[key]
    w_line = str(key+1) + '\t' + str(ave) + '\n'
    output.write(w_line)
temporal_file.close()
output.close()
