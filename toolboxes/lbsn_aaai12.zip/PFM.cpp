#include <cstdio>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <map>
#include <vector>

/****************************************************************************
 * define some global variables 
 * *************************************************************************/
typedef std::map<int, double> Map;
typedef std::vector<Map> Vector;
typedef std::map<int, double>::iterator Iterator;

// model input
int nuser, nmovie, nrating; // number of users, number of movies, n of ratings
Vector ui; // vector of map from mid to rating
Vector iu; // vector of map from uid to rating
int K; // latent feature dimension
int **tui; // user item matrix for testing
double **tuir; // user item rating matrix for testing
FILE* gfp;
// model paramters
double **luf; // latent user feature
double **lmf; // latent movie feature
double **lufactor; // multiplicative factor for latent users features
double **lmfactor; // multiplicative factor for latent items features
double lambda = 0.01; // regulization parameter
double epsilon = 0.002; // learning rate
int is_write = 0;
double alpha = 20.0;
double beta = 0.2;
void initParam(void) {
    luf = (double **)malloc(sizeof(double *) * nuser);
    lmf = (double **)malloc(sizeof(double *) * nmovie);
    for (int i = 1; i < nuser; i++) {
        luf[i] = (double *) malloc(sizeof(double) * K);
    }
    for (int i = 1; i < nmovie; i++) {
        lmf[i] = (double *) malloc(sizeof(double) * K);
    }
    srand(time(NULL));
    for (int i = 1; i < nuser; i++)
        for (int j = 0; j < K; j++)
            luf[i][j] = ((double)rand()/RAND_MAX);
    for (int i = 1; i < nmovie; i++)
        for (int j = 0; j < K; j++)
            lmf[i][j] = ((double)rand()/RAND_MAX);

    // Allocate multiplicative factors
    lufactor = (double **)malloc(sizeof(double*) * nuser);
    lmfactor = (double **)malloc(sizeof(double*) * nmovie);
    for (int i = 1; i < nuser; i++) {
        lufactor[i] = (double*)malloc(sizeof(double) * (K+1));
    }
    for (int i = 1; i < nmovie; i++) {
        lmfactor[i] = (double*)malloc(sizeof(double) * (K+1));
    }
    fprintf(stderr, "gradients done\n");
}

void getinput(int argc, char **argv) {
    FILE *paramf, *userf, *ratingf;
    int cu = 0, cm = 0, cc = 0; // current user, current movie, current count
    double cr = 0;

    // 11 parameters
    if (argc < 5) {
        fprintf(stderr, "./online count rating.in user.test rating.test [alpha] [beta] U L K record_file\n");
        exit(1);
    }

    if ((paramf = fopen(argv[1], "r")) == NULL) {
        fprintf(stderr, "%s cannot be opened!\n", argv[1]);
        exit(1);
    }
    fscanf(paramf, "%d %d %d %lf %lf", &nuser, &nmovie, &K, &lambda, &epsilon);
    fclose(paramf);
    nuser++;
    nmovie++;
    K = atoi(argv[9]);
    if (argc > 5)
        alpha = atof(argv[5]);
    if (argc > 6)
        beta = atof(argv[6]);

    // Initialize ui iu uir
    for (int i = 0; i < nuser; i++)
        ui.push_back(Map());
    for (int i = 0; i < nmovie; i++)
        iu.push_back(Map());
    tui = (int **)malloc(sizeof(int *) * nuser);
    tuir = (double **)malloc(sizeof(double *) * nuser);

    if ((ratingf = fopen(argv[2], "r")) == NULL) {
        fprintf(stderr, "%s cannot be opened!\n", argv[2]);
        exit(1);
    }
    while (fscanf(ratingf, "%d %d %lf", &cu, &cm, &cr) != EOF) {
        ui[cu][cm] = cr;
        iu[cm][cu] = cr;
    }
    fclose(ratingf);

    if ((userf = fopen(argv[3], "r")) == NULL) {
        fprintf(stderr, "%s cannot be opened!\n", argv[5]);
        exit(1);
    }
    while (fscanf(userf, "%d %d", &cu, &cc) != EOF) {
        tui[cu] = (int *) malloc(sizeof(int)*(cc+1));
        tui[cu][0] = cc;
        int tmp;
        for (int i = 1; i <= cc; i++) {
            fscanf(userf, "%d", &tmp);
            tui[cu][i] = tmp;
        }
    }
    fclose(userf);

    if ((ratingf = fopen(argv[4], "r")) == NULL) {
        fprintf(stderr, "%s cannot be opened!\n", argv[6]);
        exit(1);
    }
    while (fscanf(ratingf, "%d %d", &cu, &cc) != EOF) {
        tuir[cu] = (double *)malloc(sizeof(double) * (cc+1));
        tuir[cu][0] = cc;
        double tmp;
        for (int i = 1; i <= cc; i++) {
            fscanf(ratingf, "%lf", &tmp);
            tuir[cu][i] = tmp;
        }
    }
    fclose(ratingf);
}

// return dot product of user feature and movie feature
double dotproduct(int user, int movie) {
    double result = 0;
    for (int i = 0; i < K; i++) {
        result += luf[user][i]*lmf[movie][i];
    }
    return result;
}

// sigmoid function
double sigmoid(double value) {
    return (1.0/(1+exp(-value)));
}

// derivative of sigmoid function
double dsigmoid(double value) {
    double v = sigmoid(value);
    return v*(1.0-v);
}

int comp(const void *d1, const void *d2) {
    if ((*(double*)d1) > (*(double*)d2))
        return -1;
    else if ((*(double*)d1) < (*(double*)d2))
        return 1;
    else
        return 0;
}

double trainMAE(void) {
    double result = 0;
    int count = 0;
    Iterator it;
    for (int i = 1; i < nuser; i++) 
    {
        for (it = ui[i].begin(); it != ui[i].end(); it++) 
        {
            count++;
            double pred = dotproduct(i, it->first);
            //if(pred <1) pred=1;
            result += fabs(pred - ui[i][it->first]);
        }
    }
    return result/count;
}


double MAE(void) {
    double result = 0;
    int count = 0;
    for (int i = 1; i < nuser; i++) {
        int numm = tui[i][0];
        count += numm;
        for (int j = 1; j <= numm; j++) {
            double pred = (dotproduct(i, tui[i][j]));
            //if (pred > 5) pred = 5;
            //if (pred < 1) pred = 1;
            result += fabs(pred - (tuir[i][j]));
            //result += fabs(1 - tuir[i][j]);
        }
    }
    return result/count;
}

double RMSE(void) {
    double result = 0;
    int count = 0;
    for (int i = 1; i < nuser; i++) {
        int numm = tui[i][0];
        count += numm;
        for (int j = 1; j <= numm; j++) {
            double pred = sigmoid(dotproduct(i, tui[i][j]));
            pred = pred*4+1;
            result += (pred - (tuir[i][j]*4+1))*(pred - (tuir[i][j]*4+1));
        }
    }
    return result/count;
}

// update lufactor
void updateUFactor(void) {
    for (int i = 1; i < nuser; i++) {
        Iterator it;
        Map tmpY;
        for (it = ui[i].begin(); it != ui[i].end(); it++) {
            tmpY[it->first] = ui[i][it->first] / dotproduct(i, it->first);
        }
        for (int k = 0; k < K; k++) {
            double sumUpper = 0, sumLower = 0;
            for (it = ui[i].begin(); it != ui[i].end(); it++) {
                sumUpper += lmf[it->first][k] * tmpY[it->first];
                sumLower += lmf[it->first][k];
            }
            sumUpper += (alpha - 1)/luf[i][k];
            sumLower += 1/beta;
            lufactor[i][k] = sumUpper / sumLower;
        }
    }
}

// update lmfactor
void updateVFactor(void) {
    for (int i = 1; i < nmovie; i++) {
        Iterator it;
        Map tmpY;
        for (it = iu[i].begin(); it != iu[i].end(); it++) {
            tmpY[it->first] = iu[i][it->first] / dotproduct(it->first, i);
        }
        for (int k = 0; k < K; k++) {
            double sumUpper = 0, sumLower = 0;
            for (it = iu[i].begin(); it != iu[i].end(); it++) {
                sumUpper += luf[it->first][k] * tmpY[it->first];
                sumLower += luf[it->first][k];
            }
            sumUpper += (alpha - 1)/lmf[i][k];
            sumLower += 1/beta;
            lmfactor[i][k] = sumUpper / sumLower;
        }
    }
}

void updateU(int user) {
    for (int j = 0; j < K; j++) {
        luf[user][j] *= lufactor[user][j];
    }
}

void updateV(int movie) {
    for (int j = 0; j < K; j++) {
        lmf[movie][j] *= lmfactor[movie][j];
    }
}

void writeModel(int argc, char** argv)
{
    FILE* tfp = fopen(argv[7],"w");
    for( int i = 1; i < nuser; i++)
    {
        fprintf(tfp,"%d\t",i);
        for(int k = 0;k < K-1;k++)
        {
            fprintf(tfp,"%lf\t",luf[i][k]);
        }
        fprintf(tfp,"%lf\n",luf[i][K-1]);
    }
    fclose(tfp);

    tfp = fopen(argv[8],"w");
    for(int i =1;i < nmovie;i++)
    {
        fprintf(tfp,"%d\t",i);
        for(int k = 0;  k < K-1;k++)
        {
            fprintf(tfp,"%lf\t",lmf[i][k]);
        }
        fprintf(tfp,"%lf\n",lmf[i][K-1]);
    }
    fclose(tfp);
    is_write = 1;
}

int main(int argc, char **argv) {
    int iteration = 1;
    getinput(argc, argv);
    initParam();
    double lastMAE, currentMAE;

    gfp = fopen(argv[10],"a");
    int stopno = 0;
    lastMAE = 100000;
    fprintf(gfp,"alpha is %lf, beta is %lf, K is %d\n",alpha,beta,K);
    while(iteration <= 50 && stopno <= 20) {
        updateUFactor();
        updateVFactor();
        for (int i = 1; i < nuser; i++) {
            updateU(i);
        }
        for (int j = 1; j < nmovie; j++) {
            updateV(j);
        }
        currentMAE = MAE();
        fprintf(stdout,"%d\t%lf\t%lf\n", iteration++, currentMAE,trainMAE());
        if (fabs(lastMAE-currentMAE) < 1e-10) {
        //    beta /= 10.0;
            stopno++;
        }
        lastMAE = currentMAE;
    }
    writeModel(argc,argv);
    return 0;
}

