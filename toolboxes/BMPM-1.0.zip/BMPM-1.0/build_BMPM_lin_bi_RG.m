function [alpha_lin, a, b] = build_BMPM_lin_bi_RG(Mx,My,Covx,Covy,beta0,gauss_assump,ita0,tol,RGiter)
% build_BMPM_lin_bi_RG - build a linear biased minimax probability machine (BMPM) for binary classification 
%                            using the Rosen Gradient (RG) projection method. 
%
% [alpha_lin, a, b] = build_BMPM_lin_bi_RG(Mx,My,Covx,Covy,beta0,gauss_assump,ita0,tol,RGiter)
%
% The algorithm finds the minimum error minimax probabilistic decision hyperplane between two classes of points x and y
%
% H = {z | a'*z = b}
%
% that maximizes alpha_lin(lower bound on the probability of correct classification of future data for class x, while  
% keeps the lower bound on the probability of correct classification of future data for class y at an acceptable level, 
% beta0, subject to the constraint a<>0 and
%
% inf_(x~DX) Pr(a'x >= b) >= alpha_lin
% inf_(y~DY) Pr(a'y <= b) >= beta0
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for x, resp. y, having
% a given mean Mx, resp. My, and a given covariance matrix Covx, resp. Covy (if gauss_assump=1, only 
% Gaussian distributions are considered). Mx, My, Covx and Covy can, e.g., be estimated from data using
% the classical plug-in estimates.
%
%
% The inputs are
% Mx           - (estimated) mean of class x (column vector)
% My           - (estimated) mean of class y (column vector)
% Covx         - (estimated) covariance matrix of class x
% Covy         - (estimated) covariance matrix of class y
% beta0        - lower bound on the probability of correct classification of future data for class y 
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not; more details about this 
%                can be found in the reference
% ita0         - internal parameter for the initial step of the RG method. 
%                enter -1 to use default value 0.1
% tol          - relative tolerance level for RG methods
%                enter -1 to use default value: 1.000000e-006
% RGiter       - maximum number of iterations for RG method
%                enter -1 to use  default value: 5000
%
% The outputs are
% alpha_lin    - lower bound on the probability of correct classification of future data for class x
% a, b         - model parameters for the linear BMPM
%

%%%%%% set default values if needed %%%%%%
if ita0==-1
    ita0=0.1
end
if tol==-1
    tol=1.00000e-05;
end
if RGiter==-1
    RGiter=5000;
end

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     Begin the Rosen Gradient Projection Method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A = Mx-My;
d = size(A,1);
a=0.6*ones(d,1);
i1=find(abs(A)==max(abs(A)));
a(i1(1))=(1-sum(a.*A)+a(i1(1))*A(i1(1)))/A((i1));    
gradi=ones(d,1);
epoch=1;%ita=0.1;
I=eye(d,d);
ita=ita0;
da = 10*tol;
while and(epoch<=RGiter,da>tol)
     a_old = a;
     Vx=a'*Covx*a; Vy=a'*Covy*a;
     t1=kbeta0*sqrt(Vx)/sqrt(Vy)*Covy*a;
     t2=(1-kbeta0*sqrt(Vy))/sqrt(Vx)*Covx*a;
     gradi=-1/Vx*(t1+t2);
     P=I-A*inv(A'*A)*A';
     gradi=P*gradi;
     %find optimal ita;
     a1=a+ita*gradi;
     Vy_dg(epoch)=Vy;
     kalpha(epoch)=(1-kbeta0*sqrt(Vy))/sqrt(Vx);
     if(epoch>1)
         if(kalpha(epoch)-kalpha(epoch-1)>tol)
             a=a1;
         else
             ita=ita/2;
             a=a+ita*gradi;
        end
    else
        a=a1;
    end
    epoch=epoch+1;
    da = norm(a-a_old);
    if epoch/90 ~= round(epoch/90)
       fprintf('.');
    else
       fprintf('\n');
    end
end
fprintf('\n');
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Vx=a'*Covx*a; Vy=a'*Covy*a;
%%  Calculate b, both values in the bracket should be the same
b = mean([(a'*Mx + kbeta0*sqrt(Vy)-1), (a'*My + kbeta0*sqrt(Vy))]);

ka=(1-kbeta0*sqrt(Vy))/sqrt(Vx);
kalpha = max([ka, 0]);
if(gauss_assump)
    alpha_lin=normcdf(kalpha,0,1);
else
    alpha_lin=kalpha^2/(kalpha^2+1);
end
