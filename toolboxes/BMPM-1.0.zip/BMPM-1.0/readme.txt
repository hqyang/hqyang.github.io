-----------------------------------------
-----------------------------------------
 Instructions for using BMPM, version 1.0
-----------------------------------------
-----------------------------------------
 

- unzip BMPM-1.0.zip

- run 'bmpm_demo' in matlab, in the corresponding directroy
  the procedure is performed step by step interactively, you may press any key to continue it	

- the m-file 'bmpm_demo.m' is commented and explains how to use the code with your own data

- the other m-files are commented as well and can directly be used to train and test the BMPM with your own data



An overview of the files:

build_BMPM_lin_bi_RG.m
-----------------------------
to train a biased minimax probability machine (BMPM, linear version) for binary classification using Rosen Gradient projection method

build_BMPM_k_bi_PM.m
-------------------------------
to train a biased minimax probability machine (BMPM, kernelized version) for binary classification using Parametric Method to solve the Fractional Programming problem

build_robBMPM_lin_bi_RG.m
-----------------------------
to train a robust biased minimax probability machine (BMPM, linear version) for binary classification using Rosen Gradient projection method

build_robBMPM_k_bi_PM.m
-------------------------------
to train a robust biased minimax probability machine (BMPM, kernelized version) for binary classification using Parametric Method to solve the Fractional Programming problem


eval_lin_bi.m
----------------------
evaluate all minimax probability machines (linear version), including Minimax Probability Machine (MPM), Biased Minimax Probability Machine (BMPM), Minimum Error Minimax 
Probability Machine (MEMPM), for binary classification

eval_k_bi.m
----------------------
evaluate all minimax probability machines (kernelized version), including Minimax Probability Machine (MPM), Biased Minimax Probability Machine (BMPM), Minimum Error Minimax 
Probability Machine (MEMPM), for binary classification


bmpm.mat:
------------
contains the data for the demonstration in .mat format


bmpm_demo.m:
-------------
demonstration for using the bmpm toolbox

--------------------------------------------------------------------------------------------------------
We thank Gert R. G. Lanckriet for providing the Matlab source code of MPM.  For convenient comparison, 
we implement the BMPM using the same data format to the MPM.  

Please email us if you have any comments or problems: hqyang@cse.cuhk.edu.hk and kzhuang@cse.cuhk.edu.hk
--------------------------------------------------------------------------------------------------------



