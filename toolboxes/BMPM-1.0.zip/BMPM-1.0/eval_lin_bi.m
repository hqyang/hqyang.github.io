function [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_lin_bi(data,n_train,a,b)
% eval_lin_bi - evaluate all minimax probability machines (linear version), including 
%               Minimum Error Minimax Probability Machine (MEMPM), Biased Minimax 
%               Probability Machine (BMPM), Minimax Probability Machine (MPM) for 
%               binary classification
%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_lin_bi(data,n_train,a,b)
%
%
% The inputs are
% data      - an (n_train + n_test + n_unlab) x (d+1) matrix, where
%                  * rows correspond to datapoints:
%                          -> the first 'n_train' rows correspond to 'n_train' training  points
%                             (points with known class label, used to train the MPM)
%                          -> the next  'n_test'  rows correspond to 'n_test'  test      points
%                             (points with known class label, not used to train the MPM)
%                          -> the next  'n_unlab' rows correspond to 'n_unlab' unlabeled points
%                             (points with unknown class label, to be labeled)
%                   * the the columns 1, ..., d correspond to the given features of the data points 
%                     (so, d is the dimension of the input space)
%                   * column d+1 corresponds to the class label:
%                          -> +1 for a point known to be in class +1
%                          -> -1 for a point known to be in class -1
%                          -> 0  for a point for which the class is unknown
%                          
% n_train   - number of training data points
% a, b      - model parameters for the classification model (a is a d-vector of weights; b is the offset)
%
% The outputs are
%   ng_tr   - number of well-classified trainig data points
%   pg_tr   - percentage of well-classified trainig data points (-1 if no training points)
%   ng_t    - number of well-classified test data points
%   pg_t    - percentage of well-classified test data points (-1 if no test points)
%   ng_trt  - number of well-classified data points (training + test)
%   pg_trt  - percentage of well-classified data points, training + test (-1 if no training + test points)
%   lab     - an n_unlab-vector containing the class-labels of the unlabelled data points, after classification
%   pg_trx  - percentage of well-classified training data points for class x (-1 if no training points for class x)
%   pg_try  - percentage of well-classified training data points for class y (-1 if no training points for class y) 
%   pg_tx   - percentage of well-classified testig data points for class x (-1 if no test points for class x)
%   pg_ty   - percentage of well-classified testig data points for class y (-1 if no test points for class y)
%   pg_trtx - percentage of well-classified data points for class x, training + test (-1 if no training + test points for class x)
%   pg_trty - percentage of well-classified data points for class y, training + test (-1 if no training + test points for class y)
%


if (nargin ~= 4) % check correct number of arguments
    help eval_lin_bi
else
    
% determine dimension of the input space
d = size(data,2)-1;
% determine number of training, test and unlabeled data points
n = size(data,1);
n_trt = length(find(abs(data(:,d+1))==1));
n_test = n_trt - n_train;
n_unlab = n - n_trt;
    
% compute outputs
Xtrain_sub = data(find(data(1:n_train,d+1)==1),1:d);
Ytrain_sub = data(find(data(1:n_train,d+1)==-1),1:d);
sx = size(Xtrain_sub);
sy = size(Ytrain_sub);


nw_tr = sum(abs(sign(sign(data(1:n_train,1:d)*a - b*ones(n_train,1)) - data(1:n_train,d+1))));
Xnw_tr = sum(abs(sign(sign(Xtrain_sub(:,1:d)*a - b*ones(sx(1),1)) - 1)));
Ynw_tr = sum(abs(sign(sign(Ytrain_sub(:,1:d)*a - b*ones(sy(1),1)) + 1)));
ng_tr = n_train - nw_tr;
if n_train == 0
    pg_tr = -1;
else
    pg_tr = 100*ng_tr/n_train;
end

if sx(1) == 0
    pg_trx = -1;
else
    pg_trx = 100-100*Xnw_tr/sx(1);
end

if sy(1) == 0
    pg_try = -1;
else
    pg_try = 100-100*Ynw_tr/sy(1);
end

Xtest_sub = data(find(data(1+n_train:n_trt,d+1)==1)+n_train,1:d);
Ytest_sub = data(find(data(1+n_train:n_trt,d+1)==-1)+n_train,1:d);
sx_test = size(Xtest_sub);
sy_test = size(Ytest_sub);

nw_t = sum(abs(sign(sign(data(n_train+1:n_trt,1:d)*a - b*ones(n_test,1)) - data(n_train+1:n_trt,d+1))));
Xnw_tst = sum(abs(sign(sign(Xtest_sub(:,1:d)*a - b*ones(sx_test(1),1)) - 1)));
Ynw_tst = sum(abs(sign(sign(Ytest_sub(:,1:d)*a - b*ones(sy_test(1),1)) + 1)));

ng_t = n_test - nw_t;
if n_test == 0
    pg_t = -1;
else
    pg_t = 100*ng_t/n_test;
end

if sx_test(1) == 0
    pg_tx = -1;
else
    pg_tx = 100-100*Xnw_tst/sx_test(1);
end

if sy_test(1) == 0
    pg_ty = -1;
else
    pg_ty = 100-100*Ynw_tst/sy_test(1);
end

nw_trt = sum(abs(sign(sign(data(1:n_trt,1:d)*a - b*ones(n_trt,1)) - data(1:n_trt,d+1))));
ng_trt = n_trt - nw_trt;
if n_trt == 0
    pg_trt = -1;
else
    pg_trt = 100*ng_trt/n_trt;
end

if sx(1)+sx_test(1) == 0
    pg_trtx = -1;
else
    pg_trtx = 100-100*(Xnw_tr+Xnw_tst)/(sx(1)+sx_test(1));
end

if sy(1)+sy_test(1) == 0
    pg_trty = -1;
else
    pg_trty = 100-100*(Ynw_tr+Ynw_tst)/(sy(1)+sy_test(1));
end

if n_unlab == 0
    lab = [];
else
    lab = sign(data(n_trt+1:n,1:d)*a - b*ones(n_unlab,1));
end

end