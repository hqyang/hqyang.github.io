echo off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%       Biased Minimax Probability Machine (BMPM)                     %%%%%%                    
%%%%%%        Toolbox Demonstrations For Toy Dataset                       %%%%%%                                    
%%%%%%                                                                     %%%%%%
%%%%%%          1. linear BMPM                                             %%%%%%
%%%%%%          2. robust linear BMPM                                      %%%%%%
%%%%%%          3. kernelized BMPM                                         %%%%%%                                                   
%%%%%%          4. robust kernelized BMPM                                  %%%%%%
%%%%%%                                                                     %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Yang Haiqin  March 2004                                               %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%   Data Format:                                                      %%%%%%
%%%%%%       [ .......features...... | class ]                             %%%%%%
%%%%%%       - one row per data point                                      %%%%%%
%%%%%%       - one column per feature                                      %%%%%%
%%%%%%       - 'class' is the class-label: -1 / +1                         %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on; 


clc
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
%   Load the training data and plot the data
%   Note: You can load your own dataset here
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue 
echo off;

%%%%%% to GET THE TOYDATA                                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% load a variable 'data' containing the toydata
load bmpm
%% class +1 : 60 points generated from a gaussian with mean [0.0, 3.0]^T and covariance
%%            matrix as [1.0, 0.0; 0.0, 1.5]
%%                       
%% class -1 : 60 points generated from a gaussian with mean [0.0, -2.0]^T and covariance
%%            matrix as [1.5, 0.0; 0.0, 1.5]
                             
%%%%%% to GET YOUR OWN DATA                             %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%data = [ .......features...... | class ];


%% total number of datapoints
n = size(data,1);
%% dimension of the data
d = size(data,2)-1;
%% assign the features of all datapoints of class +1 to variable 'X'
X = data(find(data(:,d+1)==1),1:d);
%% assign the features of all datapoints of class -1 to variable 'Y'
Y = data(find(data(:,d+1)==-1),1:d);


%%%%%% to PLOT THE TOYDATA                                  %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot class +1 as +'s and class -1 as squares
figure(1)
plot(X(:,1), X(:,2), 'k+', Y(:,1), Y(:,2), 'ms');
title('Data: Class +1 depicted as + and Class -1 depicted as squares');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-4 4 -5 6])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% split data in training and test data             %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% split TOYDATA in training and test data             %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% training data = first 60 data points in 'data' (being 30 points of class +1
%% and 30 points of class -1)
training_points = [1:60]';
test_points = [61:120]';

%%%%%% split YOUR OWN DATA in training and test data       %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% training_points = vector containing row numbers in 'data' corresponding to training points;
% test_points     = vector containing row numbers in 'data' corresponding to test points;

%% all training data points
data_train = data(training_points,:);
%% number of training data points
n_train = size(data_train,1);
%% all test data points
data_test = data(test_points,:);
%% training data features for class +1 : Xtrain
Xtrain = data_train(find(data_train(:,d+1)==1),1:d);
%% training data features for class -1 : Ytrain
Ytrain = data_train(find(data_train(:,d+1)==-1),1:d);
%% test data features for class +1 : Xtest
Xtest = data_test(find(data_test(:,d+1)==1),1:d);
%% test data features for class -1 : Ytest
Ytest = data_test(find(data_test(:,d+1)==-1),1:d);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      1.  LINEAR BMPM                               %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using linear BMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% estimate mean and covariance matrix from the training data points  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% class +1
xhat = mean(Xtrain)'; 
Sx = cov(Xtrain,1);
%% class -1
yhat = mean(Ytrain)';
Sy = cov(Ytrain,1);

beta0 = 0.8;
gauss_assump = 1;

%%%%%%  train linear BMPM for TOYDATA                                      %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[alpha_lin, a, b] = build_BMPM_lin_bi_RG(xhat,yhat,Sx,Sy,beta0,gauss_assump,0.1,1e-5,5000);
%%
%% notice that we make the gaussian assumption here (6th input is equal to 1)
%%
%% input 7-9 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_BMPM_lin_bi_RG'

%%%%%%  train linear BMPM for YOUR OWN DATA                               %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% [alpha_lin, a, b] = build_BMPM_lin_bi_RG(xhat,yhat,Sx,Sy,beta0,gauss_assump,0.1,1e-5,5000)
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..6.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%%
%% ..7.., ..8.., ..9.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_BMPM_lin_bi_RG'

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Plot the linear BMPM and display its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot training data for class +1 as +'s and for class -1 as squares
figure(2)
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-4 4 -5 6])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
%% plot decision line in black dash-dot
h1 = plot([-4 4],[(b+4*a(1,1))/a(2,1) (b-4*a(1,1))/a(2,1)],'k-.');

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a,b);

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a,b);
%% for more details about this function: 'help eval_lin_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

%% display relevant values
disp('Underbound on correct classification of future data-Class 1:');
disp(alpha_lin*100);
disp('Setting lower bound on correct classification of future data-Class 2:');
disp(beta0*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      2.  ROBUST LINEAR BMPM                        %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using robust linear BMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  estimate mean and covariance matrix from the training data points %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% class +1
xhat = mean(Xtrain)';
Sx = cov(Xtrain,1);
%% class -1
yhat = mean(Ytrain)';
Sy = cov(Ytrain,1);

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% since we know the true mean and covariance matrices, we can calculate nu_x, nu_y
%% rho_x and rho_y as folows for the toy example:
Mx = [0 3]'; Covx = [1 0; 0 1.5];
My = [0 -2]'; Covy = [1.5, 0; 0 1.5];
%% nu_x -- uncertainty in mean for class +1
nu_x = sqrt((xhat-Mx)'*inv(Covx)*(xhat-Mx));
%% nu_y -- uncertainty in mean for class -1
nu_y = sqrt((yhat-My)'*inv(Covy)*(yhat-My));
%% rho_x -- uncertainty in covariance matrix for class +1
rho_x = norm(Sx-Covx,'fro');
%% rho_y -- uncertainty in covariance matrix for class -1
rho_y = norm(Sy-Covy,'fro');

beta0 = 0.8;
gauss_assump = 1;

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for YOUR DATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for real data, the true mean and covariance matrices are unknown
%%
%% nu_x, nu_y, rho_x and rho_y could be estimated using resampling methods, 
%% the central limit theorem or cross-validation
%%
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;

%%%%%%  train robust linear BMPM for TOYDATA                              %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[alpha_lin_rob, a_rob, b_rob] = build_robBMPM_lin_bi_RG(xhat,yhat,Sx,Sy,beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,0.1,1e-5,5000);
%%
%% notice that we make the gaussian assumption here (10th input is equal to 1)
%%
%% input 11-13 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_robBMPM_lin_bi_RG'

%%%%%%  train robust linear BMPM for YOUR OWN DATA                        %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_lin_rob, a_rob, b_rob] = build_robBMPM_lin_bi_RG(xhat,yhat,Sx,Sy,beta0,nu_x,nu_y,rho_x,rho_y,..10..,..11..,..12..,..13..);
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..10.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%%
%% ..11.., ..12.., ..13.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robBMPM_lin_bi_RG'

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty]=eval_lin_bi([data_train;data_test],n_train,a_rob,b_rob);

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty]=eval_lin_bi([data_train;data_test],n_train,a_rob,b_rob);
%% for more details about this function: 'help eval_lin_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Plot the robust linear BMPM and display its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot decision line in red dashed line
hold on;
h2 = plot([-4 4],[(b_rob+4*a_rob(1,1))/a_rob(2,1) (b_rob-4*a_rob(1,1))/a_rob(2,1)],'r--');

legend([h1, h2],'BMPM','rob-BMPM');

%% display relevant values
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_lin_rob*100);
disp('Setting lower bound on correct classification of future data-Class 2:');
disp(beta0*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      3.  KERNELIZED BMPM                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using kernelized BMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  build the kernel matrix (aka Gram matrix)                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  K has the following block structure:                              %%%%%%%
%%%%%%                   K = [K_tr K_trt; K_trt^T K_t]                    %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  where            K_ij = Phi(x_i)^T Phi(x_j)                       %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  for i,j = 1,... , n_train, n_train + 1, ..., n_train + n_test     %%%%%%%
%%%%%%      with n_train: the number of training data points              %%%%%%%
%%%%%%           n_test : the number of test     data points              %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  So, K can be split into a ``training-data block'' K_tr, a ``mixed %%%%%%%
%%%%%%  block'' K_trt and a ``test-data block'' K_t                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%  build K for TOYDATA, using a linear kernel function:              %%%%%%%
%%%%%%  K_ij = x_i^T x_j                                                  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build K for YOUR OWN DATA                                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%K = a positive semi-definite matrix;
%% here, you can use whichever way you prefer to construct a kernel matrix, 
%% e.g. through the evaluation of a kernel function, by using dynamic
%%      programming to build a similarity measure between the different data points, 
%%      by using a linear combination of given kernel matrices, ...
%%
%% e.g., to build a kernel matrix for YOUR OWN DATA, using a linear kernel
%% function, you could use the following line of code:
%% K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';


%%%%%%  build the corresponding label vector                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  the order of the labels should correspond to the order of the     %%%%%%%
%%%%%%  training and test points in the kernel matrx K                    %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
labels = [data_train(:,d+1);data_test(:,d+1)];

beta0 = 0.8;
gauss_assump = 1;

%%%%%%  train kernelized BMPM for TOYDATA                                 %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[alpha_k, gamma_k, b_k] = build_BMPM_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),beta0,gauss_assump,1e-6,1e-5,50);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% notice that we make the gaussian assumption here (4rd input is equal to 1)
%%
%% input 5-7 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_BMPM_k_bi_PM'

%%%%%%  train kernelized BMPM for YOUR OWN DATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_k, gamma_k, b_k] = build_BMPM_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),beta0,..4..,..5..,..6..,..7..);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..4.. is '1' if you assume that both classes are Gaussian distributed in
%%       the feature space (i.e., the space where the mapped data points Phi(z)
%%       live), '0' for the general case
%%
%% ..5.., ..6.., ..7.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_BMPM_k_bi_PM'

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty, pg_trtx, pg_trty] = eval_k_bi(K,labels,gamma_k,b_k);

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty, pg_trtx, pg_trty] = eval_k_bi(K,labels,gamma_k,b_k);
%% for more details about this function: 'help eval_k_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Display the kernelized BMPM and its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;
%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3)
hold on
syms w x y ax ay f;
f = subs(f,-b_k);
for i=1:n_train;
    f = f + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_k(i),data_train(i,1),data_train(i,2)});
end;
%% plot decision curve corresponding to kernelized BMPM solved by f=0.
ezplot(f,[-4 4]);
%% plot decision line corresponding to linear BMPM in black dash-dot
plot([-4 4],[(b+4*a(1,1))/a(2,1) (b-4*a(1,1))/a(2,1)],'k-.');
legend('kernel','linear')
%% plot training data for class +1 as +'s and for class -1 as squares
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-4 4 -5 6])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
  
%% display relevant values
disp('Underbound on correct classification of future data-Class 1:');
disp(alpha_k*100);
disp('Setting lower bound on correct classification of future data-Class 2:');
disp(beta0*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      4.  ROBUST KERNELIZED BMPM                    %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using robust kernelized BMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  build the kernel matrix (aka Gram matrix)                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  K has the following block structure:                              %%%%%%%
%%%%%%                   K = [K_tr K_trt; K_trt^T K_t]                    %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  where            K_ij = Phi(x_i)^T Phi(x_j)                       %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  for i,j = 1,... , n_train, n_train + 1, ..., n_train + n_test     %%%%%%%
%%%%%%      with n_train: the number of training data points              %%%%%%%
%%%%%%           n_test : the number of test     data points              %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  So, K can be split into a ``training-data block'' K_tr, a ``mixed %%%%%%%
%%%%%%  block'' K_trt and a ``test-data block'' K_t                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%  build K for TOYDATA, using a linear kernel function:              %%%%%%%
%%%%%%  K_ij = x_i^T x_j                                                  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build K for YOUR OWN DATA                                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%K = a positive semi-definite matrix;
%% here, you can use whichever way you prefer to construct a kernel matrix, 
%% e.g. through the evaluation of a kernel function, by using dynamic
%%      programming to build a similarity measure between the different data points, 
%%      by using a linear combination of given kernel matrices, ...
%%
%% e.g., to build a kernel matrix for YOUR OWN DATA, using a linear kernel
%% function, you could use the following line of code:
%% K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build the corresponding label vector                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  the order of the labels should correspond to the order of the     %%%%%%%
%%%%%%  training and test points in the kernel matrx K                    %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
labels = [data_train(:,d+1);data_test(:,d+1)];


%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Since we use a linear kernel for the TOYDATA here, we use as values for those
%% parameters the values we earlier assigned to them for the robust linear MEMPM
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;

beta0 = 0.8;
gauss_assump = 1;

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for YOUR DATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for real data, the true mean and covariance matrices are unknown in the
%% feature space
%%
%% nu_x, nu_y, rho_x and rho_y could be estimated using resampling methods, 
%% the central limit theorem or cross-validation
%%
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;

%%%%%%  train kernelized BMPM for TOYDATA                                 %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[alpha_kr, gamma_kr, b_kr] = build_robBMPM_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,1e-6,1e-5,50);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% notice that we make the gaussian assumption here (8th input is equal to 1)
%%
%% input 9-11 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_robBMPM_k_bi_PM'

%%%%%%  train kernelized BMPM for YOUR OWN DATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [alpha_kr, gamma_kr, b_kr] = build_robBMPM_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),beta0,nu_x,nu_y,rho_x,rho_y,..8..,..9..,..10..,..11..);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..8.. is '1' if you assume that both classes are Gaussian distributed in
%%       the feature space (i.e., the space where the mapped data points Phi(z)
%%       live), '0' for the general case
%%
%% ..9.., ..10.., ..11.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMPM_k_binclass_LSreg'

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,labels,gamma_kr,b_kr);

%%%%%% evaluate performance of the BMPM                     %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,labels,gamma_kr,b_kr);
%% for more details about this function: 'help eval_k_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Display the robust kernelized BMPM and its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4)
hold on
syms w x y ax ay f;
f = subs(f,-b_kr);
for i=1:n_train;
    f = f + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_kr(i),data_train(i,1),data_train(i,2)});
end;
%% plot decision curve corresponding to kernelized BMPM solved by f=0.
ezplot(f,[-4 4]);
%% plot decision line corresponding to robust linear BMPM in red dashed line
plot([-4 4],[(b_rob+4*a_rob(1,1))/a_rob(2,1) (b_rob-4*a_rob(1,1))/a_rob(2,1)],'r--');
legend('rob-kernel','rob-linear');

%% plot training data for class +1 as +'s and for class -1 as squares
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-4 4 -4 6])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');

%% display relevant values
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_kr*100);
disp('Setting lower bound on correct classification of future data-Class 2:');
disp(beta0*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);