function [alpha_k, vgamma, b] = build_robBMPM_k_bi_PM(Kmat,Y,beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,PMiter);
% build_robBMPM_k_bi_PM - build a robust biased minimax probability machine (BMPM, kernelized version) for binary classification 
%                      using iterative parametric method (PM) to solve the Fractional Programming problem.
%
% [alpha_k, vgamma, b] = build_robBMPM_k_bi_PM(Kmat,Y,kbeta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,PMiter);
%
%
% The algorithm finds the biased minimax probabilistic decision hyperplane between two classes of points phi(x) and phi(y)
%
% H = {phi(z) | a'*phi(z) = b}
%
% that maximizes alpha_k (lower bound on the probability of correct classification of future data for the class x), while  
% keeps the lower bound on the probability of correct classification of future data for class y at an acceptable level, 
% beta0, subject to the constraint a<>0 and
%
% inf_(phi(x)~DX) Pr(a'phi(x) >= b) >= alpha_k
% inf_(phi(y)~DY) Pr(a'phi(y) <= b) >= beta0
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for phi(x), resp. phi(y), having
% a given mean and covariance matrix (if gauss_assump=1, only Gaussian distributions are considered). Mean and 
% covariance matrix for both class phi(x) and class phi(y) are estimated from data using the classical plug-in estimates.
%
% The mapping phi(z) is not explicitely needed. For the input, only the Gram matrix Kmat, specifying 
% Kmat(z_1,z_2)=phi(z_1)'*phi(z_2) is needed. For the output, not a is returned, but instead the weights
% of the decomposition of a in the span of the data points.
%
% The inputs are
% Kmat         - an n-by-n Gram Matrix, corresponding to the n data points (n = Nx + Ny)
% Y            - an n-vector containing the labels of the n data points (+1 for class x, -1 for class y)
% beta0        - lower bound on the probability of correct classification of future data for class y 
% nu_x,nu_y    - robustness parameter quantizing uncertainty in the mean of class x, resp. y 
%                 (0 for no robustness)
% rho_x,rho_y  - robustness parameter quantizing uncertainty in the covariance for class x, resp. y
%                 (0 for no robustness)
% gauss_assump - 1 if phi(x) and phi(y) are assumed to be Gaussian distributed / 0 if not (this will only
%                influence the optimal value of alfa, not the position of the optimal hyperplane; more details
%                about this can be found in the reference)
% algoparam    - internal parameter to determine the amount of regularization added to LSmat, the systemmatrix
%                for the least squares step; technically, algopar * eye(size(LSmat)) is added to LSmat
%                enter -1 to use default value: 1.000000e-006
% tol          - relative tolerance level for least squares iterations
%                enter -1 to use default value: 1.000000e-006
% PMiter       - maximum number of iterations for least squares iterations
%                enter -1 to use  default value: 50
%
% The outputs are
% alpha_k      - lower bound on the probability of correct classification of future data for the biased class
% vgamma, b    - model parameters for the BMPM (vgamma is an n-vector of weights, b is the offset)
%
%


%%%%%%%%%%%%% INITIALIZATION STEPS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% set default values if needed %%%%%%
if algoparam==-1
    algoparam=1.000000e-006;
end
if tol==-1
    tol=1.000000e-006;
end
if PMiter==-1
    PMiter=50;
end

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end

%%%%%%% determine data points in both classes %%%%%%
Xclass = find(Y==1);
Yclass = find(Y==-1);

%%%%%%% number of data points in both classes %%%%%%
Nx = length(Xclass);
Ny = length(Yclass);

%%%%%%% total number of data points %%%%%%
N = Nx + Ny;

%%%%%% build matrices needed for iterative least squares %%%%%%
% rearrange kernel matrix
XY_perm=[Xclass;Yclass];
K = Kmat(XY_perm,XY_perm);
% build Lx and Ly
Kx = K(1:Nx,:);
Ky = K(Nx+1:N,:);
tx = mean(Kx)';
ty = mean(Ky)';
tKx = Kx - ones(Nx,1)*tx';
tKy = Ky - ones(Ny,1)*ty';
% vector gamma0
d = (tx - ty);
gamma0 = d/(d'*d);
% matrix F -- orthogonal matrix whose columns span the subspace of vectors orthogonal to gamma0
f = zeros(1,N-1);
[maxel,maxind]=max(d);
for i=1:maxind-1,
   f(1,i) = -d(i,1)/maxel;
end
for i=maxind:N-1,
   f(1,i) = -d(i+1,1)/maxel;
end
IN_1 = eye(N-1);
F = [IN_1(1:maxind-1,:); f; IN_1(maxind:N-1,:)];

% Parametric FP
% Making the matrices positive definite, the extra term algoparam*... is
% useful when rho_x=0, or rho_y=0.
Vsol = 1/Nx*tKx'*tKx+rho_x*K+algoparam*eye(size(tKx,2));
Wsol = 1/Ny*tKy'*tKy+rho_y*K+algoparam*eye(size(tKy,2));

% matrices for least squares step
Csq = F'*Vsol*F;
Cc = F'*Vsol*gamma0;
Dsq = F'*Wsol*F;
Dd = F'*Wsol*gamma0;

rkbeta0 = kbeta0+nu_y;
%%%%%%%%%%%%% Outer iterations  %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Parametric Method %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize lambda, assign lambda to a small positive value
lambda = min(rkbeta0/5,0.1);
outiter = 1;
l_d(outiter) = lambda;
rel_ql_ch = 10*tol;

while and(rel_ql_ch > tol, outiter<PMiter)
    
	% matrices for least squares step
	
	%%%%%%%%%%%%% ITERATIVE LEAST SQUARES %%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%% (see Section 2.3 in reference) %%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%% initialization %%%%%%
	eta_k = 1;
	xi_k = 1;
	iter = 1;
	rel_obj_ch = 10*tol;
	z_k = 0;
	
	%%%%%% Inner iterations %%%%%%%
	while and(rel_obj_ch > tol,iter<50),
        LSmat = Csq*lambda*lambda/eta_k + Dsq*rkbeta0*rkbeta0/xi_k;
        LSvect = -(Cc*lambda*lambda/eta_k + Dd*rkbeta0*rkbeta0/xi_k);
        z_k = pinv(LSmat)*LSvect;
        gamma_t = F*z_k+gamma0;
        t1 = gamma_t'*Vsol*gamma_t;
        t2 = gamma_t'*Wsol*gamma_t;
        tt = eta_k+lambda*lambda*t1/eta_k+xi_k+rkbeta0*rkbeta0*t2/xi_k;
        eta_kp1 = lambda*sqrt(t1);
        xi_kp1 = rkbeta0*sqrt(t2);
        Lobj_old = 2*(eta_k + xi_k);
        Lobj_new = 2*(eta_kp1 + xi_kp1);
        rel_obj_ch = abs(Lobj_new-Lobj_old)/abs(Lobj_old);
        iter = iter + 1;
        eta_k = eta_kp1;
        xi_k = xi_kp1;
        tt = eta_k+lambda*lambda*t1/eta_k+xi_k+rkbeta0*rkbeta0*t2/xi_k;
    end
	rel_ql_ch = abs(1-xi_k-eta_k);
	lambda = (1-xi_k)/eta_k*lambda;
	outiter = outiter + 1;
	l_d(outiter) = lambda;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% since \lambda increases after each iteration and the maximal
    %% value of alfa_temp is 1, we can terminate the iteration beforehand
    %% if (1-alfa_temp) < tol
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    tl = max([lambda-nu_x, 0]);
    if gauss_assump==1
        alfa_temp = normcdf(tl,0,1);
	else
        alfa_temp = tl^2/(1+tl^2);
	end
	if (1-alfa_temp<tol) break; end;
    if iter/90 ~= round(iter/90)
        fprintf('.');
    else
        fprintf('\n');
    end
end;
fprintf('\n');
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vgamma = gamma0 + F*z_k;
s = sqrt(vgamma'*Vsol*vgamma);
t = sqrt(vgamma'*Wsol*vgamma);
%%  Calculate b, both values in the bracket should be the same
b = mean([(vgamma'*tx-1+rkbeta0*t), (vgamma'*ty+rkbeta0*t)]);
kappa = (1-rkbeta0*t)/s;
tl = max([kappa-nu_x, 0]);
if gauss_assump==1
    alpha_k = normcdf(tl,0,1);
else
    alpha_k = tl^2/(1+tl^2);
end

% put gamma in the right order (such that the weights correspond to the resp.
% entries of Kmat rather than K)
vgamma(XY_perm) = vgamma;
