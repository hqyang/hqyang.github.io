function [alpha_lin, a, b] = build_robBMPM_lin_bi_RG(Mx,My,Covx,Covy,beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,ita0,tol,RGiter)
% build_robBMPM_lin_bi_RG - build a robust linear biased minimax probability machine (BMPM) 
%                               for binary classification by the Rosen Gradient (RG) projection method. 
%
% build_robBMPM_lin_bi_RG(Mx,My,Covx,Covy,beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,ita0,tol,RGiter)
%
% The algorithm finds the minimum error minimax probabilistic decision hyperplane between two classes of points x and y
%
% H = {z | a'*z = b}
%
% that maximizes alpha_lin(lower bound on the probability of correct classification of future data for class x, while  
% keeps the lower bound on the probability of correct classification of future data for class y at an acceptable level, 
% beta0, subject to the constraint a<>0 and
%
% inf_(x~DX) Pr(a'x >= b) >= alpha_lin
% inf_(y~DY) Pr(a'y <= b) >= beta0
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for x, resp. y, having
% a mean and covariance matrix in the convex set V, resp. W (if gauss_assump=1, only Gaussian distributions are 
% considered):
%
% V = {mean(x),cov(x) | (mean(x)-Mx)^T inv(cov(x)) (mean(x)-Mx) <= nu_x^2,
%                        ||cov(x)-Covx||_F <= rho_x}
% W = {mean(y),cov(y) | (mean(y)-My)^T inv(cov(y)) (mean(y)-My) <= nu_y^2,
%                        ||cov(y)-Covy||_F <= rho_y}
% 
% where Mx and Covx, resp. My and Covy, are the estimates for the mean and covariance matrix of class x, resp. class y, 
% provided in the input; ||...||_F denotes the Frobenius norm.
%
%
% The inputs are
% Mx           - (estimated) mean of class x (column vector)
% My           - (estimated) mean of class y (column vector)
% Covx         - (estimated) covariance matrix of class x
% Covy         - (estimated) covariance matrix of class y
% beta0        - lower bound on the probability of correct classification of future data for class y 
% nu_x,nu_y    - robustness parameter quantizing uncertainty in the mean of class x, resp. y 
%                 (0 for no robustness)
% rho_x,rho_y   - robustness parameter quantizing uncertainty in the covariance for class x, resp. y
%                 (0 for no robustness)
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not; more details about this 
%                can be found in the reference
% ita0         - internal parameter for the initial step of the RG method. 
%                enter -1 to use default value 0.1
% tol          - relative tolerance level for RG methods
%                enter -1 to use default value: 1.0000e-006
% RGiter       - maximum number of iterations for RG method
%                enter -1 to use  default value: 5000
%
% The outputs are
% alpha_lin    - lower bound on the probability of correct classification of future data for class x
% a, b         - model parameters for the linear BMPM
%

%%%%%% set default values if needed %%%%%%
if ita0==-1
    ita0=0.1
end
if tol==-1
    tol=1.000000e-006;
end
if RGiter==-1
    RGiter=5000;
end

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     Begin the Rosen Gradient Projection Method 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A = Mx - My;
d = size(A,1);
a=0.6*ones(d,1);
i1=find(abs(A)==max(abs(A)));
a(i1(1))=(1-sum(a.*A)+a(i1(1))*A(i1(1)))/A((i1));    
gradi=ones(d,1);
epoch=1;
I=eye(d,d);
ita=ita0;
da = 10*tol;

Sxp = Covx+rho_x*I;
Syp = Covy+rho_y*I;
rketap = kbeta0+nu_y;

while and(epoch<=RGiter,da>tol)
     a_old = a;
     Vx=a'*Sxp*a; Vy=a'*Syp*a;
     t1=rketap*sqrt(Vx)/sqrt(Vy)*Syp*a;
     t2=(1-rketap*sqrt(Vy))/sqrt(Vx)*Sxp*a;
     gradi=-1/Vx*(t1+t2);
     P=I-A*inv(A'*A)*A';
     gradi=P*gradi;
     %find optimal ita;
     a1=a+ita*gradi;
     Vy_dg(epoch)=Vy;
     kalpha(epoch)=(1-rketap*sqrt(Vy))/sqrt(Vx);
     if(epoch>1)
         if(kalpha(epoch)-kalpha(epoch-1)>tol)
                     a=a1;
         else
             ita=ita/2;
             a=a+ita*gradi;
        end
    else
        a=a1;
    end
    epoch=epoch+1;
    da = norm(a-a_old);
    if epoch/90 ~= round(epoch/90)
       fprintf('.');
    else
       fprintf('\n');
    end
end
fprintf('\n');
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Vx=a'*Sxp*a; Vy=a'*Syp*a;
%%  Calculate b, both values in the bracket should be the same
b = mean([(a'*Mx + rketap*sqrt(Vy) -1), (a'*My + rketap*sqrt(Vy))]);

kappa = (1-rketap*sqrt(Vy))/sqrt(Vx);  
kalpha= max([kappa-nu_x,0]);
if(gauss_assump)
    alpha_lin=normcdf(kalpha,0,1);
else
    alpha_lin=kalpha^2/(kalpha^2+1);
end
