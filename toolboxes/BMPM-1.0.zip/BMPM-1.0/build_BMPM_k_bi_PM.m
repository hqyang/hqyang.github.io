function [alpha_k, vgamma, b] = build_BMPM_k_bi_PM(Kmat,Y,beta0,gauss_assump,algoparam,tol,PMiter);
% build_BMPM_k_bi_PM - build a biased minimax probability machine (BMPM, kernelized version) for binary classification 
%                       using iterative parametric method (PM) to solve the Fractional Programming problem.
%
% [alpha_k, vgamma, b] = build_BMPM_k_bi_PM(Kmat,Y,beta0,gauss_assump,algoparam,tol,PMiter);
%
%
% The algorithm finds the biased minimax probabilistic decision hyperplane between two classes of points phi(x) and phi(y)
%
% H = {phi(z) | a'*phi(z) = b}
%
% that maximizes alpha_lin(lower bound on the probability of correct classification of future data for class x), while  
% keeps the lower bound on the probability of correct classification of future data for class y at an acceptable level, 
% beta0, subject to the constraint a<>0 and
%
% inf_(phi(x)~DX) Pr(a'phi(x) >= b) >= alpha_k
% inf_(phi(y)~DY) Pr(a'phi(y) <= b) >= beta0
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for phi(x), resp. phi(y), having
% a given mean and covariance matrix (if gauss_assump=1, only Gaussian distributions are considered). Mean and 
% covariance matrix for both class phi(x) and class phi(y) are estimated from data using the classical plug-in estimates.
%
% The mapping phi(z) is not explicitely needed. For the input, only the Gram matrix Kmat, specifying 
% Kmat(z_1,z_2)=phi(z_1)'*phi(z_2) is needed. For the output, not a is returned, but instead the weights
% of the decomposition of a in the span of the data points. 
%
%
% The inputs are
% Kmat         - an n-by-n Gram Matrix, corresponding to the n data points (n = Nx + Ny)
% Y            - an n-vector containing the labels of the n data points (+1 for class x, -1 for class y)
% beta0        - lower bound on the probability of correct classification of future data for class y 
% gauss_assump - 1 if phi(x) and phi(y) are assumed to be Gaussian distributed; 0 if not 
% algoparam    - internal parameter to determine the amount of regularization added to LSmat, the systemmatrix
%                for the least squares step; technically, algopar * eye(size(LSmat)) is added to LSmat
%                enter -1 to use default value: 1.000000e-006
% tol          - relative tolerance level for PM iterations
%                enter -1 to use default value: 1.0000e-006
% PMiter       - maximum number of iterations for PM iterations
%                enter -1 to use  default value: 50
%
% The outputs are
% alpha_k       - lower bound on the probability of correct classification of future data for the biased class x
% vgamma, b     - model parameters for the BMPM (vgamma is an n-vector of weights, b is the offset)
%

%%%%%%%%%%%%% INITIALIZATION STEPS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% set default values if needed %%%%%%
if algoparam==-1
    algoparam=1.000000e-006;
end
if tol==-1
    tol=1.000000e-006;
end
if PMiter==-1
    PMiter=50;
end

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end
%%%%%%% determine data points in both classes %%%%%%
Xclass = find(Y==1);
Yclass = find(Y==-1);

%%%%%%% number of data points in both classes %%%%%%
Nx = length(Xclass);
Ny = length(Yclass);

%%%%%%% total number of data points %%%%%%
N = Nx + Ny;

%%%%%% build matrices needed for iterative least squares %%%%%%
% rearrange kernel matrix
XY_perm=[Xclass;Yclass];
K = Kmat(XY_perm,XY_perm);
Kx = K(1:Nx,:);
Ky = K(Nx+1:N,:);
tx = mean(Kx)';
ty = mean(Ky)';
tKx = Kx - ones(Nx,1)*tx';
tKy = Ky - ones(Ny,1)*ty';
% vector gamma0
d = (tx - ty);
gamma0 = d/(d'*d);
% matrix F -- orthogonal matrix whose columns span the subspace of vectors orthogonal to gamma0
f = zeros(1,N-1);
[maxel,maxind]=max(d);
for i=1:maxind-1,
   f(1,i) = -d(i,1)/maxel;
end
for i=maxind:N-1,
   f(1,i) = -d(i+1,1)/maxel;
end
IN_1 = eye(N-1);
F = [IN_1(1:maxind-1,:); f; IN_1(maxind:N-1,:)];

% Parametric FP
% Making the matrices positive definite
Vsol = 1/Nx*tKx'*tKx+algoparam*eye(size(tKx,2));
Wsol = 1/Nx*tKy'*tKy+algoparam*eye(size(tKy,2));

% matrices for least squares step
Csq = F'*Vsol*F;
Cc = F'*Vsol*gamma0;
Dsq = F'*Wsol*F;
Dd = F'*Wsol*gamma0;

%%%%%%%%%%%%% Outer iterations  %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Parametric Method %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize lambda, assign lambda to a small positive value
lambda = min(kbeta0/5,0.1);
outiter = 1;
l_d(outiter) = lambda;
rel_ql_ch = 10*tol;

while and(rel_ql_ch > tol, outiter<PMiter)
    
	%%%%%%%%%%%%% ITERATIVE LEAST SQUARES %%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%% initialization %%%%%%
	eta_k = 1;
	xi_k = 1;
	iter = 1;
	rel_obj_ch = 10*tol;
	z_k = 0;
	
	%%%%%% Inner iterations %%%%%%%
	while and(rel_obj_ch > tol,iter<50),
        LSmat = lambda*lambda/eta_k*Csq + kbeta0*kbeta0/xi_k*Dsq;
        LSvect = -(lambda*lambda/eta_k*Cc + kbeta0*kbeta0/xi_k*Dd);
        z_k = inv(LSmat)*LSvect;
        gamma_t = F*z_k+gamma0;
        t1 = gamma_t'*Vsol*gamma_t;
        t2 = gamma_t'*Wsol*gamma_t;
        tt = eta_k+lambda^2*t1/eta_k+xi_k+kbeta0^2*t2/xi_k;
        eta_kp1 = lambda*sqrt(t1);
        xi_kp1 = kbeta0*sqrt(t2);
        Lobj_old = 2*(eta_k + xi_k);
        Lobj_new = 2*(eta_kp1 + xi_kp1);
        rel_obj_ch = abs(Lobj_new-Lobj_old)/abs(Lobj_old);
        iter = iter + 1;
        eta_k = eta_kp1;
        xi_k = xi_kp1;
       tt = eta_k+lambda^2*t1/eta_k+xi_k+kbeta0^2*t2/xi_k;
   end
	rel_ql_ch = abs(1-xi_k-eta_k);
	lambda = (1-xi_k)/eta_k*lambda;
	outiter = outiter + 1;
	l_d(outiter) = lambda;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% since \lambda increases after each iteration and the maximal
    %% value of alfa_temp is 1, we can terminate the iteration beforehand
    %% if (1-alfa_temp) < tol
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if gauss_assump==1
        alfa_temp = normcdf(lambda,0,1);
	else
        alfa_temp = lambda^2/(1+lambda^2);
	end
	if (1-alfa_temp<tol) break; end;
    if iter/90 ~= round(iter/90)
        fprintf('.');
    else
        fprintf('\n');
    end
end;
fprintf('\n');
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vgamma = gamma0 + F*z_k;
s = sqrt(vgamma'*Vsol*vgamma);
t = sqrt(vgamma'*Wsol*vgamma);
%%  Calculate b, both values in the bracket should be the same
b = mean([(vgamma'*ty+kbeta0*t), (vgamma'*tx-1+kbeta0*t)]);
kappa = max([(1-kbeta0*t)/s,0]);
if gauss_assump==1
    alpha_k = normcdf(kappa,0,1);
else
    alpha_k = kappa^2/(1+kappa^2);
end

% put gamma in the right order (such that the weights correspond to the resp.
% entries of Kmat rather than K)
vgamma(XY_perm) = vgamma;
