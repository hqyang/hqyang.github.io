function [alpha_lin, a] = solve_FP_RG(Mx,My,Covx,Covy,beta0,gauss_assump,ita0,tol,RGiter)
% solve_FP_RG       - solve a Fractional Programming (FP) Problem by the Rosen Gradient (RG) 
%                       projection method, or a BMPM problem.
%
% [alpha_lin, a] = solve_FP_RG(Mx,My,Covx,Covy,beta0,gauss_assump,ita0,tol,RGiter)
%
% The algorithm finds a(<>0) by maximizing 
%  k(a) = (1-kbeta0*sqrt(a'*Covy*a))/sqrt(a'*Covx*a), s.t., a'*(Mx-My) = 1;
% Mx, My, Covx and Covy are estimated from data using the classical plug-in estimates.
% kbeta0 = norminv(beta0,0,1), if under gaussian assumption; sqrt(beta0/(1-beta0)), otherwise

% The inputs are
% Mx           - (estimated) mean of class x (column vector)
% My           - (estimated) mean of class y (column vector)
% Covx         - (estimated) covariance matrix of class x
% Covy         - (estimated) covariance matrix of class y
% beta0        - the parameter for the BMPM to maintain the accuracy of class y
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not;
% ita0         - internal parameter for the initial step of the RG method. 
% tol          - relative tolerance level for RG method
% RGiter       - maximum number of iterations for RG method
%
% The outputs are
% alpha_lin    - the probability of correct classification of future data
%                for class x with given probability of beta0 for class y
% a            - optimal solution for the FP problem
%

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end

%% Initialize
A = Mx-My;
d = size(A,1);
a=0.6*ones(d,1);
i1=find(abs(A)==max(abs(A)));
a(i1(1))=(1-sum(a.*A)+a(i1(1))*A(i1(1)))/A((i1));    
gradi=ones(d,1);
epoch=1;%ita=0.1;
I=eye(d,d);

ita=ita0;
da = 10*tol;

%% Begin Rosen Gradient projection method
while and(epoch<=RGiter,da>tol)
     a_old = a;
     Vx=a'*Covx*a; Vy=a'*Covy*a;
     t1=kbeta0*sqrt(Vx)/sqrt(Vy)*Covy*a;
     t2=(1-kbeta0*sqrt(Vy))/sqrt(Vx)*Covx*a;
     gradi=-1/Vx*(t1+t2);
     P=I-A*inv(A'*A)*A';
     gradi=P*gradi;
     %find optimal ita;
     a1=a+ita*gradi;
     Vy_dg(epoch)=Vy;
     kalpha(epoch)=(1-kbeta0*sqrt(Vy))/sqrt(Vx);
     if(epoch>1)
         if(kalpha(epoch)-kalpha(epoch-1)>tol)
                     a=a1;
         else
             ita=ita/2;
             a=a+ita*gradi;
        end
    else
        a=a1;
    end
    epoch=epoch+1;
    da = norm(a-a_old);
end
Vx=a'*Covx*a; Vy=a'*Covy*a;
ka=(1-kbeta0*sqrt(Vy))/sqrt(Vx);
% ka should be non-negative for the worst-case
if(gauss_assump)
    alpha_lin=normcdf(ka,0,1);
else
    kalpha = max([ka, 0]);
    alpha_lin=kalpha^2/(kalpha^2+1);
end
