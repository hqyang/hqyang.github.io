function [alfa, a, b] = build_robMPMn_lin_bi_PM(Mx,My,Covx,Covy,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,PMiter);
% build_robMPMn_lin_bi_PM - build a robust linear minimax probability machine (MPM) for binary classification 
%                            with nu_x(~)= nu_y using Parametric Method (PM)
%
% The algorithm finds the minimax probabilistic decision hyperplane between two classes of points x and y
%
% H = {z | a'*z = b}
%
% that maximizes alfa (lower bound on the probability of correct classification of future data) subject
% to the constraint a<>0 and
% inf_(x~DX) Pr(a'x >= b) >= alfa
% inf_(y~DY) Pr(a'y <= b) >= alfa
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for x, resp. y, having
% a mean and covariance matrix in the convex set V, resp. W (if gauss_assump=1, only Gaussian distributions are 
% considered):
%
% V = {mean(x),cov(x) | (mean(x)-Mx)^T inv(cov(x)) (mean(x)-Mx) <= nu_x^2,
%                        ||cov(x)-Covx||_F <= rho_x}
% W = {mean(y),cov(y) | (mean(y)-My)^T inv(cov(y)) (mean(y)-My) <= nu_y^2,
%                        ||cov(y)-Covy||_F <= rho_y}
% 
% where Mx and Covx, resp. My and Covy, are the estimates for the mean and covariance matrix of class x, resp. class y, 
% provided in the input; ||...||_F denotes the Frobenius norm.
%
%
%
% The inputs are
% Mx           - (estimated) mean of class x (column vector)
% My           - (estimated) mean of class y (column vector)
% Covx         - (estimated) covariance matrix of class x
% Covy         - (estimated) covariance matrix of class y
% nu_x,nu_y    - robustness parameter quantizing uncertainty in the mean of class x, resp. y 
%                 (0 for no robustness)
% rho_x,rho_y   - robustness parameter quantizing uncertainty in the covariance for class x, resp. y
%                 (0 for no robustness)
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not; more details about this 
%                can be found in the reference
% algoparam    - internal parameter to determine the amount of regularization added to LSmat
%                enter -1 to use default value: 1.000000e-006
% tol          - relative tolerance level for QI/RG methods
%                enter -1 to use default value: 1.000000e-006
% PMiter       - maximum number of iterations for PM
%                enter -1 to use  default value: 50
%
% The outputs are
% alfa         - lower bound on the probability of correct classification of future data
% a, b         - model parameters for the linear MPM
%


%%%%%%%%%%%%% INITIALIZATION STEPS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% set default values if needed %%%%%%
if algoparam==-1
    algoparam=1.000000e-06;
end
if tol==-1
    tol=1.000000e-06;
end
if PMiter==-1
    PMiter=50;
end

%%%%%% build matrices needed for iterative least squares %%%%%%
% vector a0
d = (Mx - My);
a0 = d/(d'*d);
% matrix F -- orthogonal matrix whose columns span the subspace of vectors orthogonal to a0
N = length(a0);
f = zeros(1,N-1);
[maxel,maxind]=max(d);
for i=1:maxind-1,
   f(1,i) = -d(i,1)/maxel;
end
for i=maxind:N-1,
   f(1,i) = -d(i+1,1)/maxel;
end
IN_1 = eye(N-1);
F = [IN_1(1:maxind-1,:); f; IN_1(maxind:N-1,:)];
I = eye(N);

Sxp = Covx+rho_x*I;
Syp = Covy+rho_y*I;
% matrices for least squares step
G = F'*Sxp*F;
H = F'*Syp*F;
g = F'*Sxp*a0;
h = F'*Syp*a0;

%%%%%%%%%%%%% Outer iterations  %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Parametric Method %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize lambda
lambda = 0.1;
outiter = 1;
l_d(outiter) = lambda;
rel_pa_ch = 10*tol;
while and(rel_pa_ch > tol, outiter<PMiter)

	%%%%%%%%%%%%% ITERATIVE LEAST SQUARES %%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%% (see Section 2.3 in reference) %%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%% initialization %%%%%%
	eta_k = 1;
	xi_k = 1;
	iter = 1;
	rel_obj_ch = 10*tol;
	u_k = 0;

    tkx = lambda+nu_x;
    tky = lambda+nu_y;
    
    %%%%%% iterations %%%%%%%
	while and(rel_obj_ch > tol,iter<PMiter),
		LSmat = tkx*tkx/eta_k*G + tky*tky/xi_k*H;
		LSmat = LSmat + algoparam*eye(size(LSmat));
		LSvect = -(tkx*tky/eta_k*g + tky*tky/xi_k*h);
		u_k = pinv(LSmat)*LSvect;
		a_k = a0 + F*u_k;
		arg1 = sqrt(a_k'*Sxp*a_k);
		arg2 = sqrt(a_k'*Syp*a_k);
		eta_kp1 = tkx*arg1;
		xi_kp1 = tky*arg2;
		Lobj_old = 2*(eta_k + xi_k);
		Lobj_new = 2*(eta_kp1 + xi_kp1);
		rel_obj_ch = abs(Lobj_new-Lobj_old)/abs(Lobj_old);
		iter = iter + 1;
		eta_k = eta_kp1;
		xi_k = xi_kp1;
	end
    denom = arg1+arg2;
    nom = nu_x*arg1+nu_y*arg2;
	rel_pa_ch = abs(1-nom-lambda*denom);
    lambda = (1-nom)/denom;
	outiter = outiter + 1;
	l_d(outiter) = lambda;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% since \lambda increases after each iteration and the maximal
    %% value of alfa_temp is 1, we can determine the iteration beforehand
    %% if (1-alfa_temp) < tol
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if gauss_assump==1
        alfa_temp = normcdf(lambda,0,1);
	else
        alfa_temp = lambda^2/(1+lambda^2);
	end
	if (1-alfa_temp<tol) break; end;

    if outiter/90 ~= round(outiter/90)
        fprintf('.');
    else
        fprintf('\n');
    end
end;
fprintf('\n');
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a = a_k;
Vx = a'*Sxp*a; Vy = a'*Syp*a;
b = mean([(a'*Mx+(lambda+nu_y)*sqrt(Vy)-1), (a'*My+(lambda+nu_y)*sqrt(Vy))]);
ka = (1-(nu_x*sqrt(Vx)+nu_y*sqrt(Vy)))/(sqrt(Vx)+sqrt(Vy));
kalfa = max([ka 0]);
if gauss_assump==1
    alfa = normcdf(kalfa,0,1);
else
    alfa = kalfa^2/(kalfa^2+1);
end