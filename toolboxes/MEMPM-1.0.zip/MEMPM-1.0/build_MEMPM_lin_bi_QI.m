function [alpha_lin, beta_lin, a, b] = build_MEMPM_lin_bi_QI(Mx,My,Covx,Covy,xprior,gauss_assump,beta,ita,tol,QIiter,RGiter);
% build_MEMPM_lin_bi_QI - build a linear minimum error minimax probability machine (MEMPM) for binary classification 
%                            using sequential biased minimax probability machine (BMPM), or a line search + BMPM.
%                            The line search is performed by the Quadratic Interpolation (QI) method, where the 
%                            objective is to maximize f(beta) = xprior*alfa(beta)+yprior*beta, alfa(beta), a form of 
%                            BMPM, needs to optimize a Fractional Programming (FP) problem and is solved by the Rosen 
%                            Gradient (RG) projection method here. 
%
% [alpha_lin, beta_lin, a, b] = build_MEMPM_lin_bi_QI(Mx,My,Covx,Covy,xpriorgauss_assump,,beta,ita,tol,QIiter,RGiter)
%
% The algorithm finds the minimum error minimax probabilistic decision hyperplane between two classes of points x and y
%
% H = {z | a'*z = b}
%
% that maximizes xprior*alpha_lin+(1-xprior)*beta_lin (lower bound on the probability of correct classification of future 
% data) subject to the constraint a<>0 and
%
% inf_(x~DX) Pr(a'x >= b) >= alpha_lin
% inf_(y~DY) Pr(a'y <= b) >= beta_lin
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for x, resp. y, having
% a given mean Mx, resp. My, and a given covariance matrix Covx, resp. Covy (if gauss_assump=1, only 
% Gaussian distributions are considered). Mx, My, Covx and Covy can, e.g., be estimated from data using
% the classical plug-in estimates.
%
%
% The inputs are
% Mx           - (estimated) mean of class x (column vector)
% My           - (estimated) mean of class y (column vector)
% Covx         - (estimated) covariance matrix of class x
% Covy         - (estimated) covariance matrix of class y
% xprior       - (estimated) prior probability of class x 
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not; more details about this 
%                can be found in the reference
% beta         - internal parameter for the initial values of the three-point pattern QI method,
%                you may enter better initial beta to speed up the QI search, or       
%                enter norm(beta)==0 or length(beta)~=3 to use default value: 
% 						beta(1) = min_beta_lin; 
% 						beta(3) = max_beta_lin;
% 						beta(2) = (beta(1)+beta(3))/2;
%                where min_beta = 0.5001 for gaussian distribution assumption; 0.0001 otherwise.  This is 
%                due to the convexity of FP being maintained when kbeta0>=0.
%                max_beta is calulated by the FP when alpha_lin is set to (a value approaching to) its minimum,
%                i.e., min_alpha_lin = min_beta_lin (alpha_lin is symmetrical to beta_lin).
% ita          - internal parameter for the initial step of the RG method. 
%                enter -1 to use default value 0.1
% tol          - relative tolerance level for QI/RG methods
%                enter -1 to use default value: 1.000000e-006
% QIiter       - maximum number of iterations for QI method
%                enter -1 to use  default value: 500
% RGiter       - maximum number of iterations for RG method
%                enter -1 to use  default value: 5000
%
% The outputs are
% alpha_lin    - lower bound on the probability of correct classification of future data for class x
% beta_lin     - lower bound on the probability of correct classification of future data for class y
% a, b         - model parameters for the linear MEMPM
%
%
% Yang, Haiqin February 2004.

%%%%%%%%%%%%% INITIALIZATION STEPS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% set default values if needed %%%%%%
if (norm(beta)==0 | length(beta)~=3)
    clear beta;
    beta = zeros(1,3);
	if(gauss_assump)
		beta(1) = 0.5001; 
	else
        beta(1) = 0.0001; 
	end
	min_alpha = beta(1);
	beta_up = solve_FP_RG(My,Mx,Covy,Covx,min_alpha,gauss_assump,ita,tol,RGiter);
	if beta_up > 1-tol beta_up = 1-tol; end;
	beta(3) = beta_up;
	beta(2) = (beta(1)+beta(3))/2;
end
if ita==-1
    ita=0.1
end
if tol==-1
    tol=1.000000e-06;
end
if QIiter==-1
    QIiter=500;
end
if RGiter==-1
    RGiter=5000;
end
yprior = 1-xprior;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Find suitable beta for the three-point pattern QI method based on the
%% inital beta, where beta1<beta2<beta3, and f(beta1)<f(beta2)>f(beta3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

va = zeros(size(Mx,1),3);
[la(1), va(:,1)] = solve_FP_RG(Mx,My,Covx,Covy,beta(1),gauss_assump,ita,tol,RGiter);
[la(2), va(:,2)] = solve_FP_RG(Mx,My,Covx,Covy,beta(2),gauss_assump,ita,tol,RGiter);
[la(3), va(:,3)] = solve_FP_RG(Mx,My,Covx,Covy,beta(3),gauss_assump,ita,tol,RGiter);
    
fl = xprior*la + yprior*beta;

while (fl(1)<fl(2) & fl(2)<fl(3) & abs(fl(1)-fl(3))>tol)
    beta(1) = beta(2);
    fl(1) = fl(2);
    beta(2) = (beta(2)+beta(3))/2;
	[la(2), va(:,2)] = solve_FP_RG(Mx,My,Covx,Covy,beta(2),gauss_assump,ita,tol,RGiter);
	fl(2) = xprior*la(2) + yprior*beta(2);
end;

while (fl(1)>fl(2) & fl(2)>fl(3) & abs(fl(1)-fl(3))>tol)
    beta(3) = beta(2);
    fl(3) = fl(2);
    beta(2) = (beta(1)+beta(2))/2;
	[la(2), va(:,2)] = solve_FP_RG(Mx,My,Covx,Covy,beta(2),gauss_assump,ita,tol,RGiter);
	fl(2) = xprior*la(2) + yprior*beta(2);
end;

dfl = max(abs(fl(1)-fl(2)),abs(fl(2)-fl(3)));
if (dfl<=tol)
    beta_lin = beta(2);
    a = va(:,2);
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                  Begin the QI search
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    iter = 1;
    dvbeta = 10*tol;
    while (abs(fl(1)-fl(3))>tol & dvbeta>tol & iter<QIiter)
        beta_old = beta;
        %% Calulate new beta
        beta_new = 0.5*(fl(1)*(beta(3)*beta(3)-beta(2)*beta(2))+fl(2)*(beta(1)*beta(1)-beta(3)*beta(3))+fl(3)*(beta(2)*beta(2)-beta(1)*beta(1)))/(fl(1)*(beta(3)-beta(2))+fl(2)*(beta(1)-beta(3))+fl(3)*(beta(2)-beta(1)));
        dbeta = beta_new - beta(2);
        if (abs(dbeta) < tol)
            if (2*beta(2)>beta(1)+beta(3))
                beta_new = beta_new - tol;
            else
                beta_new = beta_new + tol;
            end;
        end;
        [la_new, va_new] = solve_FP_RG(Mx,My,Covx,Covy,beta_new,gauss_assump,ita,tol,RGiter);
        fl_new = xprior*la_new + yprior*beta_new;
        dfl = fl_new - fl(2);
        while (abs(dfl)<=tol & (abs(fl_new-fl(1))>tol | abs(fl_new-fl(3))>tol))
            if (2*beta(2)>beta(1)+beta(3))
                beta_new = (beta_new + beta(1))/2;
            else
                beta_new = (beta_new + beta(3))/2;
            end;
            [la_new, va_new] = solve_FP_RG(Mx,My,Covx,Covy,beta_new,gauss_assump,ita,tol,RGiter);
            fl_new = xprior*la_new + yprior*beta_new;
            dfl = fl_new - fl(2);
            iter = iter + 1;
        end;
        
        %% Update three-point pattern 
        dbeta = beta_new - beta(2);
        if (dbeta>0)
            if (dfl>0)
                beta(1) = [beta_new];
                fl(1) = [fl_new];
                va(:,1) = [va_new];
            else
                beta(3) = [beta_new];
                fl(3) = [fl_new];
                va(:,3) = [va_new];
            end;
        elseif (dbeta<0)
            if (dfl>0)
                beta(3) = [beta_new];
                fl(3) = [fl_new];
                va(:,3) = [va_new];
            else
                beta(1) = [beta_new];
                fl(1) = [fl_new];
                va(:,1) = [va_new];
            end;
        end;
        [beta I] = sort(beta);
        fl = fl(I);
        va(:,1:3) = va(:,I);
        dvbeta = norm(beta-beta_old);
        iter = iter + 1;
        if iter/90 ~= round(iter/90)
            fprintf('.');
        else
            fprintf('\n');
        end
    end;
    a = va(:,2);
    beta_lin = beta(2);
    fprintf('\n');
end;    
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(gauss_assump)
    kbeta=norminv(beta_lin,0, 1);
else
    kbeta=sqrt(beta_lin/(1-beta_lin));
end
Vx=a'*Covx*a; Vy=a'*Covy*a;

%%  Calculate b, both values in the bracket should be the same
b=mean([(a'*Mx-1+kbeta*sqrt(Vy)),(a'*My+kbeta*sqrt(Vy))]); 
% ka should be non-negative for the worst-case
ka = (1-kbeta*sqrt(Vy))/sqrt(Vx);
if(gauss_assump)
    alpha_lin=normcdf(ka,0,1);
else
    kalpha = max([ka, 0]);
    alpha_lin=kalpha^2/(kalpha^2+1);
end
 
