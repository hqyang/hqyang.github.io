-------------------------------------------
-------------------------------------------
 Instructions for using MEMPM, version 1.0
-------------------------------------------
-------------------------------------------
 

- unzip MEMPM-1.0.zip

- run 'mempm_demo' or 'robust_demo' in matlab, in the corresponding directroy
  the procedure is performed step by step interactively, you may press any key to continue it	

- the m-file 'mempm_demo.m' is demonstrated how to use the MEMPM functions, it is commented 
  and explains how to use the code with your own data

- the m-file 'robust_demo.m' is demonstrated how to use the robust version of MEMPM and MPM 
  (with nu_x(~)=nu_y) functions, it is commented and explains how to use the code with your 
  own data

- the other m-files are commented as well and can directly be used to train and test the MEMPM 
  or robust MPM with unequal parameters with your own data



An overview of the files:

build_MEMPM_lin_bi_QI.m
-----------------------------
to train a minimum error minimax probability machine (MEMPM, linear version) for binary 
classification using sequential biased minimax probability machine (BMPM) method,
the line search is performed by the Quadratic Interpolation method, BMPM is performed by 
the Rosen Gradient projection method

solve_FP_RG.m
-----------------------------
to solve a Fractional Programming problem by the Rosen Gradient projection method

build_MEMPM_k_bi_QI.m
-----------------------------
to train a minimum error minimax probability machine (MEMPM, kernelized version) for binary 
classification using sequential biased minimax probability machine (BMPM) method,
the line search is performed by the Quadratic Interpolation method, BMPM is performed by 
the Parametric Method

solve_FP_PM.m
-----------------------------
to solve a Fractional Programming problem by the Parametric Method

build_BMPM_k_bi_PM.m
-------------------------------
to train a biased minimax probability machine (BMPM, kernelized version) for binary 
classification using Parametric Method to solve the Fractional Programming problem
to be used to find the maximum lower bound of classification for class y 

build_robMEMPM_lin_bi_QI.m
-----------------------------
to train a robust minimum error minimax probability machine (MEMPM, linear version) for binary 
classification using sequential biased minimax probability machine (BMPM) 
method, the line search is performed by the Quadratic Interpolation method, BMPM is performed 
by the Rosen Gradient projection method

solve_robFP_RG.m
-----------------------------
to solve a Fractional Programming problem with robust parameters by the Rosen Gradient projection method

build_robMEMPM_k_bi_QI.m
-------------------------------
to train a robust minimum error minimax probability machine (MEMPM, kernelized version) for binary 
classification using sequential biased minimax probability machine (BMPM) 
method, the line search is performed by the Quadratic Interpolation method, BMPM is performed by 
the Parametric Method

solve_robFP_PM.m
-----------------------------
to solve a Fractional Programming problem with robust parameters by the Parametric Method

build_robBMPM_k_bi_PM.m
-------------------------------
to train a robust biased minimax probability machine (BMPM, kernelized version) for binary 
classification using Parametric Method to solve the Fractional Programming problem
to be used to find the maximum lower bound of classification for class y 

build_robMPMn_lin_bi_PM.m
-------------------------------
to train a robust linear minimax probability machine (MPM) for binary classification with 
nu_x(~)=nu_y, it is implemented by solved a Fractional Programming problem using parametric
method

build_robMPMn_k_bi_PM.m
-------------------------------
to train a robust minimax probability machine (MPM, kernelized version) for binary classification 
with nu_x(~)=nu_y, it is implemented by solved a Fractional Programming problem using parametric
method

eval_lin_bi.m
----------------------
evaluate all minimax probability machines (linear version), including Minimax Probability Machine (MPM), 
Biased Minimax Probability Machine (BMPM), Minimum Error Minimax Probability Machine (MEMPM), for binary 
classification

eval_k_bi.m
----------------------
evaluate all minimax probability machines (kernelized version), including Minimax Probability Machine (MPM), 
Biased Minimax Probability Machine (BMPM), Minimum Error Minimax Probability Machine (MEMPM), for binary 
classification


mempm.mat:
------------
contains the data for the demonstration in .mat format


mempm_demo.m:
-------------
demonstration for using the mempm toolbox

robust_demo.m:
-------------
demonstration for using the robust version of MEMPM and MPM with unequal parameters

--------------------------------------------------------------------------------------------------------
We thank Gert R. G. Lanckriet for providing the Matlab source code of MPM.  For convenient comparison, 
we implement the toolbox using the same data format to the MPM.   

Please email me if you have any comments or problems: hqyang@cse.cuhk.edu.hk and kzhuang@cse.cuhk.edu.hk
--------------------------------------------------------------------------------------------------------