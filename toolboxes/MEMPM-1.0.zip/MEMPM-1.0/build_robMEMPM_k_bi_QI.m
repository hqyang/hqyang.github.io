function [alph_k, beta_k, omega_k, b] = build_robMEMPM_k_bi_QI(Kmat,Y,nu_x,nu_y,rho_x,rho_y,gauss_assump,beta,algoparam,tol,QIiter,PMiter);
% build_robMEMPM_k_bi_QI - build a robust minimum error minimax probability machine (MEMPM, kernelized version) for binary classification
%                            using sequential biased minimax probability machine (BMPM), or a line search + BMPM.
%                            The line search is performed by the Quadratic Interpolation (QI) method, where the 
%                            objective is to maximize f(beta) = xprior*alfa(beta)+yprior*beta, alfa(beta), a form 
%                            of BMPM, needs to optimize a Fractional Programming (FP) problem and is solved by the 
%                            Parametric Method (PM) here. 
%
% [alph_k, beta_k, omega, b] = build_robMEMPM_k_bi_QI(Kmat,Y,beta,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,QIiter,PMiter);
%
%
% The algorithm finds the minimum error minimax probabilistic decision hyperplane between two classes of points phi(x) and phi(y)
%
% H = {phi(z) | a'*phi(z) = b}
%
% that maximizes xprior*alph_k+yprior*beta_k (lower bound on the probability of correct classification of future data) subject
% to the constraint a<>0 and
%
% inf_(phi(x)~DX) Pr(a'phi(x) >= b) >= alph_k
% inf_(phi(y)~DY) Pr(a'phi(y) <= b) >= beta_k
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for phi(x), resp. phi(y), having
% a given mean and covariance matrix (if gauss_assump=1, only Gaussian distributions are considered). Mean and 
% covariance matrix for both class phi(x) and class phi(y) are estimated from data using the classical plug-in estimates.
%
% The mapping phi(z) is not explicitely needed. For the input, only the Gram matrix Kmat, specifying 
% Kmat(z_1,z_2)=phi(z_1)'*phi(z_2) is needed. For the output, not a is returned, but instead the weights
% gamma of the decomposition of a in the span of the data points. 
%
% The inputs are
% Kmat         - an n-by-n Gram Matrix, corresponding to the n data points (n = Nx + Ny)
% Y            - an n-vector containing the labels of the n data points (+1 for class x, -1 for class y)
% nu_x,nu_y    - robustness parameter quantizing uncertainty in the mean of class x, resp.y
%               (0 for no robustness)
% rho_x,rho_y  - robustness parameter quantizing uncertainty in the covariance of class x, resp.y
%               (0 for no robustness)
% gauss_assump - 1 if phi(x) and phi(y) are assumed to be Gaussian distributed / 0 if not (this will only
%                influence the optimal value of alph_k, not the position of the optimal hyperplane; 
% beta         - internal parameter for the initial values of the three-point pattern QI method
%                you may enter better initial beta to speed up the QI search, or       
%                enter norm(beta)==0 or length(beta)~=3 to use default value: 
% 						beta(1) = min_beta; 
% 						beta(3) = max_beta;
% 						beta(2) = (beta(1)+beta(3))/2;
%                where min_beta = 0.5001 for Gaussian distribution assumption; 0.0001 otherwise, since the 
%                convexity of FP maintains when kbeta0>=0.
%                max_beta is calulated by the FP when alpha_k is set to min_beta.   
% algoparam    - internal parameter to determine the amount of regularization added to LSmat, the systemmatrix
%                for the least squares step; technically, algopar * eye(size(LSmat)) is added to LSmat
%                enter -1 to use default value: 1.000000e-006
% tol          - relative tolerance level for QI/PM methods and least squares iterations
%                enter -1 to use default value: 1.000000e-006
% QIiter       - maximum number of iterations for QI method
%                enter -1 to use  default value: 500
% PMiter       - maximum number of iterations for PM method
%                enter -1 to use  default value: 50
%
% The outputs are
% alph_k        - lower bound on the probability of correct classification of future data for class x
% beta_k        - lower bound on the probability of correct classification of future data for class y
% omega_k, b    - model parameters for the MEMPM (omega is an n-vector of weights, b is the offset)
%
%
% Haiqin Yang, March 2004.


%%%%%%%%%%%%% INITIALIZATION STEPS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% set default values if needed %%%%%%
if (norm(beta)==0 | length(beta)~=3)
    clear beta;
    beta = zeros(1,3);
	if(gauss_assump)
		beta(1) = 0.5001; 
	else
        beta(1) = 0.0001; 
	end
	min_alpha = beta(1);
	rlabels = -Y;
	beta_up = build_robBMPM_k_bi_PM(Kmat,rlabels,min_alpha,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,PMiter);
	if beta_up > 1-tol beta_up = 1-tol; end;
	beta(3) = beta_up;
	beta(2) = (beta(1)+beta(3))/2;
end
if algoparam==-1
    algoparam=1.000000e-06;
end
if tol==-1
    tol=1.000000e-06;
end
if QIiter==-1
    QIiter=500;
end
if PMiter==-1
    PMiter=50;
end

%%%%%%% determine data points in both classes %%%%%%
Xclass = find(Y==1);
Yclass = find(Y==-1);

%%%%%%% number of data points in both classes %%%%%%
Nx = length(Xclass);
Ny = length(Yclass);

%%%%%%% total number of data points %%%%%%
N = Nx + Ny;

%%prior probability
xprior = Nx/N;
yprior = Ny/N;

%%%%%% build variables %%%%%%
% rearrange kernel matrix
XY_perm=[Xclass;Yclass];
K = Kmat(XY_perm,XY_perm);
% build Lx and Ly
Kx = K(1:Nx,:);
Ky = K(Nx+1:N,:);
tx = mean(Kx)';
ty = mean(Ky)';
tKx = (Kx - ones(Nx,1)*tx');
tKy = (Ky - ones(Ny,1)*ty');
Vsol = 1/Nx*tKx'*tKx + rho_x*K;
Wsol = 1/Ny*tKy'*tKy + rho_y*K;

%%%%%% build matrices needed for QI method %%%%%%
% vector omega0
d = (tx - ty);
omega0 = d/(d'*d);
omega_old = omega0;
% matrix F -- orthogonal matrix whose columns span the subspace of vectors orthogonal to omega0
f = zeros(1,N-1);
[maxel,maxind]=max(d);
for i=1:maxind-1,
   f(1,i) = -d(i,1)/maxel;
end
for i=maxind:N-1,
   f(1,i) = -d(i+1,1)/maxel;
end
IN_1 = eye(N-1);
F = [IN_1(1:maxind-1,:); f; IN_1(maxind:N-1,:)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Find suitable beta for the three-point pattern QI method based on the
%% inital beta, where beta1<beta2<beta3, and f(beta1)<f(beta2)>f(beta3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

omega(:,1:3) = zeros(N,3);
[ka(1),omega(:,1)] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta(1),nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
[ka(2),omega(:,2)] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta(2),nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
[ka(3),omega(:,3)] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta(3),nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
fk = xprior*ka + yprior*beta;

while (fk(1)-fk(2)<tol & fk(2)-fk(3)<tol & abs(fk(1)-fk(3))>tol)
    beta(1) = beta(2);
    fk(1) = fk(2);
    beta(2) = (beta(2)+beta(3))/2;
    [ka(2),omega(:,2)] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta(2),nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
	fk(2) = xprior*ka(2) + yprior*beta(2);
end;

while (fk(1)-fk(2)>tol & fk(2)-fk(3)>tol & abs(fk(1)-fk(3))>tol)
    beta(3) = beta(2);
    fk(3) = fk(2);
    beta(2) = (beta(1)+beta(2))/2;
    [ka(2),omega(:,2)] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta(2),nu_x,nu_y,gauss_assump,lgoparam,tol,PMiter);
    fk(2) = xprior*ka(2) + yprior*beta(2);
end;

dfk = max(abs(fk(1)-fk(2)),abs(fk(2)-fk(3)));
if (dfk<=tol)
    beta_k = beta(2);
    omega_k = omega(:,2);
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                  Begin the QI search
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    iter = 1;
    dvbeta = 10*tol;
    while (abs(fk(1)-fk(3))>tol & dvbeta>tol & iter<QIiter)
        beta_old = beta;
        beta_new = 0.5*(fk(1)*(beta(3)*beta(3)-beta(2)*beta(2))+fk(2)*(beta(1)*beta(1)-beta(3)*beta(3))+fk(3)*(beta(2)*beta(2)-beta(1)*beta(1)))/(fk(1)*(beta(3)-beta(2))+fk(2)*(beta(1)-beta(3))+fk(3)*(beta(2)-beta(1)));
        [ka_new,omega_new] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta_new,nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
        fk_new = xprior*ka_new + yprior*beta_new;
        dfk = fk_new - fk(2);
        if (abs(dfk)<tol)
            if (2*beta(2)>beta(1)+beta(3))
                beta_new = (beta_new + beta(1))/2;
            else
                beta_new = (beta_new + beta(3))/2;
            end;
        end;
        [ka_new,omega_new] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta_new,nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
        fk_new = xprior*ka_new + yprior*beta_new;

        dfk = fk_new - fk(2);
        while (abs(dfk)<=tol & (abs(fk_new-fk(1))>tol | abs(fk_new-fk(3))>tol))
            if (2*beta(2)>beta(1)+beta(3))
                beta_new = (beta_new + beta(1))/2;
            else
                beta_new = (beta_new + beta(3))/2;
            end;
            [ka_new,omega_new] = solve_robFP_PM(Vsol,Wsol,F,omega0,beta_new,nu_x,nu_y,gauss_assump,algoparam,tol,PMiter);
            fk_new = xprior*ka_new + yprior*beta_new;
            dfk = fk_new - fk(2);
            iter = iter + 1;
        end;

        dbeta = beta_new - beta(2);
        if (dbeta>0)
            if (dfk>0)
                beta(1) = [beta_new];
                fk(1) = [fk_new];
                omega(:,1) = [omega_new];
            else
                beta(3) = [beta_new];
                fk(3) = [fk_new];
                omega(:,3) = [omega_new];
            end;
        elseif (dbeta<0)
            if (dfk>0)
                beta(3) = [beta_new];
                fk(3) = [fk_new];
                omega(:,3) = [omega_new];
            else
                beta(1) = [beta_new];
                fk(1) = [fk_new];
                omega(:,1) = [omega_new];
            end;
        end;
        [beta I] = sort(beta);
        fk = fk(I);
        omega(:,1:3) = omega(:,I);
        dvbeta = norm(beta-beta_old);
        iter = iter + 1;
        if iter/90 ~= round(iter/90)
            fprintf('.');
        else
            fprintf('\n');
        end
    end;
    omega_k = omega(:,2);
    beta_k = beta(2);
	fprintf('\n');
end;    
%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if gauss_assump==1
    kbeta = norminv(beta_k,0,1);
else
    kbeta = sqrt(beta_k/(1-beta_k));
end;
rkbeta = kbeta + nu_y;
s = sqrt(omega_k'*Vsol*omega_k);
t = sqrt(omega_k'*Wsol*omega_k);
%%  Calculate b, both values in the bracket should be the same
b = mean([(omega_k'*tx-1+rkbeta*t), (omega_k'*ty+rkbeta*t)]);    
kappa = (1-rkbeta*t)/s;
tl = max([kappa-nu_x, 0]);
if gauss_assump==1
    alph_k = normcdf(tl,0,1);
else
    alph_k = tl^2/(1+tl^2);
end    
    
% put omega_k in the right order (such that the weights correspond to the resp.
% entries of Kmat rather than K)
omega_k(XY_perm) = omega_k;
