function [alpha_k,omega_k] = solve_FP_PM(Vsol,Wsol,F,omega0,beta0,gauss_assump,algoparam,tol,maxiter)
% solve_FP_PM       - solve a Fractional Programming (FP) problem by the Parametric Method (PM), or a BMPM problem.
%
% [alpha_k,omega_k] = solve_FP_PM(Vsol,Wsol,F,omega0,beta0,gauss_assump,algoparam,tol,maxiter)
%
% The algorithm finds a=F*a_k+omega0 by maximizing 
%  k(a) = (1-kbeta0*sqrt(a'*Wsol*a))/sqrt(a'*Vsol*a), 
% with parameters Vsol and Wsol.
% kbeta0 = norminv(beta0,0,1), if under gaussian assumption; sqrt(beta0/(1-beta0)), otherwise
%
% The inputs are
% Vsol         - n*n matrix in the denominator of the fractional part
% Wsol         - n*n matrix in the numerator of the fractional part
% beta0        - the parameter for the BMPM to maintain the accuracy of class y
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not;
% algoparam    - internal parameter to determine the amount of regularization added to Vsol, 
%                so as to make Vsol positive definite;
% tol          - relative tolerance level for RG method
% maxiter      - maximum number of iterations for parametric method
%
% The outputs are
% alpha_k     - the probability of correct classification of future data
%                for class x with given probability of beta0 for class y
% omega_k     - optimal solution for the FP problem
%

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end

%%%%%%%%%%%% Solve the Fractional Programming problem %%%%%%%%%%%% 
%% Make the matrices positive definite
Vsol = Vsol + algoparam*eye(size(Vsol));
Wsol = Wsol + algoparam*eye(size(Wsol));

Csq = F'*Vsol*F;
Dsq = F'*Wsol*F;
Cc = F'*Vsol*omega0;
Dd = F'*Wsol*omega0;

%% Initial lambda, it should be a small positive value
lambda = min(kbeta0/5,0.1);
outiter = 1;
l_d(outiter) = lambda;

%%%%%%%%%%%%% Outer iterations %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rel_ql_ch = 10*tol;

while and(rel_ql_ch > tol, outiter<maxiter)

	% matrices for least squares step
	
	%%%%%%%%%%%%% ITERATIVE LEAST SQUARES %%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%% initialization %%%%%%
	eta_k = 1;
	xi_k = 1;
	iter = 1;
	rel_obj_ch = 10*tol;
	rel_alfa_ch = 10*tol;
	rel_beta_ch = 10*tol;
	z_k = 0;
	Lobj_old = 10*tol;
	
	%%%%%% Inner iterations %%%%%%%
	while and(rel_obj_ch > tol, iter < 50),
       LSmat = Csq/eta_k*lambda*lambda + Dsq/xi_k*kbeta0*kbeta0;
       LSvect = -(Cc/eta_k*lambda*lambda + Dd/xi_k*kbeta0*kbeta0);
       z_k = inv(LSmat)*LSvect;
       omega_arg = omega0 + F*z_k;
       arg1 = omega_arg'*Vsol*omega_arg;
       arg2 = omega_arg'*Wsol*omega_arg;
       tt = eta_k+lambda^2*arg1/eta_k+xi_k+kbeta0^2*arg2/xi_k;
       eta_kp1 = lambda*sqrt(arg1);
       xi_kp1 = kbeta0*sqrt(arg2);
       Lobj_old =  2*(eta_k + xi_k);
       Lobj_new = 2*(eta_kp1 + xi_kp1);
       eta_k = eta_kp1;
       xi_k = xi_kp1;
       rel_obj_ch = abs(Lobj_new-Lobj_old)/abs(Lobj_old);
       tt = eta_k+lambda^2*arg1/eta_k+xi_k+kbeta0^2*arg2/xi_k;
       iter = iter + 1;
	end
	rel_ql_ch = 1-xi_k-eta_k;
	lambda = (1-xi_k)/eta_k*lambda;
	outiter = outiter + 1;
	l_d(outiter) = lambda;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% since \lambda increases after each iteration and the maximal
    %% value of alfa_temp is 1, we can determine the iteration beforehand
    %% if (1-alfa_temp) < tol
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if gauss_assump==1
        alfa_temp = normcdf(lambda,0,1);
	else
        alfa_temp = lambda^2/(1+lambda^2);
	end
	if (1-alfa_temp<tol) break; end;

end;

omega_k = omega0 + F*z_k;
s = sqrt(omega_k'*Vsol*omega_k);
t = sqrt(omega_k'*Wsol*omega_k);
% kappa should be non-negative for the worst-case
kappa = (1-kbeta0*t)/s;
if gauss_assump==1
    alpha_k = normcdf(kappa,0,1);
else
    kappa = max([kappa,0]);
    alpha_k = kappa^2/(1+kappa^2);
end    
