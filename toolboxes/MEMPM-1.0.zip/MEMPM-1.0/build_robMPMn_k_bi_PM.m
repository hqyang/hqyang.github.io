function [alfa_k, vgamma, b] = build_robMPMn_k_bi_PM(Kmat,Y,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,PMiter);
% build_robMPMn_k_bi_PM - build a robust minimax probability machine (MPM, kernelized version) for binary classification 
%                      with nu_x(~)=nu_y using iterative Parametric Method (PM).
%
% [alfa_k, vgamma, b] = build_robMPMn_k_bi_PM(Kmat,Y,nu_x,nu_y,rho_x,rho_y,gauss_assump,algoparam,tol,PMiter);
%
%
% The algorithm finds the biased minimax probabilistic decision hyperplane between two classes of points phi(x) and phi(y)
%
% H = {phi(z) | a'*phi(z) = b}
%
% that maximizes alfa_k (lower bound on the probability of correct classification of future data for the biased class) subject
% to the constraint a<>0 and
%
% inf_(phi(x)~DX) Pr(a'phi(x) >= b) >= alfa_k
% inf_(phi(y)~DY) Pr(a'phi(y) <= b) >= alfa_k
%
% where the infimum is taken over DX, resp. DY, being the set of all distributions for phi(x), resp. phi(y), having
% a given mean and covariance matrix (if gauss_assump=1, only Gaussian distributions are considered). Mean and 
% covariance matrix for both class phi(x) and class phi(y) are estimated from data using the classical plug-in estimates.
%
% The mapping phi(z) is not explicitely needed. For the input, only the Gram matrix Kmat, specifying 
% Kmat(z_1,z_2)=phi(z_1)'*phi(z_2) is needed. For the output, not a is returned, but instead the weights
% kbeta0 of the decomposition of a in the span of the data points. 
%
%
% The inputs are
% Kmat         - an n-by-n Gram Matrix, corresponding to the n data points (n = Nx + Ny)
% Y            - an n-vector containing the labels of the n data points (+1 for class x, -1 for class y)
% nu_x,nu_y    - robustness parameter quantizing uncertainty in the mean of class x, resp.y
%               (0 for no robustness)
% rho_x,rho_y  - robustness parameter quantizing uncertainty in the covariance of class x, resp.y
%               (0 for no robustness)
% gauss_assump - 1 if phi(x) and phi(y) are assumed to be Gaussian distributed / 0 if not (this will only
%                influence the optimal value of alph_k, not the position of the optimal hyperplane; 
% algoparam    - internal parameter to determine the amount of regularization added to LSmat
%                enter -1 to use default value: 1.000000e-006
% tol          - relative tolerance level for least squares iterations
%                enter -1 to use default value: 1.000000e-006
% PMiter       - maximum number of iterations for least squares iterations
%                enter -1 to use  default value: 50
%
% The outputs are
% alfa_k       - lower bound on the probability of correct classification of future data for the biased class
% vgamma, b    - model parameters for the BMPM (vgamma is an n-vector of weights, b is the offset)
%
% Yang Haiqin March 2004


%%%%%%%%%%%%% INITIALIZATION STEPS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% set default values if needed %%%%%%
if algoparam==-1
    algoparam=1.000000e-06;
end
if tol==-1
    tol=1.000000e-06;
end
if PMiter==-1
    PMiter=50;
end

%%%%%%% determine data points in both classes %%%%%%
Xclass = find(Y==1);
Yclass = find(Y==-1);

%%%%%%% number of data points in both classes %%%%%%
Nx = length(Xclass);
Ny = length(Yclass);

%%%%%%% total number of data points %%%%%%
N = Nx + Ny;

%%%%%% build matrices needed for iterative least squares %%%%%%
% rearrange kernel matrix
XY_perm=[Xclass;Yclass];
K = Kmat(XY_perm,XY_perm);
% build Lx and Ly
Kx = K(1:Nx,:);
Ky = K(Nx+1:N,:);
tx = mean(Kx)';
ty = mean(Ky)';
tKx = Kx - ones(Nx,1)*tx';
tKy = Ky - ones(Ny,1)*ty';

% vector gamma0
d = (tx - ty);
gamma0 = d/(d'*d);
% matrix F -- orthogonal matrix whose columns span the subspace of vectors orthogonal to gamma0
f = zeros(1,N-1);
[maxel,maxind]=max(d);
for i=1:maxind-1,
   f(1,i) = -d(i,1)/maxel;
end
for i=maxind:N-1,
   f(1,i) = -d(i+1,1)/maxel;
end
IN_1 = eye(N-1);
F = [IN_1(1:maxind-1,:); f; IN_1(maxind:N-1,:)];

% Parametric FP
% Making the matrix in the denominator positive definite
Vsol = 1/Nx*tKx'*tKx+rho_x*K;
Csq = F'*Vsol*F;
Cc = F'*Vsol*gamma0;
Wsol = 1/Ny*tKy'*tKy+rho_y*K;
Dsq = F'*Wsol*F;
Dd = F'*Wsol*gamma0;

%%%%%%%%%%%%% Outer iterations  %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Parametric Method %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize lambda
lambda = 0.1;
outiter = 1;
l_d(outiter) = lambda;
rel_ql_ch = 10*tol;

while and(rel_ql_ch > tol, outiter<PMiter)
    
	% matrices for least squares step
	
	%%%%%%%%%%%%% ITERATIVE LEAST SQUARES %%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%% initialization %%%%%%
	eta_k = 1;
	xi_k = 1;
	iter = 1;
	rel_obj_ch = 10*tol;
	z_k = 0;
    tkx = lambda+nu_x;
    tky = lambda+nu_y;

	%%%%%% Inner iterations %%%%%%%
	while and(rel_obj_ch > tol,iter<50),
        LSmat = tkx*tkx/eta_k*Csq + tky*tky/xi_k*Dsq;
        LSmat = LSmat + algoparam*eye(size(LSmat));
        LSvect = -(tkx*tkx/eta_k*Cc + tky*tky/xi_k*Dd);
        z_k = pinv(LSmat)*LSvect;
        g_k = F*z_k+gamma0;
        arg1 = sqrt(g_k'*Vsol*g_k);
        arg2 = sqrt(g_k'*Wsol*g_k);
        eta_kp1 = tkx*arg1;
        xi_kp1 = tky*arg2;
        tt = eta_k+eta_kp1^2/eta_k+xi_k+xi_kp1^2/xi_k;
        Lobj_old = 2*(eta_k + xi_k);
        Lobj_new = 2*(eta_kp1 + xi_kp1);
        rel_obj_ch = abs(Lobj_new-Lobj_old)/abs(Lobj_old);
        iter = iter + 1;
        eta_k = eta_kp1;
        xi_k = xi_kp1;
        tt = eta_k+eta_kp1^2/eta_k+xi_k+xi_kp1^2/xi_k;
    end
    denom = arg1+arg2;
    nom = nu_x*arg1+nu_y*arg2;
	rel_ql_ch = abs(1-nom-lambda*denom);
    lambda = (1-nom)/denom;
	outiter = outiter + 1;
	l_d(outiter) = lambda;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% since \lambda increases after each iteration and the maximal
    %% value of alfa_temp is 1, we can determine the iteration beforehand
    %% if (1-alfa_temp) < tol
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if gauss_assump==1
        alfa_temp = normcdf(lambda,0,1);
	else
        alfa_temp = lambda^2/(1+lambda^2);
	end
	if (1-alfa_temp<tol) break; end;

    if outiter/90 ~= round(outiter/90)
        fprintf('.');
    else
        fprintf('\n');
    end
end;
fprintf('\n');

%%%%%%%%%%%%% ASSIGN OUTPUTS %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vgamma = gamma0 + F*z_k;
s = sqrt(vgamma'*Vsol*vgamma);
t = sqrt(vgamma'*Wsol*vgamma);
b = mean([(vgamma'*tx-1+(lambda+nu_y)*t), (vgamma'*ty + (lambda+nu_y)*t)]);
ka = (1-(nu_x*s+nu_y*t))/(s+t);
kalfa = max([ka 0]);
if gauss_assump==1
    alfa_k = normcdf(kalfa,0,1);
else
    alfa_k = kalfa^2/(1+kalfa^2);
end

% put gamma in the right order (such that the weights correspond to the resp.
% entries of Kmat rather than K)
vgamma(XY_perm) = vgamma;
