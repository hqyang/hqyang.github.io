clear all;
echo off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%      Minimum Error Minimax Probability Machine (MEMPM)              %%%%%%                    
%%%%%%          Toolbox Demonstrations For Toy Dataset                     %%%%%%                                    
%%%%%%                                                                     %%%%%%
%%%%%%            1. linear MEMPM                                          %%%%%%
%%%%%%            2. robust linear MEMPM                                   %%%%%%
%%%%%%            3. kernelized MEMPM                                      %%%%%%                                                   
%%%%%%            4. robust kernelized MEMPM                               %%%%%%
%%%%%%                                                                     %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  Yang Haiqin  March 2004                                             %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%   Data Format:                                                      %%%%%%
%%%%%%       [ .......features...... | class ]                             %%%%%%
%%%%%%       - one row per data point                                      %%%%%%
%%%%%%       - one column per feature                                      %%%%%%
%%%%%%       - 'class' is the class-label: -1 / +1                         %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on; 

clc
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
%   Load the training data and plot the data
%   Note: You can load your own dataset here
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue 
echo off;

%%%%%% to GET THE TOYDATA                                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% load a variable 'data' containing the toydata
load mempm
%% class +1 : 60 points generated from a gaussian with covariance matrix [1, 0; 0, 3] and mean [ 3, 0]^T
%% class -1 : 60 points generated from a gaussian with covariance matrix [3, 0; 0, 1] and mean [-3, 0]^T

%%%%%% to GET YOUR OWN DATA                                 %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%data = [ .......features...... | class ];

%% total number of datapoints
n = size(data,1);
%% dimension of the data
d = size(data,2)-1;
%% assign the features of all datapoints of class +1 to variable 'X'
X = data(find(data(:,d+1)==1),1:d);
%% assign the features of all datapoints of class -1 to variable 'Y'
Y = data(find(data(:,d+1)==-1),1:d);


%%%%%% to PLOT THE TOYDATA                                  %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot class +1 as +'s and class -1 as squares
figure(1)
plot(X(:,1), X(:,2), 'k+', Y(:,1), Y(:,2), 'ms');
title('Data: Class +1 depicted as + and Class -1 depicted as squares');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% split data in training and test data                %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% split TOYDATA in training and test data             %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% training data = first 20 data points in 'data' (being 10 points of class +1
%% and 10 points of class -1)
training_points = [1:20]';
%% test data = last 100 data points in 'data' (being 50 points of class +1 and
%% 50 points of class -1)
test_points = [21:120]';

%%%%%% split YOUR OWN DATA in training and test data       %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% training_points = vector containing row numbers in 'data' corresponding to training points;
% test_points     = vector containing row numbers in 'data' corresponding to test points;

%% all training data points
data_train = data(training_points,:);
%% number of training data points
n_train = size(data_train,1);
%% all test data points
data_test = data(test_points,:);
%% training data features for class +1 : Xtrain
Xtrain = data_train(find(data_train(:,d+1)==1),1:d);
%% training data features for class -1 : Ytrain
Ytrain = data_train(find(data_train(:,d+1)==-1),1:d);
%% test data features for class +1 : Xtest
Xtest = data_test(find(data_test(:,d+1)==1),1:d);
%% test data features for class -1 : Ytest
Ytest = data_test(find(data_test(:,d+1)==-1),1:d);

Nx = size(Xtrain,1);
Ny = size(Ytrain,1);
%%%%%%  estimate prior probability from the training data points          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xprior = Nx/(Nx+Ny);
yprior = Ny/(Nx+Ny);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      1.  LINEAR MEMPM                                %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using linear MEMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  estimate mean and covariance matrix from the training data points %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% class +1
xhat = mean(Xtrain)'; 
Sx = cov(Xtrain,1);
%% class -1
yhat = mean(Ytrain)';
Sy = cov(Ytrain,1);


%%%%%%  train linear MEMPM for TOYDATA                                     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Here we make the gaussian assumption
gauss_assump = 1;
tol = 0.0001;

%% Under gaussian assumption, the optimization for the BMPM is convex when
%% beta>=0.5. This is a slight constraint for data with gaussian distribution.
%% 
%% You may specific suitable beta for the three-point pattern Quadratic Interpolation line search here.
%% Here we set beta(1)=min_beta, beta(3)=max_beta,beta(2)=(min_beta+max_beta)/2.
%% max_beta is obtained when alpha is set to (a value approaching to) its minimum. 
%% Due to the symmetry of alpha and beta, min_alpha=min_beta.
if(gauss_assump)
	beta(1) = 0.5001; 
else
    beta(1) = 0.0001; 
end
min_alpha = beta(1);
beta_up = solve_FP_RG(yhat,xhat,Sy,Sx,min_alpha,gauss_assump,0.1,0.0001,5000);
%% To avoid dividing by zero in kappa(beta_up), we make the maximum beta_up<1. 
if beta_up > 1-tol beta_up = 1-tol; end;
beta(3) = beta_up;
beta(2) = (beta(1)+beta(3))/2;
[alpha_lin, beta_lin, a, b] = build_MEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,xprior,gauss_assump,beta,0.1,0.0001,500,5000);

%% There are total 11 parameters for the function, 'build_MEMPM_lin_bi_QI'.
%% More details can be found by 'help build_MEMPM_lin_bi_QI'

%%%%%%  train linear MEMPM for YOUR OWN DATA                              %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_lin, beta_lin, a, b] = build_MEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,xprior,..6,..,..7..,..8..,..9..,..10..,..11..);
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..6.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%% ..7.. is the initial parameters for the three-pattern QI method, its norm
%%       equal to 0 will lead to the default value
%% ..8.., ..9.., ..10..,11 are internal parameters of the algorithm: putting them 
%%       equal to '-1', will result in the use of default values
%% 
%% for more details: 'help build_MEMPM_lin_bi_QI'

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Plot the linear MEMPM and display its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot training data for class +1 as +'s and for class -1 as squares
figure(2)
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
%% plot decision line in black dash-dot
h1 = plot([(b+5*a(2,1))/a(1,1), (b-5*a(2,1))/a(1,1)],[-5,5],'k-.');

%%%%%% evaluate performance of the MEMPM                    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a,b);

%%%%%% evaluate performance of the MEMPM                    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a,b);
%% for more details about this function: 'help eval_lin_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

%% display relevant values
disp('Underbound on correct classification of future data-Class 1:');
disp(alpha_lin*100);
disp('Underbound on correct classification of future data-Class 2:');
disp(beta_lin*100);
disp('Underbound on correct classification of future data:');
disp((xprior*alpha_lin+yprior*beta_lin)*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      2.  ROBUST LINEAR MEMPM                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using robust linear MEMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  estimate mean and covariance matrix from the training data points %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% class +1
xhat = mean(Xtrain)';
Sx = cov(Xtrain,1);
%% class -1
yhat = mean(Ytrain)';
Sy = cov(Ytrain,1);

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% since we know the true mean and covariance matrices, we can calculate nu_x, 
%% nu_y, rho_x and rho_y as follows for the toy example:
Mx = [ 3, 0]'; Covx = [1 0; 0 3];
My = [-3, 0]'; Covy = [3 0; 0 1];

%% nu_x -- uncertainty in mean for class +1
nu_x = sqrt((xhat-Mx)'*inv(Covx)*(xhat-Mx));
%% nu_y -- uncertainty in mean for class -1
nu_y = sqrt((yhat-My)'*inv(Covy)*(yhat-My));
nu0 = max([nu_x nu_y]);
%% rho_x -- uncertainty in covariance matrix for class +1
rho_x = norm(Sx-Covx,'fro');
%% rho_y -- uncertainty in covariance matrix for class -1
rho_y = norm(Sy-Covy,'fro');

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for YOUR DATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for real data, the true mean and covariance matrices are unknown
%%
%% nu_x, nu_y, rho_x and rho_y could be estimated using resampling methods, 
%% the central limit theorem or cross-validation
%%
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;


%%%%%%  train robust linear MEMPM for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Under gaussian assumption, the optimization for the BMPM is convex when
%% beta>=0.5. This is a slight constraint for data with gaussian distribution.
%% 
%% You may specific suitable beta for the three-point pattern Quadratic Interpolation line search here.
%% Here we set beta(1)=min_beta, beta(3)=max_beta,beta(2)=(min_beta+max_beta)/2.
%% max_beta is obtained when alpha is set to (a value approaching to) its minimum. 
%% Due to the symmetry of alpha and beta, min_alpha=min_beta.
if(gauss_assump)
	beta(1) = 0.5001; 
else
    beta(1) = 0.0001; 
end
min_alpha = beta(1);
beta_up = solve_robFP_RG(yhat,xhat,Sy,Sx,min_alpha,nu_x,nu_y,rho_x,rho_y,gauss_assump,0.1,0.0001,5000);
%% To avoid dividing by zero in kappa(beta_up), we make the maximum beta_up<1.
if beta_up > 1-tol beta_up = 1-tol; end;
beta(3) = beta_up;
beta(2) = (beta(1)+beta(3))/2;

[alpha_lin_rob, beta_lin_rob, a_rob, b_rob] = build_robMEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,nu_x,nu_y,rho_x,rho_y,xprior,gauss_assump,beta,0.1,0.0001,500,5000);

%% There are total 15 input parameters for the function, 'build_MEMPM_lin_bi_QI'.
%% More details can be found by 'help build_robMEMPM_lin_bi_QI'

%%%%%%  train robust linear MEMPM for YOUR OWN DATA                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_lin_rob, beta_lin_rob, a_rob, b_rob] = build_robMEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,nu_x,nu_y,rho_x,rho_y,xprior,..10..,..11..,..12..,..13..,..14..,..15..);
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..10.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%% ..11.. is the initial parameters for the three-pattern QI method, its norm
%%       equal to 0 will lead to the default value
%% ..12.., ..13.., ..14..,..15.. are internal parameters of the algorithm: putting them 
%%       equal to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMEMPM_lin_bi_QI'

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Plot the robust linear MEMPM and display its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot decision line in blue solid line
h2 = plot([-4 4],[(b_rob+4*a_rob(1,1))/a_rob(2,1) (b_rob-4*a_rob(1,1))/a_rob(2,1)],'r-');

legend([h1,h2],'MEMPM','robMEMPM',3);

%%%%%% evaluate performance of the robust MEMPM             %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a_rob,b_rob);


%%%%%% evaluate performance of the robust MEMPM             %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a_rob,b_rob);
%% for more details about this function: 'help eval_lin_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

%% display relevant values
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_lin_rob*100);
disp('Robust underbound on correct classification of future data-Class 2:');
disp(beta_lin_rob*100);
disp('Robust underbound on correct classification of future data:');
disp((xprior*alpha_lin_rob+yprior*beta_lin_rob)*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      3.  KERNELIZED MEMPM                          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using kernelized MEMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  build the kernel matrix (aka Gram matrix)                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  K has the following block structure:                              %%%%%%%
%%%%%%                   K = [K_tr K_trt; K_trt^T K_t]                    %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  where            K_ij = Phi(x_i)^T Phi(x_j)                       %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  for i,j = 1,... , n_train, n_train + 1, ..., n_train + n_test     %%%%%%%
%%%%%%      with n_train: the number of training data points              %%%%%%%
%%%%%%           n_test : the number of test     data points              %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  So, K can be split into a ``training-data block'' K_tr, a ``mixed %%%%%%%
%%%%%%  block'' K_trt and a ``test-data block'' K_t                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%  build K for TOYDATA, using a linear kernel function:              %%%%%%%
%%%%%%  K_ij = x_i^T x_j                                                  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build K for YOUR OWN DATA                                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%K = a positive semi-definite matrix;
%% here, you can use whichever way you prefer to construct a kernel matrix, 
%% e.g. through the evaluation of a kernel function, by using dynamic
%%      programming to build a similarity measure between the different data points, 
%%      by using a linear combination of given kernel matrices, ...
%%
%% e.g., to build a kernel matrix for YOUR OWN DATA, using a linear kernel
%% function, you could use the following line of code:
%% K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';


%%%%%%  build the corresponding label vector                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  the order of the labels should correspond to the order of the     %%%%%%%
%%%%%%  training and test points in the kernel matrx K                    %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
labels = [data_train(:,d+1);data_test(:,d+1)];

%% Under gaussian assumption, the optimization for the BMPM is convex when
%% beta>=0.5. This is a slight constraint for data with gaussian distribution.
%% 
%% You may need to specific suitable beta for the three-point pattern Quadratic Interpolation line search here.
%% Here we set beta(1)=min_beta, beta(3)=max_beta,beta(2)=(min_beta+max_beta)/2.
%% max_beta is obtained when alpha is set to (a value approaching to) its minimum. 
%% Due to the symmetry of alpha and beta, min_alpha=min_beta.
if(gauss_assump)
	beta(1) = 0.5001; 
else
    beta(1) = 0.0001; 
end
min_alpha = beta(1);
rlabels = -labels;
beta_up = build_BMPM_k_bi_PM(K(1:n_train,1:n_train),rlabels(1:n_train),min_alpha,gauss_assump,0.0001,0.0001,50);
%% To avoid diving by zero in kappa(beta_up), we make the maximum beta_up<1.
if beta_up > 1-tol beta_up = 1-tol; end;
beta(3) = beta_up;
beta(2) = (beta(1)+beta(3))/2;

[alpha_k, beta_k, gamma_k, b_k] = build_MEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),gauss_assump,beta,0.0001,0.0001,500,50);
%%%%%%  train kernelized MEMPM for TOYDATA                                %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% notice that we make the gaussian assumption here (3rd input is equal to 1)
%%
%% input 4-8 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_MEMPM_k_bi_QI'

%%%%%%  train kernelized MEMPM for YOUR OWN DATA                          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_k, beta_k, gamma_k, b_k] = build_MEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),..3..,..4..,..5..,..6..,..7..,..8..);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..3.. is '1' if you assume that both classes are Gaussian distributed in
%%       the feature space (i.e., the space where the mapped data points Phi(z)
%%       live), '0' for the general case
%%
%% ..4.. is the initial parameters for the three-pattern QI method, its norm
%%       equal to 0 will lead to the default value
%% ..5.., ..6..,..7..,..8.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_MEMPM_k_bi_QI'

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Display the kernelized MEMPM and its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3);
hold on
syms w x y ax ay f;
f = subs(f,-b_k);
for i=1:n_train;
   f = f + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_k(i),data_train(i,1),data_train(i,2)});
end;
% The kernelized boundary is solved by f=0 and plotted as blue line
ezplot(f,[-8 6]);
% The linear boundary is plotted as black dash-dot line
plot([(b+5*a(2,1))/a(1,1), (b-5*a(2,1))/a(1,1)],[-5,5],'k-.');
legend('kernel','linear',3);
%% plot training data for class +1 as +'s and for class -1 as squares
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
%% plot decision line corresponding to linear MEMPM in black dash-dot

[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,labels,gamma_k,b_k);
%%%%%% evaluate performance of the MEMPM                    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty, pg_trtx, pg_trty] = eval_k_bi(K,labels,gamma_k,b_k);
%% for more details about this function: 'help eval_k_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

%% display relevant values
disp('Underbound on correct classification of future data-Class 1:');
disp(alpha_k*100);
disp('Underbound on correct classification of future data-Class 2:');
disp(beta_k*100);
disp('Underbound on correct classification of future data:');
disp((xprior*alpha_k+yprior*beta_k)*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      4.  ROBUST KERNELIZED MEMPM                   %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using robust kernelized MEMPM.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  build the kernel matrix (aka Gram matrix)                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  K has the following block structure:                              %%%%%%%
%%%%%%                   K = [K_tr K_trt; K_trt^T K_t]                    %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  where            K_ij = Phi(x_i)^T Phi(x_j)                       %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  for i,j = 1,... , n_train, n_train + 1, ..., n_train + n_test     %%%%%%%
%%%%%%      with n_train: the number of training data points              %%%%%%%
%%%%%%           n_test : the number of test     data points              %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  So, K can be split into a ``training-data block'' K_tr, a ``mixed %%%%%%%
%%%%%%  block'' K_trt and a ``test-data block'' K_t                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%  build K for TOYDATA, using a linear kernel function:              %%%%%%%
%%%%%%  K_ij = x_i^T x_j                                                  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build K for YOUR OWN DATA                                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%K = a positive semi-definite matrix;
%% here, you can use whichever way you prefer to construct a kernel matrix, 
%% e.g. through the evaluation of a kernel function, by using dynamic
%%      programming to build a similarity measure between the different data points, 
%%      by using a linear combination of given kernel matrices, ...
%%
%% e.g., to build a kernel matrix for YOUR OWN DATA, using a linear kernel
%% function, you could use the following line of code:
%% K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build the corresponding label vector                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  the order of the labels should correspond to the order of the     %%%%%%%
%%%%%%  training and test points in the kernel matrx K                    %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
labels = [data_train(:,d+1);data_test(:,d+1)];

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for real data, the true mean and covariance matrices are unknown in the
%% feature space
%%
%% nu_x, nu_y, rho_x, and rho_y could be estimated using resampling methods, 
%% the central limit theorem or cross-validation

%% Since we use a linear kernel for the TOYDATA here, we use as values for those
%% parameters the values we earlier assigned to them for the robust linear MEMPM
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;


%% Under gaussian assumption, the optimization for the BMPM is convex when
%% beta>=0.5. This is a slight constraint for data with gaussian distribution.
%% 
%% You may specific suitable beta for the three-point pattern Quadratic Interpolation line search here.
%% Here we set beta(1)=min_beta, beta(3)=max_beta,beta(2)=(min_beta+max_beta)/2.
%% max_beta is obtained when alpha is set to (a value approaching to) its minimum. 
%% Due to the symmetry of alpha and beta, min_alpha=min_beta.
if(gauss_assump)
	beta(1) = 0.5001; 
else
    beta(1) = 0.0001; 
end
min_alpha = beta(1);
rlabels = -labels;
beta_up = build_robBMPM_k_bi_PM(K(1:n_train,1:n_train),rlabels(1:n_train),min_alpha,nu_x,nu_y,rho_x,rho_y,gauss_assump,0.0001,0.0001,50);
%% To avoid dividing by zero in kappa(beta_up), we make the maximum beta_up<1.
if beta_up > 1-tol beta_up = 1-tol; end;
beta(3) = beta_up;
beta(2) = (beta(1)+beta(3))/2;

%%%%%%  train kernelized MEMPM for TOYDATA                                %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[alpha_kr, beta_kr, gamma_kr, b_kr] = build_robMEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,gauss_assump,beta,0.0001,0.0001,500,50);

%[alpha_kr, gamma_kr, b_kr] = build_robMPM_k_binclass_LSreg(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,1,0.0001,0.0001,500,50);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% notice that we make the gaussian assumption here (7th input is equal to 1)
%%
%% input 8-12 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_robMEMPM_k_bi_QI'

%%%%%%  train kernelized MEMPM for YOUR OWN DATA                            %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_kr, beta_kr, gamma_kr, b_kr] = build_robMEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,..7..,..8..,..9..,..10..,..11..,..12..);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..7.. is '1' if you assume that both classes are Gaussian distributed in
%%       the feature space (i.e., the space where the mapped data points Phi(z)
%%       live), '0' for the general case
%% ..8.. is the initial parameters for the three-pattern QI method, its norm
%%       equal to 0 will lead to the default value
%% ..9.., ..10.., ..11..,..12.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMEMPM_k_bi_QI'

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Display the robust kernelized MEMPM and its results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4)
hold on
syms w x y ax ay f;
f = subs(f,-b_kr);
for i=1:n_train;
    f = f + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_kr(i),data_train(i,1),data_train(i,2)});
end;
%% The kernelized boundary is solved by f=0 and plotted as a blue line.
ezplot(f);
%% The linear boundary is plotted as a red line.
plot([-4 4],[(b_rob+4*a_rob(1,1))/a_rob(2,1) (b_rob-4*a_rob(1,1))/a_rob(2,1)],'r-');
legend('rob-kernel','rob-linear',3);

%% plot training data for class +1 as +'s and for class -1 as squares
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
%% plot decision line corresponding to robust linear MEMPM in blue solid line

%%%%%% evaluate performance of the MEMPM                    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,labels,gamma_kr,b_kr);
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty, pg_trtx, pg_trty] = eval_k_bi(K,labels,gamma_kr,b_kr);
%% for more details about this function: 'help eval_k_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)


%% display relevant values
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_kr*100);
disp('Robust underbound on correct classification of future data-Class 2:');
disp(beta_kr*100);
disp('Robust underbound on correct classification of future data:');
disp((xprior*alpha_kr+yprior*beta_kr)*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);