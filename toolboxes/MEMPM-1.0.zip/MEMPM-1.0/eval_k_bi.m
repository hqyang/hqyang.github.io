function [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,Y,vgamma,b)
% eval_k_bi  - evaluate all minimax probability machines (kernelized version), including 
%               Minimum Error Minimax Probability Machine (MEMPM), Biased Minimax 
%               Probability Machine (BMPM), Minimax Probability Machine (MPM) for 
%               binary classification
%
% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,Y,vgamma,b)
%
%
% The inputs are
%  K        - an n-by-n Gram Matrix, corresponding to the n data points
%              n = total number of data points = n_train + n_test + n_unlab
%              n_train = number of training points    -- points with known class, used for training
%              n_test  = number of test points        -- points with known class, not used for training
%              n_unlab = number of unlabelled points  -- points with unknown class
%  y        - an (n_train+n_test)-vector containing the labels of the (n_train+n_test) labelled data points
%             (y contains n_train training point labels and n_test test point labels)
%  vgamma,b - model parameters for the classification (vgamma is an n_train-vector of weights, corresponding to the
%             n_train training data points; b is the offset)
% The outputs are
%   ng_tr   - number of well-classified trainig data points
%   pg_tr   - percentage of well-classified trainig data points (-1 if no training points)
%   ng_t    - number of well-classified test data points
%   pg_t    - percentage of well-classified test data points (-1 if no test points)
%   ng_trt  - number of well-classified data points (training + test)
%   pg_trt  - percentage of well-classified data points, training + test (-1 if no training + test points)
%   lab     - an n_unlab-vector containing the class-labels of the unlabelled data points, after classification
%   pg_trx  - percentage of well-classified trainig data points for class x (-1 if no training points for class x)
%   pg_try  - percentage of well-classified trainig data points for class y (-1 if no training points for class y)
%   pg_tx   - percentage of well-classified test data points for class x (-1 if no training points for class x)
%   pg_ty   - percentage of well-classified test data points for class y (-1 if no training points for class y)
%   pg_trtx - percentage of well-classified data points of class x, training + test (-1 if no training + test points for class x)
%   pg_trty - percentage of well-classified data points of class y, training + test (-1 if no training + test points for class y)
%


if (nargin ~= 4) % check correct number of arguments
    help eval_k_bi
else

n = size(K,1);
n_train = length(vgamma);
n_trt = length(Y);
n_test = n_trt - n_train;
n_unlab = n - n_trt;

% determine dimension of the input space

%train + test
X_class = find(Y==1);
X_size = length(X_class);
Y_class = find(Y==-1);
Y_size = length(Y_class);

%training
Atr = Y(1:n_train); % All train 
Xtr_class = find(Atr==1); % Haiqin: All train for class X
Xtr_size = length(Xtr_class); 
Ytr_class = find(Atr==-1); % Haiqin: All train for class Y
Ytr_size = length(Ytr_class);

%testing
Ats = Y(n_train+1:n_trt); % All test
Xts_class = find(Ats==1)+n_train; % All test for class X
Xts_size = length(Xts_class);
Yts_class = find(Ats==-1)+n_train;% All train for class Y
Yts_size = length(Yts_class);

% train
nw_tr = sum(abs(sign(sign(K(1:n_train,1:n_train)*vgamma - b*ones(n_train,1)) - Y(1:n_train,1))));
ng_tr = n_train - nw_tr;
if n_train == 0
    pg_tr = -1;
else
    pg_tr = 100 * ng_tr / n_train;
end

if Xtr_size == 0
    pg_trx = -1;
else
    Xnw_tr= sum(abs(sign(sign(K(Xtr_class,1:n_train)*vgamma - b*ones(Xtr_size,1)) - Atr(Xtr_class))));
    pg_trx=100-100*Xnw_tr/Xtr_size;
end
    
if Ytr_size == 0
    pg_try = -1;
else
    Ynw_tr= sum(abs(sign(sign(K(Ytr_class,1:n_train)*vgamma - b*ones(Ytr_size,1)) - Atr(Ytr_class))));
    pg_try=100-100*Ynw_tr/Ytr_size;
end

% test
nw_ts = sum(abs(sign(sign(K(n_train+1:n_trt,1:n_train)*vgamma - b*ones(n_test,1)) - Y(n_train+1:n_trt,1))));
ng_t = n_test - nw_ts;

if n_test == 0
    pg_t = -1;
else
    pg_t = 100 * ng_t / n_test;
end

if Xts_size == 0
    pg_tx = -1;
else
    Xnw_ts= sum(abs(sign(sign(K(Xts_class,1:n_train)*vgamma - b*ones(Xts_size,1)) - Y(Xts_class))));
    pg_tx=100-100*Xnw_ts/Xts_size;
end
    
if Yts_size == 0
    pg_ty = -1;
else
    Ynw_ts= sum(abs(sign(sign(K(Yts_class,1:n_train)*vgamma - b*ones(Yts_size,1)) - Y(Yts_class))));
    pg_ty=100-100*Ynw_ts/Yts_size;
end

% train + test
nw_trt = sum(abs(sign(sign(K(1:n_trt,1:n_train)*vgamma - b*ones(n_trt,1)) - Y(1:n_trt,1))));
ng_trt = n_trt - nw_trt;
if n_trt == 0
    pg_trt = -1;
else
    pg_trt = 100 * ng_trt / n_trt;
end

if X_size == 0
    pg_trtx = -1;
else
    Xnw_trt= sum(abs(sign(sign(K(X_class,1:n_train)*vgamma - b*ones(X_size,1)) - Y(X_class))));
    pg_trtx = 100 - 100*Xnw_trt/X_size;
end;

if Y_size == 0
    pg_trty = -1;
else
    Ynw_trt= sum(abs(sign(sign(K(Y_class,1:n_train)*vgamma - b*ones(Y_size,1)) - Y(Y_class))));
    pg_trty = 100 - 100*Ynw_trt/Y_size;
end;

if n_unlab == 0
    lab = [];
else
    lab = sign(K(n_trt+1:n,1:n_train)*vgamma - b*ones(n_unlab,1));
end

end