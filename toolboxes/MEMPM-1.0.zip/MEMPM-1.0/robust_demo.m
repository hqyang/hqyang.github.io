clear all;
echo off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%       Robust Version: Minimum Error Minimax Probability             %%%%%%                    
%%%%%%       Machine (MEMPM), Minimax Probability Machine (MPM)            %%%%%%                                                 
%%%%%%            Toolbox Demonstrations For Toy Dataset                   %%%%%%                                    
%%%%%%                                                                     %%%%%%
%%%%%%            1.1 robust linear MEMPM: nu_x~=nu_y                      %%%%%%
%%%%%%            1.2 robust linear MEMPM: nu_x =nu_y                      %%%%%%
%%%%%%            1.3 robust linear MPM: nu_x~=nu_y                        %%%%%%
%%%%%%            1.4 robust linear MPM: nu_x =nu_y                        %%%%%%
%%%%%%                                                                     %%%%%% 
%%%%%%            2.1 robust kernelized MEMPM: nu_x~=nu_y                  %%%%%%
%%%%%%            2.2 robust kernelized MEMPM: nu_x =nu_y                  %%%%%%
%%%%%%            2.3 robust kernelized MPM: nu_x~=nu_y                    %%%%%%
%%%%%%            2.4 robust kernelized MPM: nu_x =nu_y                    %%%%%%
%%%%%%                                                                     %%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  Yang Haiqin  March 2004                                             %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%   Data Format:                                                      %%%%%%
%%%%%%       [ .......features...... | class ]                             %%%%%%
%%%%%%       - one row per data point                                      %%%%%%
%%%%%%       - one column per feature                                      %%%%%%
%%%%%%       - 'class' is the class-label: -1 / +1                         %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on; 


clc
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
%   Load the training data and plot the data
%   Note: You can load your own dataset here
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue 
echo off;

%%%%%% to GET THE TOYDATA                                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% load a variable 'data' containing the toydata
load mempm
%% class +1 : 60 points generated from a gaussian with covariance matrix [1, 0; 0, 3] and mean [ 3, 0]^T
%% class -1 : 60 points generated from a gaussian with covariance matrix [3, 0; 0, 1] and mean [-3, 0]^T

%%%%%% to GET YOUR OWN DATA                                 %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%data = [ .......features...... | class ];

%% total number of datapoints
n = size(data,1);
%% dimension of the data
d = size(data,2)-1;
%% assign the features of all datapoints of class +1 to variable 'X'
X = data(find(data(:,d+1)==1),1:d);
%% assign the features of all datapoints of class -1 to variable 'Y'
Y = data(find(data(:,d+1)==-1),1:d);


%%%%%% to PLOT THE TOYDATA                                  %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot class +1 as +'s and class -1 as squares
figure(1)
plot(X(:,1), X(:,2), 'k+', Y(:,1), Y(:,2), 'ms');
title('Data: Class +1 depicted as + and Class -1 depicted as square');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% split data in training and test data                %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% split TOYDATA in training and test data             %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% training data = first 20 data points in 'data' (being 10 points of class +1
%% and 10 points of class -1)
training_points = [1:20]';
%% test data = last 100 data points in 'data' (being 50 points of class +1 and
%% 50 points of class -1)
test_points = [21:120]';

%%%%%% split YOUR OWN DATA in training and test data       %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% training_points = vector containing row numbers in 'data' corresponding to training points;
% test_points     = vector containing row numbers in 'data' corresponding to test points;

%% all training data points
data_train = data(training_points,:);
%% number of training data points
n_train = size(data_train,1);
%% all test data points
data_test = data(test_points,:);
%% training data features for class +1 : Xtrain
Xtrain = data_train(find(data_train(:,d+1)==1),1:d);
%% training data features for class -1 : Ytrain
Ytrain = data_train(find(data_train(:,d+1)==-1),1:d);
%% test data features for class +1 : Xtest
Xtest = data_test(find(data_test(:,d+1)==1),1:d);
%% test data features for class -1 : Ytest
Ytest = data_test(find(data_test(:,d+1)==-1),1:d);

Nx = size(Xtrain,1);
Ny = size(Ytrain,1);
%%%%%%  estimate prior probability from the training data points          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xprior = Nx/(Nx+Ny);
yprior = Ny/(Nx+Ny);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      1.  ROBUST LINEAR VERSION                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using robust linear MEMPM
% and robust linear MPM with nu_x(~)=nu_y
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  estimate mean and covariance matrix from the training data points %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% class +1
xhat = mean(Xtrain)'; 
Sx = cov(Xtrain,1);
%% class -1
yhat = mean(Ytrain)';
Sy = cov(Ytrain,1);

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% since we know the true mean and covariance matrices, we can calculate nu_x, 
%% nu_y, rho_x and rho_y as follows for the toy example:
Mx = [ 3, 0]'; Covx = [1 0; 0 3];
My = [-3, 0]'; Covy = [3 0; 0 1];

%% nu_x -- uncertainty in mean for class +1
nu_x = sqrt((xhat-Mx)'*inv(Covx)*(xhat-Mx));
%% nu_y -- uncertainty in mean for class -1
nu_y = sqrt((yhat-My)'*inv(Covy)*(yhat-My));
nu = max([nu_x nu_y]);
%% rho_x -- uncertainty in covariance matrix for class +1
rho_x = norm(Sx-Covx,'fro');
%% rho_y -- uncertainty in covariance matrix for class -1
rho_y = norm(Sy-Covy,'fro');

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for YOUR DATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for real data, the true mean and covariance matrices are unknown
%%
%% nu_x, nu_y, rho_x and rho_y could be estimated using resampling methods, 
%% the central limit theorem or cross-validation
%%
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% nu -- uncertainty in mean
%nu = max([nu_x nu_y]);
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;

%%%%%%  train robust linear MEMPM for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Here we make the gaussian assumption
gauss_assump = 1;
tol = 1e-4;

%% Under gaussian assumption, the optimization for the BMPM is convex when
%% beta>=0.5. This is a slight constraint for data with gaussian distribution.
%% 
%% You may specific suitable beta for the three-point pattern Quadratic Interpolation line search here.
%% Here we set beta(1)=min_beta, beta(3)=max_beta,beta(2)=(min_beta+max_beta)/2.
%% max_beta is obtained when alpha is set to (a value approaching to) its minimum. 
%% Due to the symmetry of alpha and beta, min_alpha=min_beta.
if(gauss_assump)
	beta(1) = 0.5001; 
else
    beta(1) = 0.0001; 
end
min_alpha = beta(1);
beta_up = solve_robFP_RG(yhat,xhat,Sy,Sx,min_alpha,nu_x,nu_y,rho_x,rho_y,gauss_assump,0.1,1e-4,5000);
%% To avoid dividing by zero in kappa(beta_up), we make the maximum beta_up<1.
if beta_up > 1-tol beta_up = 1-tol; end;
beta(3) = beta_up;
beta(2) = (beta(1)+beta(3))/2;

%% robust linear MEMPM: nu_x~=nu_y
[alpha_lin_rob, beta_lin_rob, a_rob, b_rob] = build_robMEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,nu_x,nu_y,rho_x,rho_y,xprior,gauss_assump,beta,0.1,1e-4,500,5000);

%% robust linear MEMPM: nu_x=nu_y=nu
[alpha_lin_rob2, beta_lin_rob2, a_rob2, b_rob2] = build_robMEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,nu,nu,rho_x,rho_y,xprior,gauss_assump,beta,0.1,1e-4,500,5000);

%% There are total 15 input parameters for the function, 'build_MEMPM_lin_bi_QI'.
%% More details can be found by 'help build_robMEMPM_lin_bi_QI'

%%%%%%  train robust linear MEMPM for YOUR OWN DATA                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_lin_rob, beta_lin_rob, a_rob, b_rob] = build_robMEMPM_lin_bi_QI(xhat,yhat,Sx,Sy,nu_x,nu_y,rho_x,rho_y,xprior,..10..,..11..,..12..,..13..,..14..,..15..);
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..10.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%% ..11.. is the initial parameters for the three-pattern QI method, its norm
%%       equal to 0 will lead to the default value
%% ..12.., ..13.., ..14..,..15.. are internal parameters of the algorithm: putting them 
%%       equal to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMEMPM_lin_bi_QI'

%%%%%%  train robust linear MPM for TOYDATA                               %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% robust linear MPM: nu_x~=nu_y
[alpha_lin_rob0, a_rob0, b_rob0] = build_robMPMn_lin_bi_PM(xhat,yhat,Sx,Sy,nu_x,nu_y,rho_x,rho_y,gauss_assump,1e-4,1e-4,50);

%% robust linear MPM: nu_x=nu_y=nu
[alpha_lin_rob02, a_rob02, b_rob02] = build_robMPMn_lin_bi_PM(xhat,yhat,Sx,Sy,nu,nu,rho_x,rho_y,gauss_assump,1e-4,1e-4,50);

%% There are total 12 input parameters for the function, 'build_robMPMn_lin_bi_PM'.
%% More details can be found by 'help build_robMPMn_lin_bi_PM'

%%%%%%  train robust linear MPM for YOUR OWN DATA                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_lin_rob0, a_rob0, b_rob0] = build_robMPMn_lin_bi_PM(xhat,yhat,Sx,Sy,nu_x,nu_y,rho_x,rho_y,gauss_assump,..10..,..11..,..12..);
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..10.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%% ..11.., ..12.. are internal parameters of the algorithm: putting them 
%%       equal to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMPMn_lin_bi_PM'


echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Plot the robust lines and display their results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot training data for class +1 as +'s and for class -1 as squares
figure(2)
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
%% plot decision line of robust linear MEMPM with nu_x~=nu_y in blue solid
h1 = plot([(b_rob+5*a_rob(2,1))/a_rob(1,1), (b_rob-5*a_rob(2,1))/a_rob(1,1)],[-5,5],'b-');
%% plot decision line of robust linear MEMPM with nu_x=nu_y in black dash-dot
h2 = plot([(b_rob2+5*a_rob2(2,1))/a_rob2(1,1), (b_rob2-5*a_rob2(2,1))/a_rob2(1,1)],[-5,5],'k-.');
%% plot decision line of robust linear MPM with nu_x~=nu_y in magenta dotted
h3 = plot([(b_rob0+5*a_rob0(2,1))/a_rob0(1,1), (b_rob0-5*a_rob0(2,1))/a_rob0(1,1)],[-5,5],'m:');
%% plot decision line of robust linear MPM with nu_x=nu_y in red dash
h4 = plot([(b_rob02+5*a_rob02(2,1))/a_rob02(1,1), (b_rob02-5*a_rob02(2,1))/a_rob02(1,1)],[-5,5],'r--');

legend([h1,h2,h3,h4],'robMEMPM:\nu_x\neq\nu_y','robMEMPM:\nu_x=\nu_y=\nu','robMPM:\nu_x\neq\nu_y','robMPM:\nu_x=\nu_y=\nu',3);

%%%%%% evaluate performance of the robust MEMPM             %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% robust MEMPM with nu_x~=nu_y
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a_rob,b_rob);

%% robust MEMPM with nu_x=nu_y=nu
[ng_tr2,pg_tr2,ng_t2,pg_t2,ng_trt2,pg_trt2,lab2,pg_trx2,pg_try2,pg_tx2,pg_ty2,pg_trtx2,pg_trty2]=eval_lin_bi([data_train;data_test],n_train,a_rob2,b_rob2);

%% robust MPM with nu_x~=nu_y
[ng_tr0,pg_tr0,ng_t0,pg_t0,ng_trt0,pg_trt0,lab0,pg_trx0,pg_try0,pg_tx0,pg_ty0,pg_trtx0,pg_trty0]=eval_lin_bi([data_train;data_test],n_train,a_rob0,b_rob0);

%% robust MPM with nu_x=nu_y=nu
[ng_tr02,pg_tr02,ng_t02,pg_t02,ng_trt02,pg_trt02,lab02,pg_trx02,pg_try02,pg_tx02,pg_ty02,pg_trtx02,pg_trty02]=eval_lin_bi([data_train;data_test],n_train,a_rob02,b_rob02);

%%%%%% evaluate performance of the robust MEMPM             %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty]=eval_lin_bi([data_train;data_test],n_train,a_rob,b_rob);
%% for more details about this function: 'help eval_lin_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)

%% display relevant values
disp('>>>>>>>>>> Results of linear MEMPM with nu_x~=nu_y <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_lin_rob*100);
disp('Robust underbound on correct classification of future data-Class 2:');
disp(beta_lin_rob*100);
disp('Robust underbound on correct classification of future data:');
disp((xprior*alpha_lin_rob+yprior*beta_lin_rob)*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

disp('>>>>>>>>>> Results of linear MEMPM with nu_x=nu_y=nu <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_lin_rob2*100);
disp('Robust underbound on correct classification of future data-Class 2:');
disp(beta_lin_rob2*100);
disp('Robust underbound on correct classification of future data:');
disp((xprior*alpha_lin_rob2+yprior*beta_lin_rob2)*100);

disp('Training set accuracy:');
disp(pg_tr2);
disp('Training set accuracy-Class 1:');
disp(pg_trx2);
disp('Training set accuracy-Class 2:');
disp(pg_try2);

disp('Test set accuracy:');
disp(pg_t2);
disp('Test set accuracy-Class 1:');
disp(pg_tx2);
disp('Test set accuracy-Class 2:');
disp(pg_ty2);

disp('>>>>>>>>>> Results of linear MPM with nu_x~=nu_y <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data');
disp(alpha_lin_rob0*100);

disp('Training set accuracy:');
disp(pg_tr0);

disp('Test set accuracy:');
disp(pg_t0);

disp('>>>>>>>>>> Results of linear MPM with nu_x=nu_y=nu <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data');
disp(alpha_lin_rob02*100);

disp('Training set accuracy:');
disp(pg_tr02);

disp('Test set accuracy:');
disp(pg_t02);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%                      2.  ROBUST KERNELIZED MEMPM                   %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Demonstration for using robust kernelized MEMPM.
% and robust kernelized MPM with nu_x(~)=nu_y
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%%  build the kernel matrix (aka Gram matrix)                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  K has the following block structure:                              %%%%%%%
%%%%%%                   K = [K_tr K_trt; K_trt^T K_t]                    %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  where            K_ij = Phi(x_i)^T Phi(x_j)                       %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  for i,j = 1,... , n_train, n_train + 1, ..., n_train + n_test     %%%%%%%
%%%%%%      with n_train: the number of training data points              %%%%%%%
%%%%%%           n_test : the number of test     data points              %%%%%%%
%%%%%%                                                                    %%%%%%%
%%%%%%  So, K can be split into a ``training-data block'' K_tr, a ``mixed %%%%%%%
%%%%%%  block'' K_trt and a ``test-data block'' K_t                       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%  build K for TOYDATA, using a linear kernel function:              %%%%%%%
%%%%%%  K_ij = x_i^T x_j                                                  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build K for YOUR OWN DATA                                         %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%K = a positive semi-definite matrix;
%% here, you can use whichever way you prefer to construct a kernel matrix, 
%% e.g. through the evaluation of a kernel function, by using dynamic
%%      programming to build a similarity measure between the different data points, 
%%      by using a linear combination of given kernel matrices, ...
%%
%% e.g., to build a kernel matrix for YOUR OWN DATA, using a linear kernel
%% function, you could use the following line of code:
%% K = [data_train(:,1:d);data_test(:,1:d)]*[data_train(:,1:d);data_test(:,1:d)]';

%%%%%%  build the corresponding label vector                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  the order of the labels should correspond to the order of the     %%%%%%%
%%%%%%  training and test points in the kernel matrx K                    %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
labels = [data_train(:,d+1);data_test(:,d+1)];

%%%%%% assign values to parameters modelling uncertainty in               %%%%%%%
%%%%%% mean and covariance matrix for TOYDATA                             %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for real data, the true mean and covariance matrices are unknown in the
%% feature space
%%
%% nu_x, nu_y, rho_x, and rho_y could be estimated using resampling methods, 
%% the central limit theorem or cross-validation

%% Since we use a linear kernel for the TOYDATA here, we use as values for those
%% parameters the values we earlier assigned to them for the robust linear MEMPM
%% the resulting values should be assigned here
%% nu_x -- uncertainty in mean for class +1
%nu_x = ...;
%% nu_y -- uncertainty in mean for class -1
%nu_y = ...;
%% nu   -- uncertainty in mean
%nu = ...;
%% rho_x -- uncertainty in covariance matrix for class +1
%rho_x = ...;
%% rho_y -- uncertainty in covariance matrix for class -1
%rho_y = ...;


%% Under gaussian assumption, the optimization for the BMPM is convex when
%% beta>=0.5. This is a slight constraint for data with gaussian distribution.
%% 
%% You may specific suitable beta for the three-point pattern Quadratic Interpolation line search here.
%% Here we set beta(1)=min_beta, beta(3)=max_beta,beta(2)=(min_beta+max_beta)/2.
%% max_beta is obtained when alpha is set to (a value approaching to) its minimum. 
%% Due to the symmetry of alpha and beta, min_alpha=min_beta.
if(gauss_assump)
	beta(1) = 0.5001; 
else
    beta(1) = 0.0001; 
end
min_alpha = beta(1);
rlabels = -labels;
beta_up = build_robBMPM_k_bi_PM(K(1:n_train,1:n_train),rlabels(1:n_train),min_alpha,nu_x,nu_y,rho_x,rho_y,gauss_assump,1e-4,1e-4,50);
%% To avoid dividing by zero in kappa(beta_up), we make the maximum beta_up<1.
if beta_up > 1-tol beta_up = 1-tol; end;
beta(3) = beta_up;
beta(2) = (beta(1)+beta(3))/2;

%%%%%%  train kernelized MEMPM for TOYDATA                                %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% train kernelized MEMPM with nu_x~=nu_y
[alpha_kr, beta_kr, gamma_kr, b_kr] = build_robMEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,gauss_assump,beta,1e-4,1e-4,500,50);

%% train kernelized MEMPM with nu_x=nu_y
[alpha_kr2, beta_kr2, gamma_kr2, b_kr2] = build_robMEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),nu,nu,rho_x,rho_y,gauss_assump,beta,1e-4,1e-4,500,50);

%alpha_kr, beta_kr, gamma_kr, b_kr] = build_robMEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,gauss_assump,beta,1e-4,1e-4,500,50); 
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% notice that we make the gaussian assumption here (7th input is equal to 1)
%%
%% input 8-12 correspond to internal parameters of the learning algorithm: more
%% details about those can be found by 'help build_robMEMPM_k_bi_QI'

%%%%%%  train kernelized MEMPM for YOUR OWN DATA                            %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_kr, beta_kr, gamma_kr, b_kr] = build_robMEMPM_k_bi_QI(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,..7..,..8..,..9..,..10..,..11..,..12..);
%%
%% notice that only K_tr and only the labels for the training data points are
%% fed into the learning algorithm
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..7.. is '1' if you assume that both classes are Gaussian distributed in
%%       the feature space (i.e., the space where the mapped data points Phi(z)
%%       live), '0' for the general case
%% ..8.. is the initial parameters for the three-pattern QI method, its norm
%%       equal to 0 will lead to the default value
%% ..9.., ..10.., ..11.., ..12.. are internal parameters of the algorithm: putting them equal
%% to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMEMPM_k_bi_QI'

%%%%%%  train robust kernelized MPM for TOYDATA                           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% robust kernelized MPM: nu_x~=nu_y
[alpha_kr0, gamma_kr0, b_kr0] = build_robMPMn_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,gauss_assump,1e-4,1e-4,50);

%% robust linear MPM: nu_x=nu_y=nu
[alpha_kr02, gamma_kr02, b_kr02] = build_robMPMn_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),nu,nu,rho_x,rho_y,gauss_assump,1e-4,1e-4,50);

%% There are total 10 input parameters for the function, 'build_robMPMn_k_bi_PM'.
%% More details can be found by 'help build_robMPMn_k_bi_PM'

%%%%%%  train robust kernelized MPM for YOUR OWN DATA                     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[alpha_kr0, gamma_kr0, b_kr0] = build_robMPMn_k_bi_PM(K(1:n_train,1:n_train),labels(1:n_train),nu_x,nu_y,rho_x,rho_y,gauss_assump,..8..,..9..,..10..);
%%
%% Fill in appropriate values for the '..i..':
%%
%% ..8.. is '1' if you assume that both classes are Gaussian distributed, '0' for
%%       for the general case
%% ..9.., ..10.. are internal parameters of the algorithm: putting them 
%%       equal to '-1', will result in the use of default values
%% 
%% for more details: 'help build_robMPMn_k_bi_PM'

echo on;
%>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
%
% Display the robust kernelized curves and theirs results.
%
%<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
pause % Press any key to continue (Note: use Ctrl-C to abort)
echo off;

%%%%%% to PLOT THE RESULT FOR THE TOYDATA                   %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
syms w x y ax ay f_mempmn f_mempme f_mpmn f_mpme

%% Construct the decision functions
%% kernelized MEMPM with nu_x~=nu_y
f_mempmn = subs(f_mempmn,-b_kr);
for i=1:n_train;
    f_mempmn = f_mempmn + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_kr(i),data_train(i,1),data_train(i,2)});
end;

%% kernelized MEMPM with nu_x=nu_y
f_mempme = subs(f_mempme,-b_kr2);
for i=1:n_train;
    f_mempme = f_mempme + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_kr2(i),data_train(i,1),data_train(i,2)});
end;

%% kernelized MPM with nu_x~=nu_y
f_mpmn = subs(f_mpmn,-b_kr0);
for i=1:n_train;
    f_mpmn = f_mpmn + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_kr0(i),data_train(i,1),data_train(i,2)});
end;

%% kernelized MPM with nu_x~=nu_y
f_mpme = subs(f_mpme,-b_kr02);
for i=1:n_train;
    f_mpme = f_mpme + subs(w*(x*ax+y*ay),{w,ax,ay},{gamma_kr02(i),data_train(i,1),data_train(i,2)});
end;

figure(3)
hold on
%% The kernelized boundary of MEMPM with nu_x~=nu_y is solved by f_mempmn=0, and plotted as a blue line.
ezplot(f_mempmn);
%% The linear MEMPM with nu_x~=nu_y is plotted as red line.
plot([(b_rob+5*a_rob(2,1))/a_rob(1,1), (b_rob-5*a_rob(2,1))/a_rob(1,1)],[-5,5],'r-');

%% The kernelized boundary of MEMPM with nu_x=nu_y is solved by f_mempme=0, and plotted as a blue line.
ezplot(f_mempme);
%% The linear MEMPM with nu_x=nu_y is plotted as red line.
plot([(b_rob2+5*a_rob2(2,1))/a_rob2(1,1), (b_rob2-5*a_rob2(2,1))/a_rob2(1,1)],[-5,5],'r-');

%% The kernelized boundary of MPM with nu_x~=nu_y is solved by f_mpmn=0, and plotted as a blue line.
ezplot(f_mpmn);
%% The linear MPM with nu_x~=nu_y is plotted as red line.
plot([(b_rob0+5*a_rob0(2,1))/a_rob0(1,1), (b_rob0-5*a_rob0(2,1))/a_rob0(1,1)],[-5,5],'r-');

%% The kernelized boundary of MPM with nu_x=nu_y is solved by f_mempe=0, and plotted as a blue line.
ezplot(f_mpme);
%% The linear MPM with nu_x=nu_y is plotted as red line.
plot([(b_rob02+5*a_rob02(2,1))/a_rob02(1,1), (b_rob02-5*a_rob02(2,1))/a_rob02(1,1)],[-5,5],'r-');

%% plot training data for class +1 as +'s and for class -1 as squares
plot(Xtrain(:,1), Xtrain(:,2), 'k+', Ytrain(:,1), Ytrain(:,2), 'ms');
title('Data: Class +1 training/test data is +/x; Class -1 training/test data is square/o');
xlabel('Z_1');
ylabel('Z_2');
axis equal
axis([-8 6 -5 5])
hold on
%% plot test data for class +1 as x's and for class -1 as o's
plot(Xtest(:,1), Xtest(:,2), 'bx', Ytest(:,1), Ytest(:,2), 'go');
%% plot decision line corresponding to robust linear MEMPM in blue solid line

%%%%%% evaluate performance of the MEMPM                    %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% robust MEMPM with nu_x~=nu_y
[ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab,pg_trx,pg_try,pg_tx,pg_ty,pg_trtx,pg_trty] = eval_k_bi(K,labels,gamma_kr,b_kr);

%% robust MEMPM with nu_x=nu_y=nu
[ng_tr2,pg_tr2,ng_t2,pg_t2,ng_trt2,pg_trt2,lab2,pg_trx2,pg_try2,pg_tx2,pg_ty2,pg_trtx2,pg_trty2] = eval_k_bi(K,labels,gamma_kr2,b_kr2);

%% robust MPM with nu_x~=nu_y
[ng_tr0,pg_tr0,ng_t0,pg_t0,ng_trt0,pg_trt0,lab0,pg_trx0,pg_try0,pg_tx0,pg_ty0,pg_trtx0,pg_trty0] = eval_k_bi(K,labels,gamma_kr0,b_kr0);

%% robust MPM with nu_x=nu_y=nu
[ng_tr02,pg_tr02,ng_t02,pg_t02,ng_trt02,pg_trt02,lab02,pg_trx02,pg_try02,pg_tx02,pg_ty02,pg_trtx02,pg_trty02] = eval_k_bi(K,labels,gamma_kr02,b_kr02);

% [ng_tr,pg_tr,ng_t,pg_t,ng_trt,pg_trt,lab, pg_trx, pg_try, pg_tx, pg_ty, pg_trtx, pg_trty] = eval_k_bi(K,labels,gamma_kr,b_kr);
%% for more details about this function: 'help eval_k_bi'
%% (contains also details about computing the label for data points for which the
%% label is unknown)


%% display relevant values
disp('>>>>>>>>>> Results of kernelized MEMPM with nu_x~=nu_y <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_kr*100);
disp('Robust underbound on correct classification of future data-Class 2:');
disp(beta_kr*100);
disp('Robust underbound on correct classification of future data:');
disp((xprior*alpha_kr+yprior*beta_kr)*100);

disp('Training set accuracy:');
disp(pg_tr);
disp('Training set accuracy-Class 1:');
disp(pg_trx);
disp('Training set accuracy-Class 2:');
disp(pg_try);

disp('Test set accuracy:');
disp(pg_t);
disp('Test set accuracy-Class 1:');
disp(pg_tx);
disp('Test set accuracy-Class 2:');
disp(pg_ty);

disp('>>>>>>>>>> Results of kernelized MEMPM with nu_x=nu_y=nu <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data-Class 1:');
disp(alpha_kr2*100);
disp('Robust underbound on correct classification of future data-Class 2:');
disp(beta_kr2*100);
disp('Robust underbound on correct classification of future data:');
disp((xprior*alpha_kr2+yprior*beta_kr2)*100);

disp('Training set accuracy:');
disp(pg_tr2);
disp('Training set accuracy-Class 1:');
disp(pg_trx2);
disp('Training set accuracy-Class 2:');
disp(pg_try2);

disp('Test set accuracy:');
disp(pg_t2);
disp('Test set accuracy-Class 1:');
disp(pg_tx2);
disp('Test set accuracy-Class 2:');
disp(pg_ty2);

disp('>>>>>>>>>> Results of kernelized MPM with nu_x~=nu_y <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data');
disp(alpha_kr0*100);

disp('Training set accuracy:');
disp(pg_tr0);

disp('Test set accuracy:');
disp(pg_t0);

disp('>>>>>>>>>> Results of kernelized MPM with nu_x=nu_y=nu <<<<<<<<<<<<');
disp('Robust underbound on correct classification of future data');
disp(alpha_kr02*100);

disp('Training set accuracy:');
disp(pg_tr02);

disp('Test set accuracy:');
disp(pg_t02);