function [alpha_lin, a] = solve_robFP_RG(Mx,My,Covx,Covy,beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,ita1,tol,RGiter)
% solve_robFP_RG       - solve a Fractional Programming Problem by the Rosen Gradient (RG) 
%                       projection method with robust parameters, or a robust BMPM problem.
%
% [alpha_lin, a] = solve_robFP_RG(Mx,My,Covx,Covy,beta0,nu_x,nu_y,rho_x,rho_y,gauss_assump,ita1,tol,RGiter)
%
% The algorithm finds a(<>0) by maximizing 
%  k(a) = (1-(kbeta0+nu_y)*sqrt(a'*(Covy+rho_y*I)*a))/sqrt(a'*(Covx+rho_x*I)*a)
% where I is an identity matrix, Mx, My, Covx and Covy are estimated from data using the classical plug-in estimates.
% kbeta0 = norminv(beta0,0,1), if under gaussian assumption; sqrt(beta0/(1-beta0)), otherwise
%
% The inputs are
% Mx           - (estimated) mean of class x (column vector)
% My           - (estimated) mean of class y (column vector)
% Covx         - (estimated) covariance matrix of class x
% Covy         - (estimated) covariance matrix of class y
% beta0        - the parameter for the BMPM to maintain the accuracy of class y
% nu_x,nu_y    - robustness parameter quantizing uncertainty in the mean for class x, resp. y            
%                (0 for no robustness)
% rho_x,rho_y   - robustness parameter quantizing uncertainty in the covariance for class x, resp. y
%                (0 for no robustness)
% gauss_assump - 1 if x and y are assumed to be Gaussian distributed / 0 if not;
% ita          - internal parameter for the initial step of the RG method. 
% tol          - relative tolerance level for RG method
% RGiter       - maximum number of iterations for RG method
%
% The outputs are
% alpha_lin    - the probability of correct classification of future data
%                for class x with given probability of beta0
% a            - optimal solution for the robust FP problem
%

%%%%%% Calculate kappa(beta0)
if gauss_assump==1
    kbeta0 = norminv(beta0,0,1);
else
    kbeta0 = sqrt(beta0/(1-beta0));
end

%% Initialize
kbetap = kbeta0+nu_y;

A = Mx - My;
d = size(A,1);
a=0.6*ones(d,1);
i1=find(abs(A)==max(abs(A)));
a(i1(1))=(1-sum(a.*A)+a(i1(1))*A(i1(1)))/A((i1));    
gradi=ones(d,1);
epoch=1;%ita=0.1;

I=eye(d,d);
Sxp = Covx+rho_x*I;
Syp = Covy+rho_y*I;

ita=ita1;
da = 10*tol;

%% Begin Rosen Gradient projection method
while and(epoch<=RGiter,da>tol)
     a_old = a;
     Vx=a'*Sxp*a; Vy=a'*Syp*a;
     t1=kbetap*sqrt(Vx)/sqrt(Vy)*Syp*a;
     t2=(1-kbetap*sqrt(Vy))/sqrt(Vx)*Sxp*a;
     gradi=-1/Vx*(t1+t2);
     P=I-A*inv(A'*A)*A';
     gradi=P*gradi;
     %find optimal ita;
     a1=a+ita*gradi;
     Vy_dg(epoch)=Vy;
     kalpha(epoch)=(1-kbetap*sqrt(Vy))/sqrt(Vx);
     if(epoch>1)
         if(kalpha(epoch)-kalpha(epoch-1)>tol)
                     a=a1;
         else
             ita=ita/2;
             a=a+ita*gradi;
        end
    else
        a=a1;
    end
    epoch=epoch+1;
    da = norm(a-a_old);
end
Vx=a'*Sxp*a; Vy=a'*Syp*a;
ka = (1-kbetap*sqrt(Vy))/sqrt(Vx);  
kalpha= max([ka-nu_x,0]);
if gauss_assump==1
    alpha_lin=normcdf(kalpha,0,1);
else
    alpha_lin=kalpha^2/(kalpha^2+1);
end
