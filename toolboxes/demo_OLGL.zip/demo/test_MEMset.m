clear
clc

% start training
load(['./dat/P.mat']); %, 'P');
GroupOption = GetGroupOption(P);
Niter = 10;

load(['./dat/tr5_trans.mat']); %, 'trXPDat', 'trYP');
load(['./dat/tr5_idx.mat']); %, 'idxP'   
    
lamds = [.1]; %, 0.7, .8, 0.9, 1];
sz_lamds = size(lamds, 2);
methods = {'L1-RDA', 'DA-GL', 'DA-SGL'}; %, 'FOBOS-GL', 'FOBOS-SGL', 'GL-LR', 'SGL-LR'};
sz_ms = length(methods);

trN = 5610;
Ntr = 2*trN;
option.Nepoch = 1;
option.Niter = Ntr;
option.loss = 'logit';
option.r = ones(GroupOption.lenP, 1);

fprintf('--------------------------\n');
disp('| #Rep | lambda | method |');

for repi=1:Niter
    load(['./dat/tr0_trans', num2str(repi), '.mat']); %, 'trXNDat', 'trYN');    

    Xtr = [trXPDat(idxP(1:trN), :); trXNDat(1:trN, :)];
%         Xtr = [ones(trN*2,1), Xtr];

    Ytr = [ones(trN,1), -ones(trN,1)];

    maxL = 8;
    option.gamma = maxL;
    option.rho = 1/option.gamma;

    for lami=1:sz_lamds
        option.lambda = lamds(lami);

%         model_name = ['./rs/MEMset/r', num2str(repi), '_lam', num2str(option.lambda), '.mat'];

        for mi=1:sz_ms                   
%                 disp([num2str(repi), '|', num2str(lamds(lami)), '|', methods(mi), '\\n']);
%                 fprintf('| %d | %.1f | %s |\n',[num2str(repi), num2str(lamds(lami)), methods(mi)]);
            fprintf('| %d | %.1f | %d |\n',[repi, lamds(lami), mi]);

            switch methods{mi}
                case 'L1-RDA'     
%                         option.lambda = lambstep(lami)*maxLambdas(rep,
%                         2*Ni-1);
                    [w, mw, mu, histu] = L1RDA(option, [ones(Ntr,1), Xtr], Ytr);

                    L1RDA_w = w;
                    L1RDA_mw = mw;
                    L1RDA_histu = histu;

                case 'DA-GL'
                    option.lambda = lamds(lami)./sqrt(GroupOption.lenUniP);
                    option.model = 'Group_Lasso';

                    [w, mw, mu, histu] = DA_GL(option, GroupOption, [ones(Ntr,1), Xtr], Ytr);

                    DAGL_w = w;
                    DAGL_mw = mw;
                    DAGL_histu = histu;

                case 'DA-SGL'
                    option.lambda = lamds(lami)./sqrt(GroupOption.lenUniP);
                    option.model = 'Sparse_Group_Lasso';

                    [w, mw, mu, histu] = DA_GL(option, GroupOption, [ones(Ntr,1), Xtr], Ytr);

                    DASGL_w = w;
                    DAGL_mw = mw;
                    DASGL_histu = histu;

                case 'FOBOS-GL'
                    [w, mw, mu] = FOBOS_GL(option, [ones(Ntr,1), Xtr], Ytr, w, mw, mu);
                    FOBOSGL_w(rep, lami) = w;
                    FOBOSGL_mw(rep, lami) = mw;
                    FOBOSGL_mu(rep, lami) = mu;   

                case 'FOBOS-SGL'

                case 'GL-LR'
                case 'SGL-LR'                            
            end  % end of method cases

%             pre_Y = [];
%             pre_mY = [];
%             Yts = [];
%             for iPart=1:25
%                 load(['../data/MEMset/mat/ts_trans', num2str(iPart), '.mat']); %, 'tsXDat', 'tsYsp');
% 
%                 pre_Y = [pre_Y; sign([ones(size(tsYsp,1),1), tsXDat]*w)];
%                 pre_mY = [pre_mY; sign([ones(size(tsYsp,1), 1), tsXDat]*mw)];
% 
%                 Yts = [Yts; tsYsp];
%             end
% 
%             for wi=1:size(w, 2);
%                 evalCC = eval_classification((Yts+1)/2, (pre_Y(:,wi)+1)/2);                
%                 rsCC(wi, mi) = evalCC.CC;
% 
%                 evalmCC = eval_classification((Yts+1)/2, (pre_mY(:,wi)+1)/2);                
%                 rsmCC(wi, mi) = evalmCC.CC;
% 
%                 II = find(abs(w(2:end,wi))>1e-8);
%                 rsW(wi, mi) = length(II);
% 
%                 II = find(abs(mw(2:end,wi))>1e-8);
%                 rsmW(wi, mi) = length(II);
%             end %
%                 save(model_name, 'rsCC', 'rsW', 'w', 'mw', 'histu'); 
        end % end of mi
%         save(model_name, 'rsCC', 'rsW', 'L1RDA_w', 'L1RDA_mw', 'L1RDA_histu', 'DAGL_w', 'DAGL_mw', 'DAGL_histu', 'DASGL_w', 'DASGL_mw', 'DASGL_histu');
%         save(model_name, 'rsCC', 'rsW', 'w', 'mw', 'histu'); 
    end % end of lami                    
end % end rep    