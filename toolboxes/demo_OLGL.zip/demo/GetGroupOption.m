function GroupOption = GetGroupOption(P)

Pg0 = P(P>0);
uniP = unique(Pg0);
lenP = length(uniP);
idxP = zeros(length(Pg0), lenP);
lenUniP = zeros(lenP,1);

for iP = 1:lenP
    II = find(P==uniP(iP));
    lenUniP(iP,1) = length(II);
    idxP(1:length(II), iP) = II;
end
mxLen = max(lenUniP);
idxP(mxLen+1:end, :) = [];

GroupOption.lenP = lenP;
GroupOption.idxP = idxP;
GroupOption.lenUniP = lenUniP;