function [w, mw, mu, histu, tm] = L1RDA(option, X, Y)

% Suppose X is [1 X]
[N, d] = size(X);

histu = [];
w = zeros(d,1);
mw = zeros(d,1);
mu = zeros(d,1);

iter = 1;

Nepoch = 1;
tic;
while (Nepoch<=option.Nepoch)
    Nepoch = Nepoch+1;
    
    idx_data = 1;
    while idx_data<=option.Niter
        x_t = X(idx_data, :);
        y_t = Y(idx_data);
        w_t = w(:,iter);
        idx_data = idx_data+1;
        
        switch option.loss
            case 'square'
                u_t = -x_t'*(y_t-x_t*w_t);
            case 'logit'
%                 u_t = (-1+1/(1+exp(-y_t*(x_t*w_t))))*(y_t*x_t');
                u_t = -1/(1+exp(y_t*(x_t*w_t)))*(y_t*x_t');
            case 'hinge'
                u_t = max(0, -y_t*x_t');
        end

%         histu(:, iter) = u_t;
        
        iter = iter+1;

        mw(:, iter) = (iter-2)/(iter-1)*mw(:,iter-1)+1/(iter-1)*w_t;
        mu(:,iter) = (iter-2)/(iter-1)*mu(:,iter-1)+1/(iter-1)*u_t;

        weight = max(0, abs(mu(:,iter))-option.lambda);

        II = find(weight>0);
        w(II, iter) = -sqrt(iter-1)/option.gamma*(mu(II,iter)-option.lambda*sign(mu(II,iter)));
        w(1, iter) = -sqrt(iter-1)/option.gamma*mu(1, iter);

%         if (mod(iter, 5)==0)
%             aa = 1;
%         end
    %     ww = w(:,iter);
    %     ww(abs(ww)<option.tol) = 0;
    end
end
tm = toc;