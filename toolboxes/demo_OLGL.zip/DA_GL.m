function [w, mw, mu, histu, tm] = DA_GL(option, GroupOption, X, Y)

% f(x) = w'*x+b
% w: weight of decision function
% mw: mean weight of decision function
% u: mean sub-gradient 

% Suppose X is [1 X]
[N, d] = size(X);

histu = [];

idxP = GroupOption.idxP;        % the index for each group
lenP = GroupOption.lenP;        % no. of groups
lenUniP = GroupOption.lenUniP;  % length for each group

lambda_dg = option.lambda.*sqrt(lenUniP);
lambda_rg = option.lambda.*option.r;

w = zeros(d,1);
mw = zeros(d,1);
mu = zeros(d,1);

iter = 1;

Nepoch = 1;
tic;
while (Nepoch<=option.Nepoch)
    Nepoch = Nepoch+1;

    idx_data = 1;
    while idx_data<=option.Niter
        x_t = X(idx_data, :);
        y_t = Y(idx_data);
        w_t = w(:,iter);
        idx_data = idx_data+1;

        switch option.loss
            case 'square'
                u_t = -x_t'*(y_t-x_t*w_t);
            case 'logit'
%                 u_t = (-1+1/(1+exp(-y_t*(x_t*w_t))))*(y_t*x_t');
                u_t = -1/(1+exp(y_t*(x_t*w_t)))*(y_t*x_t');
            case 'hinge'
                u_t = max(0, -y_t*x_t');
        end

%         histu(:, iter) = u_t;
        iter = iter+1;

        mw(:, iter) = (iter-2)/(iter-1)*mw(:,iter-1)+1/(iter-1)*w_t;
        mu(:,iter) = (iter-2)/(iter-1)*mu(:,iter-1)+1/(iter-1)*u_t;

        gamma_t = sqrt(iter-1)/option.gamma;
        w(1, iter) = -gamma_t*mu(1, iter);

        for iP = 1:lenP
            idx_used = idxP(1:lenUniP(iP), iP);

            u_g = mu(idx_used,iter);
            switch option.model
                case 'Group_Lasso'
                    n2u_t = norm(u_g);
                    
                    if (n2u_t==0)
                        weight = 0;
                    else                       
                        weight = max(0, 1-lambda_dg(iP)/n2u_t);
                    end
                    
                    w(idx_used, iter) = -gamma_t*weight*u_g;
                case 'Sparse_Group_Lasso'
                    c_g = max(abs(u_g)-lambda_rg(iP), 0).*sign(u_g);
                    
                    II = find(c_g==0);
                    if (size(II))
                        a=0;
                    end
                    
                    n2c_g = norm(c_g);
                    if (n2c_g==0)
                        weight = 0;
                    else
                        weight = max(0, 1-lambda_dg(iP)/n2c_g);
                    end
                    
                    w(idx_used, iter) = -gamma_t*weight*c_g;                
    %                 k_g = solve_kg(u_g, c_g, lambda_dg(iP), lambda_rg(iP), 1/gamma_t);
                case 'ESparse_Group_Lasso'
                    c_g = max(0, abs(u_g)-lambda_rg(iP)-option.rho/gamma_t).*sign(u_g);
                    weight = max(0, 1-lambda_dg(iP)/norm(c_g));
                    w(idx_used, iter) = -gamma_t*weight*c_g;                
    %                 c_g = abs(u_g-lambda_rg(iP)-gamma_t*option.rho)*sign(u_g);
    %                 k_g = solve_kg(u_g, c_g, lambda_dg(iP), lambda_rg(iP)+option.lambda*gamma_t*option.rho, .5/gamma_t);
            end                
        end
    %     ww = w(:,iter);
    %     ww(abs(ww)<option.tol) = 0;    
    end
end
tm=toc;

function k_g = solve_kg(u_g, c_g, lambda_dg, lambda_rg, gamma_t)

n = size(u_g, 1);

cvx_begin
    variable k_g(n);
    minimize (u_g'*(c_g.*k_g)+lambda_dg*norm(c_g.*k_g, 2)+lambda_rg*norm(c_g.*k_g,1)+gamma_t/2*(c_g.*k_g)'*(c_g.*k_g));
    subject to
        k_g>=0;
cvx_end